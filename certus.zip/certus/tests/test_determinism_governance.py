from decimal import Decimal

import pytest

from certus.engine import Engine
from certus.errors import AccessDenied, ModelError
from certus.expr import Formula
from certus.model import load_model

from .conftest import q, val


# ---------------------------------------------------------------- determinism

def test_same_request_same_hash_across_engines(engine, demo_dir):
    req = dict(metrics=["deposit_balance", "loan_to_deposit_ratio", "net_flow"], period="2025",
               dimensions=["branch.region", "time:quarter"])
    a = q(engine, **req)
    b = q(Engine(load_model(demo_dir / "acme_bank.certus.yaml"), demo_dir / "principals.yaml"), **req)
    assert a.meta["result_hash"] == b.meta["result_hash"]
    assert a.meta["data_hash"] == b.meta["data_hash"]


def test_physical_row_order_does_not_matter(engine, variant):
    req = dict(metrics=["deposit_balance", "net_flow", "active_customers"], period="2025", dimensions=["branch.region"])
    base = q(engine, **req)
    shuffled = variant(edit_data={t: f"CREATE OR REPLACE TABLE t AS SELECT * FROM t ORDER BY hash(rowid * 7919)"
                                  for t in ["txn", "balance_snapshot", "account", "fx_rate", "account_owner"]})
    other = q(shuffled, **req)
    assert other.meta["result_hash"] == base.meta["result_hash"]
    assert other.meta["data_hash"] == base.meta["data_hash"]


@pytest.mark.parametrize("bad, match", [
    ({"filter": "txn_date <= CURRENT_DATE"}, "non-deterministic"),
    ({"expr": "amount / 2"}, "division"),
    ({"expr": "amount * 1e2"}, "floating"),
    ({"expr": "CAST(amount AS DOUBLE)"}, "inexact"),
    ({"agg": "avg"}, "agg must be"),
    ({"filter": "amount > (SELECT 1)"}, "not allowed"),
    ({"expr": "APPROX_COUNT_DISTINCT(customer_id)"}, "inexact"),
])
def test_non_deterministic_or_inexact_definitions_rejected(variant, bad, match):
    def edit(raw):
        m = next(x for x in raw["metrics"] if x["name"] == "fee_revenue")
        m.update(bad)
    with pytest.raises(ModelError, match=match):
        variant(edit)


def test_decimal_formulas():
    assert Formula("round(x, 2)", where="t").evaluate({"x": Decimal("0.125")}) == Decimal("0.12")   # half-even
    assert Formula("round(x, 2)", where="t").evaluate({"x": Decimal("0.135")}) == Decimal("0.14")
    assert Formula("a / b", where="t").evaluate({"a": Decimal(1), "b": Decimal(0)}) is None          # no error, missing
    assert Formula("0.1 + 0.2 == 0.3", where="t").evaluate({}) is True                               # exact, not float
    assert Formula("x > 1 and y > 1", where="t").evaluate({"x": None, "y": Decimal(0)}) is False     # 3-valued
    assert Formula("x > 1 and y > 1", where="t").evaluate({"x": None, "y": Decimal(5)}) is None


def test_model_typos_are_errors(variant):
    with pytest.raises(ModelError, match="unknown top-level keys"):
        variant(lambda raw: raw.update({"rolez": {}}))
    with pytest.raises(ModelError, match="matches nothing"):
        variant(lambda raw: raw["roles"]["analyst"]["allow_metrics"].append("deposit_balanse"))


# ---------------------------------------------------------------- governance

def test_pii_and_restricted_refused_before_sql(engine):
    with pytest.raises(AccessDenied, match="PII"):
        q(engine, "ana.analyst", metrics=["deposit_balance"], period="2025-12", dimensions=["customer.email"])
    with pytest.raises(AccessDenied, match="RESTRICTED"):
        q(engine, "ana.analyst", metrics=["aml_flag_rate"], period="2025")
    with pytest.raises(AccessDenied, match="RESTRICTED"):
        q(engine, "ana.analyst", metrics=["transaction_count"], period="2025", dimensions=["customer_risk.risk_rating"])
    assert q(engine, "rita.risk", metrics=["aml_flag_rate"], period="2025").rows


def test_metric_dependencies_are_governed(engine):
    with pytest.raises(AccessDenied, match="aml_flag_rate|flagged_transactions"):
        q(engine, "carl.credit", metrics=["aml_flag_rate"], period="2025")
    assert q(engine, "carl.credit", metrics=["card_utilization"], period="2025-12").rows


def test_row_filter(engine):
    tx = q(engine, "tom.txbranch", metrics=["deposit_balance"], period="2025-12", dimensions=["branch.state"])
    assert [r["branch.state"] for r in tx.rows] == ["TX"]
    full = q(engine, "ana.analyst", metrics=["deposit_balance"], period="2025-12", dimensions=["branch.state"])
    assert val(tx, "deposit_balance") == val(full, "deposit_balance", **{"branch.state": "TX"})
    total = q(engine, "tom.txbranch", metrics=["deposit_balance"], period="2025-12")
    assert val(total, "deposit_balance") == val(tx, "deposit_balance")


def test_unenforceable_row_filter_fails_closed(variant):
    def edit(raw):
        raw["metrics"].append({"name": "customers_on_file", "unit": "count", "status": "draft",
                               "dataset": "customer", "agg": "count"})
    e = variant(edit)
    with pytest.raises(AccessDenied, match="cannot reach"):
        q(e, "tom.txbranch", metrics=["customers_on_file"], period="2025")
    assert q(e, "ana.analyst", metrics=["customers_on_file"], period="2025").rows


def test_roles_must_be_entitled(engine):
    with pytest.raises(AccessDenied, match="not entitled"):
        q(engine, "ana.analyst", metrics=["deposit_balance"], period="2025", role="aml_officer")
    with pytest.raises(AccessDenied, match="unknown principal"):
        q(engine, "mallory", metrics=["deposit_balance"], period="2025")


def test_agent_policy(engine):
    with pytest.raises(AccessDenied, match="certified"):
        q(engine, "claude.agent", metrics=["experimental_engagement_score"], period="2025")
    with pytest.raises(AccessDenied, match="limit"):
        q(engine, "claude.agent", metrics=["deposit_balance"], period="2025-12", dimensions=["branch.region"])
    with pytest.raises(AccessDenied, match="CONFIDENTIAL"):
        q(engine, "claude.agent", metrics=["card_balance"], period="2025-12", dimensions=["account.account_number"], limit=5)
    assert q(engine, "claude.agent", metrics=["deposit_balance"], period="2025-12", dimensions=["branch.region"], limit=10).rows


def test_protected_attributes_cannot_drive_decisions(variant):
    def edit(raw):
        d = next(x for x in raw["decisions"] if x["name"] == "liquidity_watch")
        d["grain"] = ["customer.birth_year"]
    with pytest.raises(ModelError, match="PROTECTED"):
        variant(edit)


def test_certified_metric_cannot_depend_on_draft(variant):
    def edit(raw):
        raw["metrics"].append({"name": "x_ratio", "unit": "ratio", "status": "certified", "owner": "o",
                               "approved_by": "a", "formula": "experimental_engagement_score / transaction_count"})
    with pytest.raises(ModelError, match="depends on experimental_engagement_score"):
        variant(edit)
