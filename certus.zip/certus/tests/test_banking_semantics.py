"""Each test closes one of the Ossie gaps identified for banking."""
from decimal import ROUND_HALF_EVEN, Decimal

import duckdb
import pytest

from certus.errors import DataIntegrityError, QueryError

from .conftest import q, val

D = Decimal


def raw(engine, sql):
    con = duckdb.connect()
    for name, ds in engine.model.datasets.items():
        con.execute(f"CREATE VIEW {name} AS SELECT * FROM read_parquet('{engine.model.data_dir / (ds.source + '.parquet')}')")
    return con.execute(sql).fetchall()


# ---------------------------------------------------------------- gap 2: time and balances

def test_balances_are_point_in_time_not_summed(engine):
    year = val(q(engine, metrics=["deposit_balance"], period="2025"), "deposit_balance")
    december = val(q(engine, metrics=["deposit_balance"], period="2025-12"), "deposit_balance")
    monthly = q(engine, metrics=["deposit_balance"], period="2025", dimensions=["time:month"])
    assert year == december                       # the year reports its last month-end
    assert len(monthly.rows) == 12
    naive = sum(r["deposit_balance"] for r in monthly.rows)
    assert naive > 10 * year                      # what a plain SUM over time would have reported


def test_average_balance_is_mean_of_month_ends(engine):
    avg = val(q(engine, metrics=["average_deposit_balance"], period="2025"), "average_deposit_balance")
    months = q(engine, metrics=["deposit_balance"], period="2025", dimensions=["time:month"])
    # month values are rounded to cents for display; the average is computed from unrounded values
    approx = sum(r["deposit_balance"] for r in months.rows) / 12
    assert abs(avg - approx) <= D("0.01")


def test_quarter_grain_takes_each_quarter_end(engine):
    qs = q(engine, metrics=["deposit_balance"], period="2025", dimensions=["time:quarter"])
    for row, month in zip(qs.rows, ["2025-03", "2025-06", "2025-09", "2025-12"]):
        assert row["deposit_balance"] == val(q(engine, metrics=["deposit_balance"], period=month), "deposit_balance")


def test_bitemporal_restatement(engine):
    before = q(engine, metrics=["credit_outstanding", "deposit_balance"], period="2025-12", known_at="2026-01-05T00:00:00")
    after = q(engine, metrics=["credit_outstanding", "deposit_balance"], period="2025-12")
    assert val(before, "credit_outstanding") - val(after, "credit_outstanding") == D("500000.00")
    assert val(before, "deposit_balance") == val(after, "deposit_balance")
    assert after.meta["known_at"] == "2026-01-15T10:00:00" and after.meta["known_at_source"] == "data watermark"


def test_reversal_tombstone(engine):
    f = [{"field": "txn.channel", "op": "=", "value": "Wire"}]
    early = val(q(engine, metrics=["transaction_count"], period="2025-11-10", filters=f, known_at="2025-11-12T00:00:00"),
                "transaction_count")
    late = val(q(engine, metrics=["transaction_count"], period="2025-11-10", filters=f), "transaction_count")
    assert early - late == 1   # the reversed $480k wire disappears once the void is known


def test_knowledge_cutoff_warning(engine):
    r = q(engine, metrics=["transaction_count"], period="2025-11", known_at="2025-11-15T00:00:00")
    assert any("only known up to" in w for w in r.meta["warnings"])


# ---------------------------------------------------------------- gap 3: money

def test_fx_converts_each_row_at_its_rate(engine):
    eur = val(q(engine, metrics=["deposit_balance"], period="2025-12", dimensions=["account.currency"]),
              "deposit_balance", **{"account.currency": "EUR"})
    rows = raw(engine, """
        WITH s AS (SELECT * FROM (SELECT *, row_number() OVER (PARTITION BY account_id, snapshot_date ORDER BY recorded_at DESC) rn
                   FROM balance_snapshot) WHERE rn = 1 AND snapshot_date = DATE '2025-12-31')
        SELECT s.balance FROM s JOIN account a USING (account_id) WHERE a.currency = 'EUR' AND a.product_family = 'DEPOSIT'""")
    rate = raw(engine, "SELECT rate FROM fx_rate WHERE currency='EUR' AND rate_type='MONTH_END' AND rate_date=DATE '2025-12-31'")[0][0]
    expect = (sum(r[0] for r in rows) * rate).quantize(D("0.01"), rounding=ROUND_HALF_EVEN)
    assert eur == expect


def test_currency_breakdown_adds_up(engine):
    total = val(q(engine, metrics=["deposit_balance"], period="2025-12"), "deposit_balance")
    parts = q(engine, metrics=["deposit_balance"], period="2025-12", dimensions=["account.currency"])
    assert {r["account.currency"] for r in parts.rows} == {"USD", "EUR", "GBP", "MXN"}
    assert abs(sum(r["deposit_balance"] for r in parts.rows) - total) <= D("0.02")  # per-row display rounding


def test_reporting_currency_translation(engine):
    usd = q(engine, metrics=["deposit_balance"], period="2025-12")
    eur = q(engine, metrics=["deposit_balance", "loan_to_deposit_ratio"], period="2025-12", reporting_currency="EUR")
    rate = D(eur.meta["fx"]["translation"]["rate"])
    assert abs(val(eur, "deposit_balance") * rate - val(usd, "deposit_balance")) < D("1")
    assert val(eur, "loan_to_deposit_ratio") == val(q(engine, metrics=["loan_to_deposit_ratio"], period="2025-12"),
                                                    "loan_to_deposit_ratio")


def test_missing_fx_rate_is_refused_not_guessed(variant):
    def edit(raw):
        for m in raw["metrics"]:
            if m["name"] == "transaction_volume":
                m["fx"]["rate_type"] = "WEEKLY"
    e = variant(edit)
    with pytest.raises(DataIntegrityError, match="FX rate"):
        q(e, metrics=["transaction_volume"], period="2025-12")


def test_stale_fx_rate_is_refused(variant):
    e = variant(edit_data={"fx_rate": "DELETE FROM t WHERE currency = 'GBP' AND rate_date BETWEEN DATE '2025-11-20' AND DATE '2025-11-30'"})
    with pytest.raises(DataIntegrityError, match="older than"):
        q(e, metrics=["transaction_volume"], period="2025-11")


# ---------------------------------------------------------------- gap 5: composition at own grain

def test_ratio_components_at_own_grain(engine):
    r = q(engine, metrics=["deposits_per_employee", "deposit_balance", "branch_headcount"], period="2025-12",
          dimensions=["branch.region"])
    for row in r.rows:
        assert abs(row["deposits_per_employee"] - row["deposit_balance"] / row["branch_headcount"]) <= D("0.01")
    naive = raw(engine, """SELECT b.region, sum(s.balance) / sum(b.headcount) FROM balance_snapshot s
        JOIN account a USING (account_id) JOIN branch b USING (branch_id)
        WHERE s.snapshot_date = DATE '2025-12-31' AND a.product_family='DEPOSIT' AND b.region = 'South' GROUP BY 1""")
    south = val(r, "deposits_per_employee", **{"branch.region": "South"})
    assert south > 50 * D(str(naive[0][1]))   # naive SQL repeats headcount per balance row


def test_derived_metrics_are_exact_decimal(engine):
    r = q(engine, "rita.risk", metrics=["aml_flag_rate", "flagged_transactions", "transaction_count"], period="2025")
    row = r.rows[0]
    assert row["aml_flag_rate"] == (row["flagged_transactions"] / row["transaction_count"]).quantize(
        D("0.000001"), rounding=ROUND_HALF_EVEN)
    assert row["aml_flag_rate"] > 0   # no integer-division truncation to zero


# ---------------------------------------------------------------- gap 6: relationships

def test_bridge_allocation_preserves_totals(engine):
    total = val(q(engine, metrics=["deposit_balance"], period="2025-12"), "deposit_balance")
    seg = q(engine, metrics=["deposit_balance"], period="2025-12", dimensions=["customer.segment"])
    assert abs(sum(r["deposit_balance"] for r in seg.rows) - total) <= D("0.02")


def test_bad_allocation_weights_refused(variant):
    e = variant(edit_data={"account_owner": "UPDATE t SET share = 0.6 WHERE share = 0.5 AND customer_id % 2 = 0"})
    with pytest.raises(DataIntegrityError, match="allocation weights"):
        q(e, metrics=["deposit_balance"], period="2025-12", dimensions=["customer.segment"])


def test_plain_count_through_bridge_refused(variant):
    def edit(raw):
        raw["metrics"].append({"name": "snapshot_rows", "unit": "count", "dataset": "balance_snapshot", "agg": "count"})
    e = variant(edit)
    with pytest.raises(QueryError, match="cannot be allocated"):
        q(e, metrics=["snapshot_rows"], period="2025-12", dimensions=["customer.segment"])


def test_type2_as_of_join_matches_exactly_one_version(engine):
    total = val(q(engine, "rita.risk", metrics=["transaction_count"], period="2025"), "transaction_count")
    by = q(engine, "rita.risk", metrics=["transaction_count"], period="2025", dimensions=["customer_risk.risk_rating"])
    assert sum(r["transaction_count"] for r in by.rows) == total
    assert all(r["customer_risk.risk_rating"] is not None for r in by.rows)


def test_overlapping_type2_versions_refused(variant):
    e = variant(edit_data={"customer_risk": "UPDATE t SET valid_to = NULL"})
    with pytest.raises(DataIntegrityError, match="overlap"):
        q(e, "rita.risk", metrics=["transaction_count"], period="2025", dimensions=["customer_risk.risk_rating"])


def test_duplicate_dimension_key_refused(variant):
    e = variant(edit_data={"branch": "INSERT INTO t SELECT * FROM t WHERE branch_id = 3"})
    with pytest.raises(DataIntegrityError, match="more than once"):
        q(e, metrics=["deposit_balance"], period="2025-12", dimensions=["branch.region"])


def test_ragged_hierarchy(engine):
    total = val(q(engine, metrics=["deposit_balance"], period="2025-12"), "deposit_balance")
    lvl2 = q(engine, metrics=["deposit_balance"], period="2025-12", dimensions=["org@2"])
    lvl3 = q(engine, metrics=["deposit_balance"], period="2025-12", dimensions=["org@3"])
    assert {r["org@2"] for r in lvl2.rows} == {"Acme Bank N.A.", "Acme Private Bank"}
    assert "Acme Private Bank" in {r["org@3"] for r in lvl3.rows}   # no region below it: reported at its own level
    for res in (lvl2, lvl3):
        assert abs(sum(r["deposit_balance"] for r in res.rows) - total) <= D("0.05")


# ---------------------------------------------------------------- gap 8: definitions over time

def test_effective_dated_definitions(engine):
    q2 = q(engine, metrics=["active_customers"], period="2025Q2")
    q4 = q(engine, metrics=["active_customers"], period="2025Q4")
    assert q2.meta["definitions"]["active_customers"]["version"] == 1
    assert q4.meta["definitions"]["active_customers"]["version"] == 2
    old_rule = q(engine, metrics=["active_customers"], period="2025Q4", definitions_as_of="2025-06-30")
    assert old_rule.meta["definitions"]["active_customers"]["version"] == 1
    assert val(old_rule, "active_customers") >= val(q4, "active_customers")


def test_no_definition_before_first_version(engine):
    with pytest.raises(QueryError, match="no definition in force"):
        q(engine, metrics=["active_customers"], period="2023-12")


def test_parameters_are_typed(engine):
    with pytest.raises(Exception, match="not a valid decimal"):
        q(engine, metrics=["active_customers"], period="2025Q4", parameters={"min_activity_amount": "five"})
    a = val(q(engine, metrics=["active_customers"], period="2025Q4", parameters={"min_activity_amount": "1000"}),
            "active_customers")
    assert a < val(q(engine, metrics=["active_customers"], period="2025Q4"), "active_customers")


def test_filters_are_typed(engine):
    r = q(engine, metrics=["transaction_count"], period="2025",
          filters=[{"field": "txn.txn_date", "op": "between", "values": ["2025-03-01", "2025-03-31"]}])
    assert val(r, "transaction_count") == val(q(engine, metrics=["transaction_count"], period="2025-03"), "transaction_count")
