import asyncio
import json

import pytest

from certus.cli import main
from certus.decisions import Ledger, evaluate_rules, replay, run_decision
from certus.errors import AccessDenied
from certus.model import load_model
from certus.ossie import export_ossie, import_ossie, validate_ossie


def test_decision_is_deterministic_and_explained(engine):
    a = run_decision(engine, "liquidity_watch", period="2025-12", principal="tess.treasury").record
    b = run_decision(engine, "liquidity_watch", period="2025-12", principal="tess.treasury").record
    assert a["decision_id"] == b["decision_id"] and a["result_hash"] == b["result_hash"]
    west = next(o for o in a["outcomes"] if o["branch.region"] == "West")
    assert west["outcome"] == "AMBER" and "L2" in west["reason"]


def test_restatement_changes_decision_but_old_one_replays(engine, tmp_path):
    led = Ledger(tmp_path / "l.jsonl")
    before = run_decision(engine, "liquidity_watch", period="2025-12", principal="tess.treasury",
                          known_at="2026-01-05T00:00:00", ledger=led).record
    after = run_decision(engine, "liquidity_watch", period="2025-12", principal="tess.treasury", ledger=led).record
    west = lambda r: next(o["outcome"] for o in r["outcomes"] if o["branch.region"] == "West")  # noqa: E731
    assert (west(before), west(after)) == ("RED", "AMBER")
    rep = replay(engine, before, principal="audrey.audit", ledger=led)
    assert rep["verdict"] == "IDENTICAL"
    assert led.verify()["valid"] and led.verify()["entries"] == 3


def test_append_only_correction_keeps_replay_identical_but_in_place_edit_is_detected(variant):
    e = variant()
    rec = run_decision(e, "liquidity_watch", period="2025-12", principal="tess.treasury",
                       known_at="2026-01-20T00:00:00").record
    appended = variant(edit_data={"balance_snapshot": "INSERT INTO t SELECT account_id, snapshot_date, balance * 2, "
                                  "TIMESTAMP '2026-02-01 00:00:00' FROM t WHERE snapshot_date = DATE '2025-12-31'"})
    assert replay(appended, rec, principal="tess.treasury")["verdict"] == "IDENTICAL"
    edited = variant(edit_data={"balance_snapshot": "UPDATE t SET balance = balance * 2 WHERE snapshot_date = DATE '2025-12-31'"})
    rep = replay(edited, rec, principal="tess.treasury")
    assert rep["verdict"] == "DIFFERENT" and "data_hash" in rep["changed"] and rep["differences"]


def test_missing_input_never_falls_through_to_default(engine):
    dec = engine.model.decisions["liquidity_watch"]
    out = evaluate_rules(dec, {"loan_to_deposit_ratio": None, "deposit_balance": None,
                               "ldr_red": dec and engine.model.params["ldr_red"].default,
                               "ldr_amber": engine.model.params["ldr_amber"].default})
    assert out["outcome"] == "DATA_GAP"


def test_decision_permissions_and_lock(engine, variant):
    with pytest.raises(AccessDenied, match="may not run"):
        run_decision(engine, "card_limit_action", period="2025-12", principal="tess.treasury")
    assert run_decision(engine, "liquidity_watch", period="2025-12", principal="claude.agent").record["summary"]
    with pytest.raises(AccessDenied, match="agents may not run"):
        run_decision(engine, "aml_channel_monitoring", period="2025Q4", principal="claude.agent")
    unlocked = variant(lock=False)
    with pytest.raises(AccessDenied, match="model lock"):
        run_decision(unlocked, "liquidity_watch", period="2025-12", principal="tess.treasury")


def test_ledger_tamper_detection(engine, tmp_path):
    led = Ledger(tmp_path / "l.jsonl")
    for period in ["2025-10", "2025-11", "2025-12"]:
        run_decision(engine, "liquidity_watch", period=period, principal="tess.treasury", ledger=led)
    assert led.verify()["valid"]
    lines = led.path.read_text().splitlines()
    led.path.write_text("\n".join([lines[0], lines[1].replace('"RED"', '"GREEN"'), lines[2]]) + "\n")
    assert led.verify() == {"valid": False, "entries": 3, "broken_at": 2,
                            "reason": "entry content does not match its hash: it was edited"}
    led.path.write_text("\n".join([lines[0], lines[2]]) + "\n")
    assert led.verify()["broken_at"] == 3 and "chain broken" in led.verify()["reason"]


def test_ossie_export_is_valid_and_round_trips(engine):
    doc, losses = export_ossie(engine.model)
    assert validate_ossie(doc) == []
    assert any("semi-additive" in loss for loss in losses)
    raw, notes = import_ossie(json.loads(json.dumps(doc)))
    assert raw == engine.model.raw and "lossless" in notes[0]


def test_plain_ossie_import_splits_ratios_into_own_grain_components(tmp_path):
    doc = {"version": "0.2.0.dev0", "name": "Shop", "datasets": [
        {"name": "orders", "source": "orders", "primary_key": ["id"], "fields": [
            {"name": "id", "expression": {"sql": "id"}}, {"name": "amount", "expression": {"sql": "amount"}},
            {"name": "store_id", "expression": {"sql": "store_id"}}]},
        {"name": "stores", "source": "stores", "primary_key": ["id"], "fields": [
            {"name": "id", "expression": {"sql": "id"}}, {"name": "staff", "expression": {"sql": "staff"}}]}],
        "relationships": [{"name": "o_s", "from": "orders", "to": "stores", "from_columns": ["store_id"], "to_columns": ["id"]}],
        "metrics": [{"name": "sales_per_staff", "expression": {"sql": "SUM(orders.amount) / NULLIF(SUM(stores.staff), 0)"}}]}
    raw, notes = import_ossie(doc)
    names = [m["name"] for m in raw["metrics"]]
    assert names == ["sales_per_staff_numerator", "sales_per_staff_denominator", "sales_per_staff"]
    p = tmp_path / "shop.certus.yaml"
    import yaml
    p.write_text(yaml.safe_dump(raw))
    assert load_model(p).metrics["sales_per_staff"].versions[0].kind == "derived"


def test_cli(demo_dir, capsys, monkeypatch):
    monkeypatch.chdir(demo_dir)
    assert main(["query", "--as", "tess.treasury", "-m", "deposit_balance", "-p", "2025-12", "--json"]) == 0
    out = json.loads(capsys.readouterr().out)
    assert out["rows"][0]["deposit_balance"]
    assert main(["query", "--as", "ana.analyst", "-m", "aml_flag_rate", "-p", "2025"]) == 2
    assert "refused [classified]" in capsys.readouterr().err
    assert main(["decide", "liquidity_watch", "--as", "tess.treasury", "-p", "2025-12"]) == 0
    assert main(["replay", "1", "--as", "audrey.audit"]) == 0
    assert main(["ledger", "verify"]) == 0


def test_mcp_tools(demo_dir):
    pytest.importorskip("mcp")
    from certus.mcp_server import build_server
    from certus.workspace import open_workspace
    ws = open_workspace(str(demo_dir / "acme_bank.certus.yaml"))
    srv = build_server(ws, "claude.agent")

    async def call(name, args):
        res = await srv.call_tool(name, args)
        payload = res[1] if isinstance(res, tuple) else res
        return payload.get("result", payload) if isinstance(payload, dict) else json.loads(payload[0].text)

    metrics = asyncio.run(call("list_metrics", {}))
    names = {m["name"] for m in metrics["metrics"]}
    assert "deposit_balance" in names and "aml_flag_rate" not in names and "experimental_engagement_score" not in names
    r = asyncio.run(call("query", {"metrics": ["deposit_balance"], "period": "2025-12", "dimensions": ["customer.email"],
                                   "limit": 5}))
    assert r["refused"] is True
    d = asyncio.run(call("run_decision", {"name": "liquidity_watch", "period": "2025-12"}))
    assert asyncio.run(call("verify_decision", {"decision_id": d["decision_id"][:12]}))["verdict"] == "IDENTICAL"
