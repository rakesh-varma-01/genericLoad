import shutil
from pathlib import Path

import duckdb
import pytest
import yaml

from certus.decisions import Ledger
from certus.engine import Engine
from certus.model import load_model, lock_model
from certus.workspace import init_demo


@pytest.fixture(scope="session")
def demo_dir(tmp_path_factory) -> Path:
    d = tmp_path_factory.mktemp("acme")
    init_demo(d, "full")
    lock_model(load_model(d / "acme_bank.certus.yaml"), "pytest")
    return d


@pytest.fixture(scope="session")
def engine(demo_dir) -> Engine:
    return Engine(load_model(demo_dir / "acme_bank.certus.yaml"), demo_dir / "principals.yaml")


@pytest.fixture
def variant(demo_dir, tmp_path):
    """Copy the demo, optionally edit the model (a function on the raw dict) or the data (SQL per table)."""
    counter = [0]

    def make(edit_model=None, edit_data: dict[str, str] | None = None, lock: bool = True) -> Engine:
        counter[0] += 1
        dst = tmp_path / f"v{counter[0]}"
        shutil.copytree(demo_dir, dst, ignore=shutil.ignore_patterns("*.ledger.jsonl", "*.lock.json"))
        mp = dst / "acme_bank.certus.yaml"
        if edit_model:
            raw = yaml.safe_load(mp.read_text())
            edit_model(raw)
            mp.write_text(yaml.safe_dump(raw, sort_keys=False))
        for table, sql in (edit_data or {}).items():
            path = dst / "data" / f"{table}.parquet"
            tmp = dst / "data" / f"{table}.new.parquet"
            con = duckdb.connect()
            con.execute(f"CREATE TABLE t AS SELECT * FROM read_parquet('{path}')")
            con.execute(sql)
            con.execute(f"COPY t TO '{tmp}' (FORMAT parquet)")
            con.close()
            tmp.replace(path)
        m = load_model(mp)
        if lock:
            lock_model(m, "pytest")
        e = Engine(m, dst / "principals.yaml")
        e.ledger = Ledger(dst / "test.ledger.jsonl")
        return e
    return make


def q(engine, principal="tess.treasury", **req):
    return engine.query(req, principal)


def val(res, metric, **where):
    rows = [r for r in res.rows if all(r.get(k) == v for k, v in where.items())]
    assert len(rows) == 1, (where, res.rows)
    return rows[0][metric]
