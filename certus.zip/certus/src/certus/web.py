"""Local decision cockpit: a single-page app served on 127.0.0.1 with the standard library.

Identity is chosen in the page (like header auth), so the server binds to localhost only and
must not be exposed on a network. Every call still goes through the same governance, and every
decision run is written to the same ledger as the CLI.
"""
from __future__ import annotations

import json
import threading
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from importlib import resources
from urllib.parse import parse_qs, urlparse

from .engine import _jsonable
from .errors import CertusError
from .workspace import Workspace


def _meta(ws: Workspace) -> dict:
    m = ws.model
    return {
        "model": {"name": m.name, "version": m.version, "hash": m.hash, "owner": m.owner,
                  "description": m.description, "currency": m.reporting_currency, "lock": m.lock_status()},
        "watermark": ws.engine.watermark(),
        "principals": [{"name": p.name, "display": p.display, "roles": p.roles, "kind": p.kind}
                       for p in ws.engine.directory.values()],
        "metrics": [{"name": n, "unit": x.unit, "status": x.status, "description": x.description,
                     "classification": sorted(x.classification), "versions": len(x.versions)}
                    for n, x in m.metrics.items()],
        "dimensions": [f"{d.name}.{f.name}" for d in m.datasets.values() for f in d.fields.values() if f.dimension]
                      + [f"time:{g}" for g in ["month", "quarter", "year"]]
                      + [f"{h.name}@{i}" for h in m.hierarchies.values() for i in range(1, len(h.levels) + 1)],
        "decisions": [{"name": n, "version": d.version, "status": d.status, "owner": d.owner,
                       "approved_by": d.approved_by, "description": d.description, "grain": d.grain,
                       "metrics": d.metrics,
                       "parameters": {k: _jsonable(m.params[k].default) for k in d.params},
                       "parameter_help": {k: m.params[k].description for k in d.params},
                       "rules": [{"id": r.id, "when": r.when.text, "outcome": r.outcome, "action": r.action}
                                 for r in d.rules],
                       "default": {"id": d.default.id, "outcome": d.default.outcome},
                       "on_missing": {"id": d.on_missing.id, "outcome": d.on_missing.outcome}}
                      for n, d in m.decisions.items()],
    }


def serve(ws: Workspace, host: str = "127.0.0.1", port: int = 8765, open_browser: bool = True) -> None:
    if host not in {"127.0.0.1", "localhost", "::1"}:
        raise CertusError("the cockpit trusts the identity chosen in the page, so it only serves on localhost",
                          code="unsafe_host")
    page = resources.files("certus.static").joinpath("index.html").read_text()
    lock = threading.Lock()

    class Handler(BaseHTTPRequestHandler):
        def log_message(self, fmt, *args):  # quiet
            pass

        def _send(self, code: int, body, ctype="application/json"):
            data = body.encode() if isinstance(body, str) else json.dumps(body, default=_jsonable).encode()
            self.send_response(code)
            self.send_header("Content-Type", ctype + "; charset=utf-8")
            self.send_header("Content-Length", str(len(data)))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.wfile.write(data)

        def _host_ok(self) -> bool:
            # refuse DNS-rebinding: a page on another domain that resolves to 127.0.0.1
            return self.headers.get("Host") in {f"{host}:{port}", f"localhost:{port}", f"127.0.0.1:{port}"}

        def do_GET(self):
            if not self._host_ok():
                return self._send(403, {"error": "unexpected Host header"})
            u = urlparse(self.path)
            try:
                with lock:
                    if u.path in {"/", "/index.html"}:
                        return self._send(200, page, "text/html")
                    if u.path == "/api/meta":
                        return self._send(200, _meta(ws))
                    if u.path == "/api/ledger":
                        entries = ws.ledger.entries()
                        return self._send(200, {"entries": [_summ(e) for e in reversed(entries)],
                                                "verify": ws.ledger.verify(), "path": str(ws.ledger.path)})
                    if u.path == "/api/ledger/entry":
                        q = parse_qs(u.query)
                        return self._send(200, ws.ledger.find(q.get("id", [""])[0]))
                return self._send(404, {"error": "not found"})
            except CertusError as e:
                return self._send(400, e.to_dict())

        def do_POST(self):
            if not self._host_ok():
                return self._send(403, {"error": "unexpected Host header"})
            u = urlparse(self.path)
            if self.headers.get("Origin") not in (None, f"http://{host}:{port}", f"http://localhost:{port}"):
                return self._send(403, {"error": "cross-origin requests are refused"})
            try:
                body = json.loads(self.rfile.read(int(self.headers.get("Content-Length", 0))) or b"{}")
                with lock:
                    if u.path == "/api/query":
                        req = dict(body.get("request") or {})
                        if body.get("role"):
                            req["role"] = body["role"]
                        return self._send(200, ws.engine.query(req, body.get("principal")).to_dict())
                    if u.path == "/api/decide":
                        from .decisions import run_decision
                        run = run_decision(ws.engine, body["name"], period=body["period"],
                                           principal=body.get("principal"), role=body.get("role"),
                                           known_at=body.get("known_at") or None,
                                           parameters=body.get("parameters") or {},
                                           ledger=ws.ledger if body.get("record", True) else None)
                        return self._send(200, {"record": run.record,
                                                "ledger_seq": run.ledger_entry and run.ledger_entry["seq"]})
                    if u.path == "/api/replay":
                        from .decisions import replay
                        entry = ws.ledger.find(str(body["id"]))
                        return self._send(200, replay(ws.engine, entry["payload"], principal=body.get("principal"),
                                                      ledger=ws.ledger))
                return self._send(404, {"error": "not found"})
            except CertusError as e:
                return self._send(400, e.to_dict())
            except (KeyError, ValueError, json.JSONDecodeError) as e:
                return self._send(400, {"error": f"bad request: {e}", "code": "bad_request"})

    httpd = ThreadingHTTPServer((host, port), Handler)
    url = f"http://{host}:{port}/"
    print(f"Certus cockpit for {ws.model.name} {ws.model.version} at {url}  (Ctrl+C to stop)")
    if open_browser:
        threading.Timer(0.5, lambda: webbrowser.open(url)).start()
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        httpd.server_close()


def _summ(e: dict) -> dict:
    p = e["payload"]
    return {"seq": e["seq"], "kind": e["kind"], "logged_at": e["logged_at"], "principal": e["principal"],
            "principal_kind": e.get("principal_kind"), "decision": p.get("decision"), "period": p.get("period"),
            "known_at": p.get("known_at"), "summary": p.get("summary"), "decision_id": p.get("decision_id"),
            "verdict": p.get("verdict"), "approved_by": p.get("approved_by"), "model_hash": p.get("model_hash"),
            "entry_hash": e["entry_hash"]}
