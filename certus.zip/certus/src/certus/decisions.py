"""Deterministic decisions and their tamper-evident ledger.

A decision is a certified, versioned rule table evaluated over certified metrics. Rules are
tried in order and the first one that holds wins. If a rule cannot be evaluated because an
input is missing, evaluation stops and the decision's ``on_missing`` outcome is returned:
a gap in the data is never allowed to fall through to the default.

Every run produces a record whose ``decision_id`` is a hash of everything that determines the
answer (decision version, model hash, period, knowledge cut-off, parameters, role and the hash
of the visible data). The same inputs therefore always produce the same id and the same
``result_hash``, and ``replay`` proves it. Records are appended to a hash-chained JSONL ledger;
editing or deleting any line breaks the chain and ``verify`` reports where.
"""
from __future__ import annotations

import datetime as dt
import json
from dataclasses import dataclass
from decimal import Decimal
from pathlib import Path
from typing import Any

from . import __version__
from .engine import Engine, Request, _jsonable, canonical_hash
from .errors import AccessDenied, LedgerError, QueryError
from .governance import check_decision, resolve_access
from .model import Principal


@dataclass
class DecisionRun:
    record: dict
    ledger_entry: dict | None


def evaluate_rules(dec, env: dict[str, Any]) -> dict:
    for r in dec.rules:
        res = r.when.evaluate(env)
        if res is None:
            missing = sorted(n for n in r.when.names if env.get(n) is None)
            return {"outcome": dec.on_missing.outcome, "rule": dec.on_missing.id, "action": dec.on_missing.action,
                    "severity": dec.on_missing.severity,
                    "reason": f"rule {r.id} ({r.when.text}) could not be evaluated: missing {', '.join(missing) or 'input'}"}
        if res is True:
            return {"outcome": r.outcome, "rule": r.id, "action": r.action, "severity": r.severity,
                    "reason": f"rule {r.id} holds: {r.when.text} with " + _bound(r.when.names, env)}
    d = dec.default
    tried = "; ".join(f"{r.id} ({r.when.text})" for r in dec.rules)
    return {"outcome": d.outcome, "rule": d.id, "action": d.action, "severity": d.severity,
            "reason": f"no rule held ({tried}) with " + _bound(set().union(*[r.when.names for r in dec.rules]), env)}


def _bound(names, env) -> str:
    return ", ".join(f"{n}={_jsonable(env.get(n))}" for n in sorted(names))


def _may_run(engine: Engine, role: str, decision: str) -> bool:
    import fnmatch
    return any(fnmatch.fnmatchcase(decision, pat) for pat in engine.model.roles[role].allow_decisions)


def run_decision(engine: Engine, name: str, *, period: str, principal: str | Principal | None, role: str | None = None,
                 known_at: str | None = None, parameters: dict | None = None, ledger: "Ledger | None" = None,
                 allow_unlocked: bool = False, _replay: bool = False) -> DecisionRun:
    m = engine.model
    if name not in m.decisions:
        raise QueryError(f"unknown decision {name!r}")
    dec = m.decisions[name]
    p = principal if isinstance(principal, Principal) else engine.principal(principal)
    access = resolve_access(m, p, role)
    if not _replay:  # a replay was authorised against the replayer's own role in replay()
        check_decision(m, access, name)
    lock = m.lock_status()
    if dec.status == "certified" and not lock["locked"] and not allow_unlocked:
        raise AccessDenied(f"certified decision {name} needs an approved model lock ({lock['reason']}); run "
                           f"`certus lock` after review", code="model_not_locked")
    if dec.status == "deprecated":
        raise AccessDenied(f"decision {name} is deprecated", code="deprecated")
    extra = set(parameters or {}) - set(dec.params)
    if extra:
        raise QueryError(f"decision {name} does not take parameters {sorted(extra)} (declared: {dec.params})")
    req = Request(metrics=list(dec.metrics), period=period, dimensions=list(dec.grain), filters=list(dec.filters),
                  known_at=known_at or engine.watermark(), parameters=dict(parameters or {}), role=access.role)
    res = engine._run(req, access, decision_rows=dec.max_rows)
    if len(res.rows) > dec.max_rows:
        raise QueryError(f"decision {name} produced {len(res.rows)} rows, above its max_rows {dec.max_rows}")
    params = res.meta["parameters"]
    outcomes = []
    for row in res.rows:
        env: dict[str, Any] = {k: m.params[k].coerce(v) for k, v in params.items()}
        env.update({mn: row[mn] for mn in dec.metrics})
        verdict = evaluate_rules(dec, env)
        outcomes.append({**{g: _jsonable(row[g]) for g in dec.grain},
                         "inputs": {mn: _jsonable(row[mn]) for mn in dec.metrics}, **verdict})
    summary: dict[str, int] = {}
    for o in outcomes:
        summary[o["outcome"]] = summary.get(o["outcome"], 0) + 1
    fingerprint = {
        "decision": name, "decision_version": dec.version, "model_hash": res.meta["model_hash"],
        "period": period, "known_at": res.meta["known_at"], "parameters": params, "role": access.role,
        "data_hash": res.meta["data_hash"],
    }
    record = {
        "decision_id": canonical_hash(fingerprint),
        "decision": name, "decision_version": dec.version, "decision_status": dec.status,
        "owner": dec.owner, "approved_by": dec.approved_by, "description": dec.description,
        "model": m.name, "model_version": m.version, "model_hash": res.meta["model_hash"],
        "model_lock": lock.get("lock") if lock["locked"] else {"locked": False, "reason": lock["reason"]},
        "period": period, "period_end": res.meta["period_end"], "known_at": res.meta["known_at"],
        "known_at_source": "request" if known_at else "data watermark",
        "definitions_as_of": res.meta["definitions_as_of"], "definitions": res.meta["definitions"],
        "parameters": params, "role": access.role, "grain": dec.grain,
        "rules": [{"id": r.id, "when": r.when.text, "outcome": r.outcome} for r in dec.rules]
                 + [{"id": dec.default.id, "when": "default", "outcome": dec.default.outcome},
                    {"id": dec.on_missing.id, "when": "missing input", "outcome": dec.on_missing.outcome}],
        "data_hashes": res.meta["data_hashes"], "data_hash": res.meta["data_hash"],
        "warnings": res.meta["warnings"], "summary": dict(sorted(summary.items())),
        "outcomes": outcomes, "result_hash": canonical_hash(outcomes),
        "engine": f"certus {__version__}",
    }
    entry = ledger.append("decision", record, access.principal) if ledger else None
    return DecisionRun(record, entry)


def replay(engine: Engine, record: dict, *, principal: str | Principal | None, ledger: "Ledger | None" = None) -> dict:
    """Re-run a recorded decision with the same inputs and report whether the answer is identical.

    The replayer must be allowed to run the decision in their own role. The re-run then applies
    the *recorded* role's rules (its row filters), because that is what produced the original.
    """
    p = principal if isinstance(principal, Principal) else engine.principal(principal)
    own = resolve_access(engine.model, p, None)
    allowed = [r for r in p.roles if _may_run(engine, r, record["decision"])] if p else []
    if not allowed and not (p and record["role"] in p.roles):
        raise AccessDenied(f"{p.name if p else 'unknown'} may not replay decision {record['decision']}",
                           code="decision_denied")
    if record["role"] not in engine.model.roles:
        raise QueryError(f"role {record['role']} no longer exists in the model")
    proxy = Principal(f"{own.principal.name} replaying as {record['role']}", [record["role"]], own.principal.kind)
    run = run_decision(engine, record["decision"], period=record["period"], principal=proxy, role=record["role"],
                       known_at=record["known_at"], parameters=_decision_params(engine, record),
                       allow_unlocked=True, _replay=True)
    new = run.record
    checks = {
        "decision_version": record["decision_version"] == new["decision_version"],
        "model_hash": record["model_hash"] == new["model_hash"],
        "data_hash": record["data_hash"] == new["data_hash"],
        "result_hash": record["result_hash"] == new["result_hash"],
    }
    changed = [k for k, ok in checks.items() if not ok]
    if not changed:
        verdict = "IDENTICAL"
    elif checks["result_hash"]:
        verdict = "SAME_OUTCOMES_DIFFERENT_INPUTS"
    else:
        verdict = "DIFFERENT"
    diffs = []
    if not checks["result_hash"]:
        old = {json.dumps({g: o[g] for g in record["grain"]}, sort_keys=True): o for o in record["outcomes"]}
        for o in new["outcomes"]:
            k = json.dumps({g: o[g] for g in record["grain"]}, sort_keys=True)
            before = old.pop(k, None)
            if before is None or before["outcome"] != o["outcome"] or before["inputs"] != o["inputs"]:
                diffs.append({"key": json.loads(k), "before": before and {"outcome": before["outcome"],
                              "inputs": before["inputs"]}, "after": {"outcome": o["outcome"], "inputs": o["inputs"]}})
        diffs += [{"key": json.loads(k), "before": {"outcome": o["outcome"], "inputs": o["inputs"]}, "after": None}
                  for k, o in old.items()]
    report = {"decision_id": record["decision_id"], "replayed_id": new["decision_id"], "verdict": verdict,
              "checks": checks, "changed": changed, "differences": diffs[:50],
              "explanation": _explain(verdict, changed)}
    if ledger:
        p = principal if isinstance(principal, Principal) else engine.principal(principal)
        ledger.append("replay", report, p)
    return report


def _decision_params(engine: Engine, record: dict) -> dict:
    dec = engine.model.decisions.get(record["decision"])
    if not dec:
        raise QueryError(f"decision {record['decision']} no longer exists in the model")
    return {k: v for k, v in record["parameters"].items() if k in dec.params}


def _explain(verdict: str, changed: list[str]) -> str:
    if verdict == "IDENTICAL":
        return ("Same model, same visible data, same parameters and the same outcomes, byte for byte. "
                "The recorded decision is reproducible.")
    why = {"model_hash": "the model definition changed", "data_hash": "the data visible at the recorded "
           "knowledge cut-off changed (rows were edited in place rather than appended as new versions)",
           "decision_version": "the decision rules were re-versioned", "result_hash": "outcomes differ"}
    return "Not reproducible as recorded: " + "; ".join(why[c] for c in changed if c in why) + "."


# --------------------------------------------------------------------------- ledger

class Ledger:
    """Append-only, hash-chained JSON Lines file."""

    GENESIS = "0" * 64

    def __init__(self, path: str | Path):
        self.path = Path(path)

    def entries(self) -> list[dict]:
        if not self.path.exists():
            return []
        out = []
        for i, line in enumerate(self.path.read_text().splitlines(), 1):
            if line.strip():
                try:
                    out.append(json.loads(line))
                except json.JSONDecodeError:
                    raise LedgerError(f"ledger line {i} is not valid JSON") from None
        return out

    def append(self, kind: str, payload: dict, principal: Principal | None) -> dict:
        prev = self.entries()
        entry = {
            "seq": len(prev) + 1,
            "kind": kind,
            "logged_at": dt.datetime.now(dt.timezone.utc).isoformat(timespec="seconds"),
            "principal": principal.name if principal else None,
            "principal_kind": principal.kind if principal else None,
            "prev_hash": prev[-1]["entry_hash"] if prev else self.GENESIS,
            "payload": payload,
        }
        entry["entry_hash"] = canonical_hash(entry)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with self.path.open("a") as fh:
            fh.write(json.dumps(entry, sort_keys=True, default=_jsonable) + "\n")
        return entry

    def verify(self) -> dict:
        prev = self.GENESIS
        entries = self.entries()
        for e in entries:
            body = {k: v for k, v in e.items() if k != "entry_hash"}
            if e.get("prev_hash") != prev:
                return {"valid": False, "entries": len(entries), "broken_at": e.get("seq"),
                        "reason": "chain broken: an earlier entry was removed, reordered or edited"}
            if canonical_hash(body) != e.get("entry_hash"):
                return {"valid": False, "entries": len(entries), "broken_at": e.get("seq"),
                        "reason": "entry content does not match its hash: it was edited"}
            prev = e["entry_hash"]
        return {"valid": True, "entries": len(entries), "head": prev}

    def find(self, decision_id_or_seq: str) -> dict:
        for e in reversed(self.entries()):
            if e["kind"] != "decision":
                continue
            if str(e["seq"]) == str(decision_id_or_seq) or e["payload"]["decision_id"].startswith(str(decision_id_or_seq)):
                return e
        raise LedgerError(f"no decision {decision_id_or_seq!r} in {self.path}")
