"""Apache Ossie interchange.

Export writes a valid Ossie 0.2.0.dev0 document: datasets, fields, relationships and one
model-scoped metric per Certus metric (its definition in force today), in the portable
OSSIE_SQL_2026 dialect. Everything Ossie cannot express yet is listed in a loss report and
carried verbatim in a ``CERTUS`` custom extension, so Certus -> Ossie -> Certus is lossless.

Import accepts any Ossie document. If it carries a CERTUS extension, the original model is
restored exactly; otherwise datasets, fields and relationships are mapped and every simple
aggregate metric becomes a *draft* Certus metric for a human to review and certify.
"""
from __future__ import annotations

import json
import re
from importlib import resources
from typing import Any

from .expr import lint_and_rewrite
from .model import Model

OSSIE_VERSION = "0.2.0.dev0"
VENDOR = "CERTUS"


def ossie_schema() -> dict:
    return json.loads(resources.files("certus.schemas").joinpath("ossie-schema.json").read_text())


def _ai(v: Any) -> Any:
    if v is None or isinstance(v, str):
        return v
    if isinstance(v, dict):
        return v
    return str(v)


def export_ossie(model: Model) -> tuple[dict, list[str]]:
    losses: list[str] = []
    doc: dict[str, Any] = {"version": OSSIE_VERSION, "name": model.name}
    if model.description:
        doc["description"] = model.description
    if model.ai_context:
        doc["ai_context"] = _ai(model.ai_context)
    datasets = []
    for ds in model.datasets.values():
        d: dict[str, Any] = {"name": ds.name, "source": ds.source}
        if ds.primary_key:
            d["primary_key"] = list(ds.primary_key)
        if ds.description:
            d["description"] = ds.description
        if ds.ai_context:
            d["ai_context"] = _ai(ds.ai_context)
        fields = []
        for f in ds.fields.values():
            fo: dict[str, Any] = {"name": f.name, "expression": {"sql": f.expr}}
            if f.dimension:
                fo["dimension"] = {"is_time": f.name == ds.valid_time or f.datatype in {"Date", "DateTime", "DateTimeTz"}}
            if f.datatype:
                fo["datatype"] = f.datatype
            if f.description:
                fo["description"] = f.description
            if f.ai_context:
                fo["ai_context"] = _ai(f.ai_context)
            fields.append(fo)
            if f.classification:
                losses.append(f"{ds.name}.{f.name}: classification {sorted(f.classification)} has no Ossie field")
        d["fields"] = fields
        datasets.append(d)
        if ds.knowledge_time or ds.deleted:
            losses.append(f"{ds.name}: bitemporal versioning (knowledge_time/deleted) has no Ossie form")
        if ds.scd:
            losses.append(f"{ds.name}: type-2 validity (valid_from/valid_to) has no Ossie form")
        if ds.bridge_weight:
            losses.append(f"{ds.name}: allocation bridge weight has no Ossie form; Ossie consumers will see "
                          f"many-to-many joins and may double count")
    doc["datasets"] = datasets
    rels = []
    for r in model.relationships:
        rels.append({"name": r.name, "from": r.src, "to": r.dst, "from_columns": r.src_cols, "to_columns": r.dst_cols})
        if r.as_of:
            losses.append(f"relationship {r.name}: as-of (type-2) join condition has no Ossie form")
    doc["relationships"] = rels

    metrics = []
    for mn, met in model.metrics.items():
        latest = met.versions[-1]
        try:
            sql = _metric_sql(model, mn, latest)
        except ValueError as e:
            losses.append(f"metric {mn}: not exported: {e}")
            continue
        mo: dict[str, Any] = {"name": mn, "expression": {"sql": sql}}
        if met.description:
            mo["description"] = met.description
        mo["datatype"] = "Integer" if met.unit == "count" and latest.kind == "base" else "Decimal"
        if met.ai_context:
            mo["ai_context"] = _ai(met.ai_context)
        metrics.append(mo)
        if len(met.versions) > 1:
            losses.append(f"metric {mn}: only the latest of {len(met.versions)} effective-dated definitions is "
                          f"exported")
        if latest.kind == "derived":
            losses.append(f"metric {mn}: derived formula inlined; Ossie does not guarantee each component is "
                          f"aggregated at its own grain")
        elif latest.additivity == "semi":
            losses.append(f"metric {mn}: semi-additive ({latest.semi_method} snapshot) has no Ossie form; a plain "
                          f"SUM over time would overstate it")
        if latest.currency:
            losses.append(f"metric {mn}: currency conversion ({latest.fx_rate_type or 'default'} rate) has no "
                          f"Ossie form")
    doc["metrics"] = metrics
    losses.append("metric status, owner and approval (certification) have no Ossie form")
    if model.roles or model.decisions or model.params:
        losses.append("roles, row filters, agent policy, parameters and decisions have no Ossie form")
    doc["custom_extensions"] = [{"vendor_name": VENDOR, "data": json.dumps(model.raw, sort_keys=True, default=str)}]
    return doc, sorted(set(losses))


def _metric_sql(model: Model, mn: str, v, depth: int = 0) -> str:
    if depth > 20:
        raise ValueError("derived metrics nest too deeply")
    if v.kind == "derived":
        text = v.formula.text

        def sub(mt: re.Match) -> str:
            name = mt.group(0)
            if name in model.metrics:
                return "(" + _metric_sql(model, name, model.metrics[name].versions[-1], depth + 1) + ")"
            if name in model.params:
                return _literal(model.params[name].default)
            return name
        return re.sub(r"\b[a-z][a-z0-9_]*\b", sub, text)
    home = v.dataset

    def resolve(ds, f):
        return f"{ds or home}.{f}"

    def qualify(text: str) -> str:
        frag = lint_and_rewrite(text, resolve, where=mn)
        out = frag.sql
        for p in frag.params:
            out = out.replace(f"$p_{p}", _literal(model.params[p].default))
        return out

    if v.expr == "*":
        pk = model.datasets[home].primary_key
        arg = f"{home}.{pk[0]}" if pk else "*"
    else:
        arg = qualify(v.expr)
    agg = {"sum": "SUM({})", "count": "COUNT({})", "count_distinct": "COUNT(DISTINCT {})",
           "min": "MIN({})", "max": "MAX({})"}[v.agg].format(arg)
    if v.filter:
        agg += f" FILTER (WHERE {qualify(v.filter)})"
    return agg


def _literal(v: Any) -> str:
    if isinstance(v, str):
        return "'" + v.replace("'", "''") + "'"
    return str(v)


def validate_ossie(doc: dict) -> list[str]:
    try:
        import jsonschema
    except ImportError:  # pragma: no cover
        return ["jsonschema is not installed; install certus[dev] to validate Ossie documents"]
    v = jsonschema.Draft202012Validator(ossie_schema())
    return [f"{'/'.join(map(str, e.absolute_path)) or '<root>'}: {e.message}" for e in v.iter_errors(doc)]


_AGG = re.compile(r"^\s*(SUM|COUNT|MIN|MAX)\s*\(\s*(DISTINCT\s+)?(.+?)\s*\)\s*(?:FILTER\s*\(\s*WHERE\s+(.+)\)\s*)?$",
                  re.IGNORECASE | re.DOTALL)


def import_ossie(doc: dict) -> tuple[dict, list[str]]:
    """Return a raw Certus model document and a report of what needs human review."""
    notes: list[str] = []
    if "semantic_model" in doc and isinstance(doc["semantic_model"], list):
        if len(doc["semantic_model"]) != 1:
            raise ValueError("this Ossie 0.1 document holds several models; split it first")
        doc = {"version": OSSIE_VERSION, **doc["semantic_model"][0]}
        notes.append("converted from the Ossie 0.1 semantic_model array shape")
    for ext in doc.get("custom_extensions") or []:
        if ext.get("vendor_name") == VENDOR:
            return json.loads(ext["data"]), ["restored from the CERTUS extension: lossless"]

    def expr_of(obj: dict) -> str | None:
        e = obj.get("expression") or {}
        if e.get("sql"):
            return e["sql"]
        for d in e.get("dialects") or []:
            if d.get("dialect") in {"OSSIE_SQL_2026", "ANSI_SQL"}:
                return d["expression"]
        return None

    raw: dict[str, Any] = {"certus": "0.1", "model": {"name": _snake(doc["name"]), "version": "0.1.0",
                                                       "description": doc.get("description", "")}}
    if doc.get("ai_context"):
        raw["model"]["ai_context"] = doc["ai_context"]
    raw["datasets"] = []
    for d in doc.get("datasets") or []:
        fields = []
        for f in d.get("fields") or []:
            fo: dict[str, Any] = {"name": _snake(f["name"])}
            e = expr_of(f)
            if e and e != f["name"]:
                fo["expr"] = e
            if f.get("datatype") and f["datatype"] not in {"Float", "Time", "Opaque"}:
                fo["datatype"] = f["datatype"]
            elif f.get("datatype") == "Float":
                notes.append(f"{d['name']}.{f['name']}: Float is inexact; review before using it in money metrics")
            if f.get("dimension") is not None:
                fo["dimension"] = True
            if f.get("description"):
                fo["description"] = f["description"]
            fields.append(fo)
        ds: dict[str, Any] = {"name": _snake(d["name"]), "source": d["source"], "fields": fields}
        if d.get("primary_key"):
            ds["primary_key"] = d["primary_key"]
        raw["datasets"].append(ds)
    raw["relationships"] = [{k: r[k] for k in ("name", "from", "to", "from_columns", "to_columns")}
                            for r in doc.get("relationships") or []]
    metrics = []
    for mt in doc.get("metrics") or []:
        e = (expr_of(mt) or "").strip()
        name = _snake(mt["name"])
        single = _single_agg(e)
        if single:
            md = _draft(name, mt, single, notes)
            if md:
                metrics.append(md)
                notes.append(f"metric {mt['name']}: imported as draft; set its unit (money needs a currency) "
                             f"and certify it")
            continue
        ratio = _ratio(e)
        if ratio:
            num, den = (_draft(f"{name}_numerator", {"name": f"{name}_numerator"}, ratio[0], notes),
                        _draft(f"{name}_denominator", {"name": f"{name}_denominator"}, ratio[1], notes))
            if num and den:
                metrics += [num, den, {"name": name, "status": "draft", "unit": "number",
                                       "description": mt.get("description", ""),
                                       "formula": f"{name}_numerator / {name}_denominator"}]
                notes.append(f"metric {mt['name']}: split into numerator and denominator, each aggregated at its own "
                             f"grain (no fan-out); review and certify")
                continue
        notes.append(f"metric {mt['name']}: {e!r} is not a single aggregate or a ratio of two; recreate it by hand")
    raw["metrics"] = metrics
    return raw, notes


def _balanced(t: str) -> bool:
    depth = 0
    for ch in t:
        depth += ch == "("
        depth -= ch == ")"
        if depth < 0:
            return False
    return depth == 0


def _single_agg(e: str):
    m = _AGG.match(e)
    if not m or not _balanced(m.group(3)) or (m.group(4) and not _balanced(m.group(4))):
        return None
    if re.search(r"\bOVER\s*\(", e, re.IGNORECASE):
        return None
    return m.group(1).upper(), bool(m.group(2)), m.group(3), m.group(4)


def _ratio(e: str):
    depth = 0
    for i, ch in enumerate(e):
        depth += ch == "("
        depth -= ch == ")"
        if ch == "/" and depth == 0:
            num, den = e[:i].strip(), e[i + 1:].strip()
            nm = re.fullmatch(r"NULLIF\s*\((.*),\s*0\s*\)", den, re.IGNORECASE | re.DOTALL)
            if nm:
                den = nm.group(1).strip()
            a, b = _single_agg(num), _single_agg(den)
            return (a, b) if a and b else None
    return None


def _draft(name: str, mt: dict, agg_parts, notes: list[str]) -> dict | None:
    fn, distinct, arg, flt = agg_parts
    dsets = sorted(set(re.findall(r"\b([a-z_][a-z0-9_]*)\.[a-z_]", arg, re.IGNORECASE)))
    if len(dsets) != 1:
        notes.append(f"metric {mt['name']}: cannot tell which dataset {arg!r} is rooted at")
        return None
    home = dsets[0]
    agg = {"SUM": "sum", "MIN": "min", "MAX": "max"}.get(fn) or ("count_distinct" if distinct else "count")
    md: dict[str, Any] = {"name": name, "status": "draft", "unit": "count" if fn == "COUNT" else "number",
                          "description": mt.get("description", ""), "dataset": home, "agg": agg,
                          "expr": re.sub(rf"\b{home}\.", "", arg)}
    if flt:
        md["filter"] = flt
    return md


def _snake(s: str) -> str:
    out = re.sub(r"[^a-z0-9_]", "_", re.sub(r"(?<!^)(?=[A-Z])", "_", s).lower()).strip("_")
    return out if re.match(r"^[a-z]", out) else f"x_{out}"
