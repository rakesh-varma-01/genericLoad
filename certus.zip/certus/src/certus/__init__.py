"""Certus: a deterministic, governed semantic layer and decision engine for banking.

Certus reads and writes Apache Ossie documents and adds what regulated finance needs and
Ossie does not yet define: bitemporal as-of queries, semi-additive balances, currency
conversion, metric composition, effective-dated definitions, governance that travels with
the model, and replayable, hash-chained decision records.
"""

__version__ = "0.1.0"
FORMAT_VERSION = "0.1"
