"""Access decisions, made before any SQL is generated.

Rules travel with the model (roles, classifications, row filters, agent policy); only the
identity directory, which maps people and agents to roles, is environment-specific. Every
check fails closed: a rule that cannot be enforced refuses the request rather than skipping.
"""
from __future__ import annotations

import fnmatch
from dataclasses import dataclass, field

from .errors import AccessDenied
from .model import Model, Principal, metric_closure


@dataclass
class Access:
    principal: Principal
    role: str
    row_filters: list[tuple[str, str]]
    deny_classifications: frozenset[str]
    is_agent: bool
    agent_max_rows: int | None = None
    notes: list[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {"principal": self.principal.name, "kind": self.principal.kind, "role": self.role,
                "row_filters": [{"dataset": d, "predicate": p} for d, p in self.row_filters]}


def resolve_access(model: Model, principal: Principal | None, role: str | None) -> Access:
    if principal is None:
        raise AccessDenied("unknown principal: identities come from the directory file", code="unknown_principal")
    if not principal.roles:
        raise AccessDenied(f"{principal.name} has no roles", code="no_role")
    role = role or principal.roles[0]
    if role not in principal.roles:
        raise AccessDenied(f"{principal.name} is not entitled to role {role!r} (has {principal.roles})",
                           code="role_not_entitled")
    r = model.roles[role]
    deny = set(r.deny_classifications)
    is_agent = principal.kind == "agent"
    max_rows = None
    if is_agent:
        ap = model.agent_policy
        deny |= set(ap.get("deny_classifications") or [])
        max_rows = int(ap.get("max_rows", 1000))
    return Access(principal, role, list(r.row_filters), frozenset(deny), is_agent, max_rows)


def _allowed(patterns: list[str], name: str) -> bool:
    return any(fnmatch.fnmatchcase(name, p) for p in patterns)


def check_metrics(model: Model, access: Access, metrics: list[str], on) -> None:
    role = model.roles[access.role]
    for mn in metrics:
        if mn not in model.metrics:
            raise AccessDenied(f"unknown metric {mn!r}", code="unknown_metric")
        met = model.metrics[mn]
        if met.status == "deprecated":
            raise AccessDenied(f"metric {mn} is deprecated", code="deprecated")
        if access.is_agent and met.status != "certified" and model.agent_policy.get("require_certified", True):
            raise AccessDenied(f"agents may only use certified metrics; {mn} is {met.status}", code="not_certified")
        for dep in [mn] + metric_closure(model, mn, on):
            if not _allowed(role.allow_metrics, dep) or _allowed(role.deny_metrics, dep):
                raise AccessDenied(f"role {access.role} may not use metric {dep}"
                                   + (f" (needed by {mn})" if dep != mn else ""), code="metric_denied")
            bad = model.metrics[dep].classification & access.deny_classifications
            if bad:
                raise AccessDenied(f"metric {dep} is classified {sorted(bad)}; role {access.role}"
                                   f"{' (agent)' if access.is_agent else ''} may not use it", code="classified")


def check_fields(model: Model, access: Access, refs: list[str], what: str) -> None:
    for ref in refs:
        ds, _, f = ref.partition(".")
        fld = model.datasets.get(ds) and model.datasets[ds].fields.get(f)
        if not fld:
            continue  # the planner reports unknown fields with a better message
        bad = (fld.classification | model.datasets[ds].classification) & access.deny_classifications
        if bad:
            raise AccessDenied(f"{what} {ref} is classified {sorted(bad)}; role {access.role}"
                               f"{' (agent)' if access.is_agent else ''} may not use it", code="classified")


def check_decision(model: Model, access: Access, decision: str) -> None:
    role = model.roles[access.role]
    if access.is_agent:
        if decision not in (model.agent_policy.get("allow_decisions") or []):
            raise AccessDenied(f"agents may not run decision {decision}", code="decision_denied")
    if not _allowed(role.allow_decisions, decision):
        raise AccessDenied(f"role {access.role} may not run decision {decision}", code="decision_denied")
