"""Finding the model, identity directory and ledger for a working folder."""
from __future__ import annotations

import os
import shutil
from dataclasses import dataclass
from importlib import resources
from pathlib import Path

from .decisions import Ledger
from .engine import Engine
from .errors import CertusError
from .model import Model, load_model


@dataclass
class Workspace:
    model: Model
    engine: Engine
    ledger: Ledger
    directory_path: Path


def find_model(path: str | None = None) -> Path:
    if path:
        return Path(path)
    if os.environ.get("CERTUS_MODEL"):
        return Path(os.environ["CERTUS_MODEL"])
    found = sorted(Path.cwd().glob("*.certus.yaml"))
    if len(found) == 1:
        return found[0]
    if not found:
        raise CertusError("no *.certus.yaml model here; run `certus init <folder>` or pass --model", code="no_model")
    raise CertusError(f"several models here ({', '.join(p.name for p in found)}); pass --model", code="no_model")


def open_workspace(model: str | None = None, directory: str | None = None, ledger: str | None = None) -> Workspace:
    mp = find_model(model).resolve()
    m = load_model(mp)
    dp = Path(directory or os.environ.get("CERTUS_DIRECTORY") or mp.parent / "principals.yaml")
    if not dp.exists():
        raise CertusError(f"identity directory {dp} not found; pass --directory", code="no_directory")
    lp = Path(ledger or os.environ.get("CERTUS_LEDGER") or mp.with_name(mp.name.replace(".certus.yaml", "")
                                                                         + ".ledger.jsonl"))
    return Workspace(m, Engine(m, dp), Ledger(lp), dp)


def init_demo(folder: str | Path, profile: str = "full") -> dict:
    from .demo.generate import write
    out = Path(folder)
    out.mkdir(parents=True, exist_ok=True)
    demo = resources.files("certus.demo")
    for name in ("acme_bank.certus.yaml", "principals.yaml"):
        target = out / name
        if not target.exists():
            with resources.as_file(demo.joinpath(name)) as src:
                shutil.copy(src, target)
    counts = write(out / "data", profile)
    return {"folder": str(out.resolve()), "rows": counts}
