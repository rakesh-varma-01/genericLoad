"""Expression handling.

Two small, closed languages, both designed so the same input always gives the same output:

* **SQL scalar fragments** (field expressions, metric scalars and filters, row filters). They are
  tokenised, checked against an allow-list, and rewritten so every column reference is
  qualified by the alias the planner chose. Non-deterministic or inexact constructs
  (CURRENT_DATE, RANDOM, APPROX_*, floating-point types, division, subqueries) are refused at
  model load time.

* **Formulas** (derived metrics and decision rules). They are evaluated in Python with
  ``decimal.Decimal`` under a fixed context and round-half-even, so arithmetic is exact and
  identical on every machine and engine. Division by zero yields ``None`` (missing), and
  missing values propagate with SQL-style three-valued logic.
"""
from __future__ import annotations

import ast
import decimal
import re
from dataclasses import dataclass
from decimal import Decimal
from typing import Any, Callable

from .errors import ModelError, QueryError

# --------------------------------------------------------------------------- SQL fragments

ALLOWED_KEYWORDS = {
    "AND", "OR", "NOT", "NULL", "IS", "IN", "BETWEEN", "LIKE", "ILIKE", "CASE", "WHEN", "THEN",
    "ELSE", "END", "TRUE", "FALSE", "AS", "DECIMAL", "NUMERIC", "INTEGER", "INT", "BIGINT",
    "SMALLINT", "VARCHAR", "DATE", "BOOLEAN", "TIMESTAMP", "DISTINCT",
}
ALLOWED_FUNCTIONS = {
    "COALESCE", "NULLIF", "ABS", "LOWER", "UPPER", "TRIM", "SUBSTR", "SUBSTRING", "LENGTH",
    "CAST", "YEAR", "MONTH", "DAY", "QUARTER", "CONCAT", "LEAST", "GREATEST", "SIGN",
}
# Named explicitly so the refusal message says why, rather than "unknown identifier".
NON_DETERMINISTIC = {
    "CURRENT_DATE", "CURRENT_TIME", "CURRENT_TIMESTAMP", "NOW", "TODAY", "GETDATE", "SYSDATE",
    "LOCALTIME", "LOCALTIMESTAMP", "RANDOM", "RAND", "UUID", "GEN_RANDOM_UUID", "SETSEED",
    "TABLESAMPLE", "USING_SAMPLE", "SAMPLE",
}
INEXACT = {"FLOAT", "DOUBLE", "REAL", "FLOAT4", "FLOAT8"}
FORBIDDEN_CLAUSES = {
    "SELECT", "FROM", "WHERE", "JOIN", "UNION", "INTERSECT", "EXCEPT", "GROUP", "ORDER", "HAVING",
    "LIMIT", "WITH", "OVER", "INSERT", "UPDATE", "DELETE", "DROP", "CREATE", "ALTER", "ATTACH",
    "COPY", "PRAGMA", "INSTALL", "LOAD", "CALL", "EXEC", "EXECUTE",
}

_TOKEN = re.compile(
    r"""
    (?P<ws>\s+)
  | (?P<str>'(?:[^']|'')*')
  | (?P<qid>"[^"]*")
  | (?P<param>:[A-Za-z_][A-Za-z0-9_]*)
  | (?P<num>\d+(?:\.\d+)?(?:[eE][+-]?\d+)?)
  | (?P<ref>[A-Za-z_][A-Za-z0-9_]*\.[A-Za-z_][A-Za-z0-9_]*)
  | (?P<ident>[A-Za-z_][A-Za-z0-9_]*)
  | (?P<op><=|>=|<>|!=|\|\||[-+*/%(),=<>])
  | (?P<bad>.)
    """,
    re.VERBOSE,
)


@dataclass
class SqlFragment:
    """A rewritten SQL fragment plus the model parameters it binds (as ``$p_<name>``)."""
    sql: str
    params: list[str]
    refs: list[tuple[str | None, str]]  # (dataset or None for home, field)


def lint_and_rewrite(
    text: str,
    resolve: Callable[[str | None, str], str],
    *,
    where: str,
    allow_aggregate: bool = False,
) -> SqlFragment:
    """Check a scalar SQL fragment and qualify its column references.

    ``resolve(dataset, field)`` returns the qualified SQL for a reference (dataset is None for
    an unqualified name) and raises ``KeyError`` when the reference is unknown.
    """
    if not isinstance(text, str) or not text.strip():
        raise ModelError(f"{where}: expression must be a non-empty string")
    out: list[str] = []
    params: list[str] = []
    refs: list[tuple[str | None, str]] = []
    tokens = [(m.lastgroup, m.group()) for m in _TOKEN.finditer(text)]
    depth = 0
    for i, (kind, val) in enumerate(tokens):
        nxt = next((v for k, v in tokens[i + 1:] if k != "ws"), "")
        if kind == "ws":
            out.append(" ")
        elif kind == "str":
            out.append(val)
        elif kind == "bad":
            raise ModelError(f"{where}: unexpected character {val!r} in {text!r}")
        elif kind == "qid":
            raise ModelError(f"{where}: quoted identifiers are not allowed ({val}); use plain field names")
        elif kind == "num":
            if "e" in val.lower():
                raise ModelError(f"{where}: exponent literal {val} is a floating-point value; write it as a decimal")
            out.append(val)
        elif kind == "param":
            out.append(f"$p_{val[1:]}")
            params.append(val[1:])
        elif kind == "op":
            if val == "/":
                raise ModelError(
                    f"{where}: division is not allowed inside SQL fragments (engines disagree on integer "
                    f"and decimal division). Define a derived metric with a formula instead: {text!r}")
            if val == "%":
                raise ModelError(f"{where}: modulo is not allowed: {text!r}")
            depth += val == "("
            depth -= val == ")"
            out.append(val)
        elif kind == "ref":
            ds, fld = val.split(".", 1)
            try:
                out.append(resolve(ds, fld))
            except KeyError as e:
                raise ModelError(f"{where}: unknown reference {val!r}: {e.args[0] if e.args else ''}") from None
            refs.append((ds, fld))
        elif kind == "ident":
            up = val.upper()
            if up in NON_DETERMINISTIC:
                raise ModelError(f"{where}: {val} is non-deterministic and is not allowed: {text!r}")
            if up.startswith("APPROX") or up in INEXACT:
                raise ModelError(f"{where}: {val} is inexact (approximate or floating point) and is not allowed")
            if up in FORBIDDEN_CLAUSES:
                raise ModelError(f"{where}: {val} is not allowed in a scalar expression: {text!r}")
            if nxt == "(":
                if allow_aggregate and up in {"SUM", "COUNT", "MIN", "MAX"}:
                    out.append(up)
                elif up in ALLOWED_FUNCTIONS:
                    out.append(up)
                else:
                    raise ModelError(f"{where}: function {val}() is not on the allow-list")
            elif up in ALLOWED_KEYWORDS:
                out.append(up)
            else:
                try:
                    out.append(resolve(None, val))
                except KeyError as e:
                    raise ModelError(
                        f"{where}: unknown field {val!r} {e.args[0] if e.args else ''}".rstrip()) from None
                refs.append((None, val))
    if depth != 0:
        raise ModelError(f"{where}: unbalanced parentheses in {text!r}")
    return SqlFragment("".join(out).strip(), params, refs)


def field_refs(text: str) -> list[tuple[str | None, str]]:
    """References in a fragment without validating them (used for static analysis)."""
    found: list[tuple[str | None, str]] = []
    tokens = [(m.lastgroup, m.group()) for m in _TOKEN.finditer(text or "")]
    for i, (kind, val) in enumerate(tokens):
        nxt = next((v for k, v in tokens[i + 1:] if k != "ws"), "")
        if kind == "ref":
            ds, f = val.split(".", 1)
            found.append((ds, f))
        elif kind == "ident":
            up = val.upper()
            if nxt == "(" or up in ALLOWED_KEYWORDS or up in NON_DETERMINISTIC or up in FORBIDDEN_CLAUSES:
                continue
            found.append((None, val))
    return found


# --------------------------------------------------------------------------- Decimal formulas

CONTEXT = decimal.Context(prec=50, rounding=decimal.ROUND_HALF_EVEN, Emin=-999999, Emax=999999,
                          traps=[decimal.InvalidOperation, decimal.Overflow])

_FUNCS = {"abs", "min", "max", "coalesce", "round", "is_missing"}


class Formula:
    """A compiled, side-effect-free arithmetic/boolean expression over named Decimal inputs."""

    def __init__(self, text: str, *, where: str):
        self.text = text
        self.where = where
        try:
            tree = ast.parse(text.strip(), mode="eval")
        except SyntaxError as e:
            raise ModelError(f"{where}: cannot parse formula {text!r}: {e.msg}") from None
        self._literals: dict[int, Decimal] = {}
        self.names: set[str] = set()
        self._check(tree.body, text.strip())
        self.tree = tree.body

    def _check(self, node: ast.AST, src: str) -> None:
        ok = (ast.BinOp, ast.UnaryOp, ast.Compare, ast.BoolOp, ast.Name, ast.Constant, ast.Call,
              ast.Tuple, ast.List, ast.Load, ast.Add, ast.Sub, ast.Mult, ast.Div, ast.USub, ast.UAdd,
              ast.Not, ast.And, ast.Or, ast.Lt, ast.LtE, ast.Gt, ast.GtE, ast.Eq, ast.NotEq, ast.In,
              ast.NotIn)
        if not isinstance(node, ok):
            raise ModelError(f"{self.where}: {type(node).__name__} is not allowed in formula {self.text!r}")
        if isinstance(node, ast.Constant):
            if isinstance(node.value, bool) or node.value is None:
                pass
            elif isinstance(node.value, (int, float)):
                seg = ast.get_source_segment(src, node)
                if seg is None or "e" in seg.lower():
                    raise ModelError(f"{self.where}: numeric literal must be plain decimal notation in {self.text!r}")
                self._literals[id(node)] = Decimal(seg)
            elif not isinstance(node.value, str):
                raise ModelError(f"{self.where}: unsupported literal {node.value!r}")
        if isinstance(node, ast.Name):
            self.names.add(node.id)
        if isinstance(node, ast.Call):
            if not isinstance(node.func, ast.Name) or node.func.id not in _FUNCS or node.keywords:
                raise ModelError(f"{self.where}: only {sorted(_FUNCS)} may be called in formulas")
            for a in node.args:
                self._check(a, src)
            return
        for child in ast.iter_child_nodes(node):
            self._check(child, src)

    def evaluate(self, env: dict[str, Any]) -> Any:
        with decimal.localcontext(CONTEXT):
            return self._eval(self.tree, env)

    def _eval(self, n: ast.AST, env: dict[str, Any]) -> Any:
        if isinstance(n, ast.Constant):
            return self._literals.get(id(n), n.value)
        if isinstance(n, ast.Name):
            if n.id not in env:
                raise QueryError(f"{self.where}: formula input {n.id!r} is not available")
            return to_decimal(env[n.id])
        if isinstance(n, (ast.Tuple, ast.List)):
            return tuple(self._eval(e, env) for e in n.elts)
        if isinstance(n, ast.UnaryOp):
            v = self._eval(n.operand, env)
            if isinstance(n.op, ast.Not):
                return None if v is None else (not v)
            if v is None:
                return None
            return -v if isinstance(n.op, ast.USub) else +v
        if isinstance(n, ast.BinOp):
            a, b = self._eval(n.left, env), self._eval(n.right, env)
            if a is None or b is None:
                return None
            if isinstance(n.op, ast.Add):
                return a + b
            if isinstance(n.op, ast.Sub):
                return a - b
            if isinstance(n.op, ast.Mult):
                return a * b
            if isinstance(n.op, ast.Div):
                return None if b == 0 else a / b
        if isinstance(n, ast.BoolOp):
            vals = [self._eval(v, env) for v in n.values]
            if isinstance(n.op, ast.And):
                if any(v is False for v in vals):
                    return False
                return None if any(v is None for v in vals) else True
            if any(v is True for v in vals):
                return True
            return None if any(v is None for v in vals) else False
        if isinstance(n, ast.Compare):
            left = self._eval(n.left, env)
            result: Any = True
            for op, comp in zip(n.ops, n.comparators):
                right = self._eval(comp, env)
                if left is None or right is None:
                    return None
                if isinstance(op, ast.Lt):
                    ok = left < right
                elif isinstance(op, ast.LtE):
                    ok = left <= right
                elif isinstance(op, ast.Gt):
                    ok = left > right
                elif isinstance(op, ast.GtE):
                    ok = left >= right
                elif isinstance(op, ast.Eq):
                    ok = left == right
                elif isinstance(op, ast.NotEq):
                    ok = left != right
                elif isinstance(op, ast.In):
                    ok = left in right
                else:
                    ok = left not in right
                if not ok:
                    result = False
                left = right
            return result
        if isinstance(n, ast.Call):
            fn = n.func.id  # type: ignore[attr-defined]
            args = [self._eval(a, env) for a in n.args]
            if fn == "is_missing":
                return args[0] is None
            if fn == "coalesce":
                return next((a for a in args if a is not None), None)
            if any(a is None for a in args):
                return None
            if fn == "abs":
                return abs(args[0])
            if fn == "min":
                return min(args)
            if fn == "max":
                return max(args)
            if fn == "round":
                places = int(args[1]) if len(args) > 1 else 0
                return args[0].quantize(Decimal(1).scaleb(-places), rounding=decimal.ROUND_HALF_EVEN)
        raise QueryError(f"{self.where}: cannot evaluate {ast.dump(n)}")


def to_decimal(v: Any) -> Any:
    """Normalise engine values: ints/Decimals to Decimal; floats are refused (they are inexact)."""
    if v is None or isinstance(v, (bool, str, tuple)):
        return v
    if isinstance(v, Decimal):
        return v
    if isinstance(v, int):
        return Decimal(v)
    if isinstance(v, float):
        raise QueryError(f"floating-point value {v!r} reached a formula; inputs must be exact")
    return v


def quantize(v: Any, scale: int) -> Any:
    if not isinstance(v, Decimal):
        return v
    with decimal.localcontext(CONTEXT):
        return v.quantize(Decimal(1).scaleb(-scale), rounding=decimal.ROUND_HALF_EVEN)
