# ossie-schema.json is copied unmodified from apache/ossie (Apache License 2.0); the commit it
# came from is recorded in OSSIE_SCHEMA_SOURCE. See NOTICE.
