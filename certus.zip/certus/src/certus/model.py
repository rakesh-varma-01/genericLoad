"""Loading and validating a Certus model.

A Certus model is a YAML document. Its core (datasets, fields, relationships, metrics) maps
one-to-one onto Apache Ossie; everything Ossie cannot yet express is first-class here and is
carried through Ossie exports as a ``custom_extensions`` payload, so nothing is lost on a
round trip. Every rule that can be checked without data is checked at load time.
"""
from __future__ import annotations

import datetime as dt
import fnmatch
import hashlib
import json
import re
from collections import deque
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml

from . import FORMAT_VERSION
from .errors import ModelError
from .expr import Formula, field_refs, lint_and_rewrite

NAME = re.compile(r"^[a-z][a-z0-9_]{0,62}$")
CLASSIFICATIONS = {"PUBLIC", "INTERNAL", "CONFIDENTIAL", "RESTRICTED", "PII", "PROTECTED", "MNPI"}
DATATYPES = {"String", "Integer", "Decimal", "Boolean", "Date", "DateTime", "DateTimeTz"}
AGGS = {"sum", "count", "count_distinct", "min", "max"}
UNITS = {"money", "count", "ratio", "number", "percent"}
STATUSES = {"draft", "certified", "deprecated"}
PARAM_TYPES = {"decimal", "integer", "string", "date", "boolean"}
GRAINS = {"day", "month", "quarter", "year", "fiscal_quarter", "fiscal_year"}


def _need(d: dict, key: str, where: str) -> Any:
    if key not in d or d[key] in (None, ""):
        raise ModelError(f"{where}: '{key}' is required")
    return d[key]


def _name(v: Any, where: str) -> str:
    if not isinstance(v, str) or not NAME.match(v):
        raise ModelError(f"{where}: name {v!r} must be lower_snake_case (a-z, 0-9, _), max 63 chars")
    return v


def _date(v: Any, where: str) -> dt.date:
    if isinstance(v, dt.datetime):
        return v.date()
    if isinstance(v, dt.date):
        return v
    try:
        return dt.date.fromisoformat(str(v))
    except ValueError:
        raise ModelError(f"{where}: {v!r} is not an ISO date (YYYY-MM-DD)") from None


def _classes(v: Any, where: str) -> frozenset[str]:
    vals = v if isinstance(v, list) else ([v] if v else [])
    bad = [c for c in vals if c not in CLASSIFICATIONS]
    if bad:
        raise ModelError(f"{where}: unknown classification {bad}; use {sorted(CLASSIFICATIONS)}")
    return frozenset(vals)


# --------------------------------------------------------------------------- structures

@dataclass
class Field:
    name: str
    expr: str
    datatype: str | None
    dimension: bool
    classification: frozenset[str]
    description: str = ""
    ai_context: Any = None
    concept: str | None = None


@dataclass
class Dataset:
    name: str
    source: str
    primary_key: list[str]
    fields: dict[str, Field]
    valid_time: str | None = None          # business date of each row (Date field)
    knowledge_time: str | None = None      # when the row became known (bitemporal)
    deleted: str | None = None             # boolean tombstone field
    scd: tuple[str, str] | None = None     # (valid_from, valid_to) for type-2 dimensions
    bridge_weight: str | None = None       # set when the dataset is an allocation bridge
    bridge_per: str | None = None          # the dataset whose amounts the weights allocate (sum to 1 per row)
    description: str = ""
    concept: str | None = None
    ai_context: Any = None
    classification: frozenset[str] = frozenset()


@dataclass
class Relationship:
    name: str
    src: str
    dst: str
    src_cols: list[str]
    dst_cols: list[str]
    as_of: bool = False   # dst is a type-2 dimension: match the version valid at the fact's time


@dataclass
class Param:
    name: str
    type: str
    default: Any
    description: str = ""
    choices: list | None = None

    def coerce(self, v: Any) -> Any:
        from decimal import Decimal, InvalidOperation
        where = f"parameter {self.name}"
        if v is None:
            raise ModelError(f"{where}: value is required")
        try:
            if self.type == "decimal":
                if isinstance(v, float):
                    v = repr(v)
                out: Any = Decimal(str(v))
            elif self.type == "integer":
                if isinstance(v, bool) or (isinstance(v, str) and not re.fullmatch(r"-?\d+", v.strip())):
                    raise ValueError
                out = int(v)
            elif self.type == "boolean":
                if isinstance(v, bool):
                    out = v
                elif str(v).lower() in {"true", "false"}:
                    out = str(v).lower() == "true"
                else:
                    raise ValueError
            elif self.type == "date":
                out = _date(v, where)
            else:
                out = str(v)
        except (ValueError, InvalidOperation, TypeError):
            raise ModelError(f"{where}: {v!r} is not a valid {self.type}") from None
        if self.choices is not None and out not in self.choices:
            raise ModelError(f"{where}: {out!r} is not one of {self.choices}")
        return out


@dataclass
class MetricVersion:
    effective_from: dt.date
    kind: str                      # base | derived
    dataset: str | None = None
    agg: str | None = None
    expr: str | None = None
    filter: str | None = None
    currency: str | None = None    # field reference holding the ISO currency code
    fx_rate_type: str | None = None
    fx_date: str = "valid_time"    # valid_time | period_end
    additivity: str = "full"       # full | semi
    semi_method: str = "last"      # last | first | average
    formula: Formula | None = None
    note: str = ""


@dataclass
class Metric:
    name: str
    status: str
    unit: str
    versions: list[MetricVersion]
    owner: str = ""
    steward: str = ""
    approved_by: str = ""
    description: str = ""
    classification: frozenset[str] = frozenset()
    ai_context: Any = None
    concept: str | None = None

    def version_for(self, on: dt.date) -> tuple[int, MetricVersion]:
        chosen = None
        for i, v in enumerate(self.versions):
            if v.effective_from <= on:
                chosen = (i + 1, v)
        if chosen is None:
            from .errors import QueryError
            raise QueryError(f"metric {self.name} has no definition in force on {on} "
                             f"(first effective {self.versions[0].effective_from})", code="no_definition")
        return chosen


@dataclass
class Role:
    name: str
    allow_metrics: list[str]
    deny_metrics: list[str]
    deny_classifications: frozenset[str]
    row_filters: list[tuple[str, str]]
    allow_decisions: list[str]
    description: str = ""


@dataclass
class Hierarchy:
    name: str
    dataset: str
    id_field: str
    parent_field: str
    label_field: str
    levels: list[str]


@dataclass
class Rule:
    id: str
    when: Formula | None
    outcome: str
    action: str = ""
    severity: str = ""


@dataclass
class Decision:
    name: str
    version: int
    status: str
    owner: str
    approved_by: str
    description: str
    grain: list[str]
    metrics: list[str]
    filters: list[dict]
    params: list[str]
    rules: list[Rule]
    default: Rule
    on_missing: Rule
    max_rows: int = 10000


@dataclass
class Model:
    path: Path
    raw: dict
    name: str
    version: str
    description: str
    owner: str
    ai_context: Any
    data_dir: Path
    reporting_currency: str
    money_scale: int
    ratio_scale: int
    fiscal_year_start_month: int
    fx: dict | None
    datasets: dict[str, Dataset]
    relationships: list[Relationship]
    params: dict[str, Param]
    metrics: dict[str, Metric]
    hierarchies: dict[str, Hierarchy]
    roles: dict[str, Role]
    agent_policy: dict
    decisions: dict[str, Decision]
    graph: "JoinGraph" = field(init=False)

    @property
    def hash(self) -> str:
        canon = json.dumps(self.raw, sort_keys=True, separators=(",", ":"), default=str)
        return hashlib.sha256(canon.encode()).hexdigest()

    def lock_path(self) -> Path:
        return self.path.with_suffix(".lock.json")

    def lock_status(self) -> dict:
        p = self.lock_path()
        if not p.exists():
            return {"locked": False, "reason": "no lock file"}
        lock = json.loads(p.read_text())
        if lock.get("model_hash") != self.hash:
            return {"locked": False, "reason": "model changed since it was approved", "lock": lock}
        return {"locked": True, "lock": lock}

    def fields_with(self, cls: str) -> set[str]:
        return {f"{d.name}.{f.name}" for d in self.datasets.values() for f in d.fields.values()
                if cls in f.classification}


# --------------------------------------------------------------------------- join graph

@dataclass(frozen=True)
class Hop:
    rel: Relationship
    reverse: bool        # True when stepping from the 'to' side into a bridge dataset
    src: str
    dst: str


class JoinGraph:
    """Joins the planner may take without changing a measure's grain.

    Forward hops follow relationships from the many side to the one side, which can never
    duplicate fact rows. The only one-to-many hop allowed is into a declared allocation bridge,
    whose weight the planner applies so totals are preserved.
    """

    def __init__(self, datasets: dict[str, Dataset], rels: list[Relationship]):
        self.datasets = datasets
        self.out: dict[str, list[Hop]] = {d: [] for d in datasets}
        for r in rels:
            self.out[r.src].append(Hop(r, False, r.src, r.dst))
            # entering a bridge is only grain-safe from the side whose amounts its shares allocate
            if datasets[r.src].bridge_weight and datasets[r.src].bridge_per == r.dst:
                self.out[r.dst].append(Hop(r, True, r.dst, r.src))
        self._cache: dict[str, dict[str, list[Hop] | None]] = {}

    def paths_from(self, root: str) -> dict[str, list[Hop] | None]:
        """Shortest hop list from root to every reachable dataset; None marks an ambiguous target."""
        if root in self._cache:
            return self._cache[root]
        best: dict[str, list[Hop] | None] = {root: []}
        dist = {root: 0}
        q = deque([root])
        while q:
            cur = q.popleft()
            path = best[cur]
            if path is None:
                continue
            came_from_bridge = bool(path) and path[-1].reverse
            for hop in self.out[cur]:
                if hop.reverse and came_from_bridge:
                    continue
                if path and hop.dst in {h.src for h in path}:
                    continue
                nd = dist[cur] + 1
                if hop.dst not in dist:
                    dist[hop.dst] = nd
                    best[hop.dst] = path + [hop]
                    q.append(hop.dst)
                elif dist[hop.dst] == nd and best[hop.dst] is not None and best[hop.dst] != path + [hop]:
                    best[hop.dst] = None
        self._cache[root] = best
        return best

    def path(self, root: str, target: str) -> list[Hop]:
        paths = self.paths_from(root)
        if target not in paths:
            raise ModelError(f"no grain-safe join path from {root} to {target}", code="unreachable")
        if paths[target] is None:
            raise ModelError(f"more than one join path from {root} to {target}; the join is ambiguous",
                             code="ambiguous_path")
        return paths[target]  # type: ignore[return-value]


# --------------------------------------------------------------------------- loader

def load_model(path: str | Path) -> Model:
    path = Path(path).resolve()
    try:
        raw = yaml.safe_load(path.read_text())
    except yaml.YAMLError as e:
        raise ModelError(f"{path.name}: invalid YAML: {e}") from None
    if not isinstance(raw, dict):
        raise ModelError(f"{path.name}: top level must be a mapping")
    return parse_model(raw, path)


KNOWN_TOP = {"certus", "model", "connection", "reporting", "fx", "datasets", "relationships",
             "parameters", "metrics", "hierarchies", "roles", "agent_policy", "decisions"}


def parse_model(raw: dict, path: Path) -> Model:
    unknown = set(raw) - KNOWN_TOP
    if unknown:
        raise ModelError(f"unknown top-level keys {sorted(unknown)} (a typo here would silently drop rules)")
    if str(raw.get("certus")) != FORMAT_VERSION:
        raise ModelError(f"'certus: {FORMAT_VERSION}' is required (found {raw.get('certus')!r})")
    m = _need(raw, "model", "model")
    name = _name(_need(m, "name", "model"), "model.name")
    version = str(_need(m, "version", "model"))
    if not re.fullmatch(r"\d+\.\d+\.\d+", version):
        raise ModelError("model.version must be semantic (MAJOR.MINOR.PATCH)")
    conn = raw.get("connection") or {}
    data_dir = (path.parent / conn.get("data_dir", "data")).resolve()
    rep = raw.get("reporting") or {}
    reporting_currency = rep.get("currency", "USD")
    fy = int(rep.get("fiscal_year_start_month", 1))
    if not 1 <= fy <= 12:
        raise ModelError("reporting.fiscal_year_start_month must be 1-12")

    # datasets
    datasets: dict[str, Dataset] = {}
    for i, d in enumerate(_need(raw, "datasets", "model")):
        where = f"datasets[{i}]"
        dn = _name(_need(d, "name", where), where)
        where = f"dataset {dn}"
        if dn in datasets:
            raise ModelError(f"{where}: duplicate name")
        fields: dict[str, Field] = {}
        for j, f in enumerate(_need(d, "fields", where)):
            fn = _name(_need(f, "name", f"{where}.fields[{j}]"), f"{where}.fields[{j}]")
            if fn in fields:
                raise ModelError(f"{where}: duplicate field {fn}")
            dtp = f.get("datatype")
            if dtp is not None and dtp not in DATATYPES:
                raise ModelError(f"{where}.{fn}: datatype {dtp!r} not in {sorted(DATATYPES)}")
            fields[fn] = Field(fn, str(f.get("expr", fn)), dtp, bool(f.get("dimension", False)),
                               _classes(f.get("classification"), f"{where}.{fn}"), f.get("description", ""),
                               f.get("ai_context"), f.get("concept"))
        pk = list(d.get("primary_key") or [])
        for k in pk:
            if k not in fields:
                raise ModelError(f"{where}: primary_key {k!r} is not a declared field")
        t = d.get("temporal") or {}
        for key in ("valid_time", "knowledge_time", "deleted"):
            if t.get(key) and t[key] not in fields:
                raise ModelError(f"{where}: temporal.{key} {t[key]!r} is not a declared field")
        if t.get("knowledge_time") and not pk:
            raise ModelError(f"{where}: a bitemporal dataset needs a primary_key to identify versions")
        scd = None
        if t.get("valid_from") or t.get("valid_to"):
            if not (t.get("valid_from") in fields and t.get("valid_to") in fields):
                raise ModelError(f"{where}: temporal.valid_from and valid_to must both be declared fields")
            scd = (t["valid_from"], t["valid_to"])
        br = d.get("bridge") or {}
        bw, bper = br.get("weight"), br.get("per")
        if br and not (bw and bper):
            raise ModelError(f"{where}: bridge needs weight (the share field) and per (the dataset whose amounts "
                             f"the shares allocate; shares must sum to 1 for each of its rows)")
        if bw and bw not in fields:
            raise ModelError(f"{where}: bridge.weight {bw!r} is not a declared field")
        datasets[dn] = Dataset(dn, str(_need(d, "source", where)), pk, fields, t.get("valid_time"),
                               t.get("knowledge_time"), t.get("deleted"), scd, bw, bper, d.get("description", ""),
                               d.get("concept"), d.get("ai_context"), _classes(d.get("classification"), where))
    # field expressions may only use physical columns, never other fields: check determinism now
    for ds in datasets.values():
        for f in ds.fields.values():
            lint_and_rewrite(f.expr, lambda dsn, col: col if dsn is None else (_ for _ in ()).throw(KeyError(
                "field expressions cannot reference other datasets")), where=f"{ds.name}.{f.name}")

    rels: list[Relationship] = []
    seen = set()
    for i, r in enumerate(raw.get("relationships") or []):
        where = f"relationships[{i}]"
        rn = _name(_need(r, "name", where), where)
        if rn in seen:
            raise ModelError(f"relationship {rn}: duplicate name")
        seen.add(rn)
        src, dst = _need(r, "from", rn), _need(r, "to", rn)
        for s in (src, dst):
            if s not in datasets:
                raise ModelError(f"relationship {rn}: dataset {s!r} does not exist")
        sc, dc = list(_need(r, "from_columns", rn)), list(_need(r, "to_columns", rn))
        if len(sc) != len(dc):
            raise ModelError(f"relationship {rn}: from_columns and to_columns differ in length")
        for c in sc:
            if c not in datasets[src].fields:
                raise ModelError(f"relationship {rn}: {src}.{c} is not a declared field")
        for c in dc:
            if c not in datasets[dst].fields:
                raise ModelError(f"relationship {rn}: {dst}.{c} is not a declared field")
        as_of = bool(r.get("as_of", False))
        if as_of and not datasets[dst].scd:
            raise ModelError(f"relationship {rn}: as_of requires {dst} to declare temporal.valid_from/valid_to")
        if not as_of and datasets[dst].scd:
            raise ModelError(f"relationship {rn}: {dst} is a type-2 dimension; set as_of: true or the join "
                             f"would match every historical version")
        rels.append(Relationship(rn, src, dst, sc, dc, as_of))

    params: dict[str, Param] = {}
    for pn, p in (raw.get("parameters") or {}).items():
        _name(pn, f"parameter {pn}")
        pt = p.get("type")
        if pt not in PARAM_TYPES:
            raise ModelError(f"parameter {pn}: type must be one of {sorted(PARAM_TYPES)}")
        par = Param(pn, pt, None, p.get("description", ""), p.get("choices"))
        par.default = par.coerce(_need(p, "default", f"parameter {pn}"))
        params[pn] = par

    fx = raw.get("fx")
    if fx:
        fds = _need(fx, "dataset", "fx")
        if fds not in datasets:
            raise ModelError(f"fx.dataset {fds!r} does not exist")
        for k in ("currency_field", "date_field", "rate_field", "type_field"):
            if _need(fx, k, "fx") not in datasets[fds].fields:
                raise ModelError(f"fx.{k} {fx[k]!r} is not a field of {fds}")

    for ds in datasets.values():
        if ds.bridge_per and not any(r.src == ds.name and r.dst == ds.bridge_per for r in rels):
            raise ModelError(f"dataset {ds.name}: bridge.per {ds.bridge_per!r} needs a relationship from {ds.name} "
                             f"to {ds.bridge_per}")

    model = Model(path, raw, name, version, m.get("description", ""), m.get("owner", ""), m.get("ai_context"),
                  data_dir, reporting_currency, int(rep.get("money_scale", 2)), int(rep.get("ratio_scale", 6)), fy,
                  fx, datasets, rels, params, {}, {}, {}, raw.get("agent_policy") or {}, {})
    model.graph = JoinGraph(datasets, rels)
    _cycle_check(rels)

    for hn, h in (raw.get("hierarchies") or {}).items():
        _name(hn, f"hierarchy {hn}")
        hd = _need(h, "dataset", f"hierarchy {hn}")
        if hd not in datasets:
            raise ModelError(f"hierarchy {hn}: dataset {hd!r} does not exist")
        for k in ("id_field", "parent_field", "label_field"):
            if _need(h, k, f"hierarchy {hn}") not in datasets[hd].fields:
                raise ModelError(f"hierarchy {hn}: {k} {h[k]!r} is not a field of {hd}")
        model.hierarchies[hn] = Hierarchy(hn, hd, h["id_field"], h["parent_field"], h["label_field"],
                                          list(h.get("levels") or []))

    _parse_metrics(model, raw.get("metrics") or [])
    _parse_roles(model, raw.get("roles") or {})
    _parse_decisions(model, raw.get("decisions") or [])
    _check_agent_policy(model)
    return model


def _cycle_check(rels: list[Relationship]) -> None:
    edges: dict[str, list[str]] = {}
    for r in rels:
        edges.setdefault(r.src, []).append(r.dst)
    state: dict[str, int] = {}

    def visit(n: str, trail: list[str]) -> None:
        state[n] = 1
        for nx in edges.get(n, []):
            if state.get(nx) == 1:
                raise ModelError(f"relationships form a cycle: {' -> '.join(trail + [n, nx])}")
            if not state.get(nx):
                visit(nx, trail + [n])
        state[n] = 2

    for n in list(edges):
        if not state.get(n):
            visit(n, [])


def check_fragment(model: Model, root: str, text: str, where: str, *, allow_params: bool = True) -> list[str]:
    """Validate a SQL fragment evaluated on a row of ``root``; return the datasets it touches."""
    touched: set[str] = set()

    def resolve(ds: str | None, f: str) -> str:
        dsn = ds or root
        if dsn not in model.datasets:
            raise KeyError(f"(dataset {dsn} does not exist)")
        if f not in model.datasets[dsn].fields:
            raise KeyError(f"(not a field of {dsn})")
        if dsn != root:
            model.graph.path(root, dsn)
        touched.add(dsn)
        return f"{dsn}.{f}"

    frag = lint_and_rewrite(text, resolve, where=where)
    for p in frag.params:
        if not allow_params or p not in model.params:
            raise ModelError(f"{where}: unknown parameter :{p}")
    return sorted(touched)


def _parse_metrics(model: Model, items: list) -> None:
    raw_by_name = {}
    for i, mt in enumerate(items):
        where = f"metrics[{i}]"
        mn = _name(_need(mt, "name", where), where)
        where = f"metric {mn}"
        if mn in raw_by_name or mn in model.params:
            raise ModelError(f"{where}: duplicate name (metrics and parameters share one namespace)")
        raw_by_name[mn] = mt
    for mn, mt in raw_by_name.items():
        where = f"metric {mn}"
        status = mt.get("status", "draft")
        if status not in STATUSES:
            raise ModelError(f"{where}: status must be one of {sorted(STATUSES)}")
        unit = _need(mt, "unit", where)
        if unit not in UNITS:
            raise ModelError(f"{where}: unit must be one of {sorted(UNITS)}")
        if status == "certified" and not (mt.get("owner") and mt.get("approved_by")):
            raise ModelError(f"{where}: a certified metric needs an owner and approved_by")
        vraw = mt.get("versions") or [{k: v for k, v in mt.items() if k in VERSION_KEYS}
                                      | {"effective_from": mt.get("effective_from", "1900-01-01")}]
        versions = []
        for j, v in enumerate(vraw):
            versions.append(_parse_version(model, mn, unit, v, f"{where}.versions[{j}]", set(raw_by_name)))
        dates = [v.effective_from for v in versions]
        if dates != sorted(dates) or len(set(dates)) != len(dates):
            raise ModelError(f"{where}: versions must have strictly increasing effective_from dates")
        model.metrics[mn] = Metric(mn, status, unit, versions, mt.get("owner", ""), mt.get("steward", ""),
                                   mt.get("approved_by", ""), mt.get("description", ""),
                                   _classes(mt.get("classification"), where), mt.get("ai_context"), mt.get("concept"))
    # derived metrics: no cycles, and a certified metric may only depend on certified metrics
    for mn, met in model.metrics.items():
        _metric_deps(model, mn, [])
        if met.status == "certified":
            for dep in metric_closure(model, mn):
                if model.metrics[dep].status != "certified":
                    raise ModelError(f"metric {mn}: certified metric depends on {dep}, which is "
                                     f"{model.metrics[dep].status}")


VERSION_KEYS = {"dataset", "agg", "expr", "filter", "currency", "fx", "additivity", "formula", "note"}


def _parse_version(model: Model, mn: str, unit: str, v: dict, where: str, metric_names: set[str]) -> MetricVersion:
    unknown = set(v) - VERSION_KEYS - {"effective_from"}
    if unknown:
        raise ModelError(f"{where}: unknown keys {sorted(unknown)}")
    eff = _date(v.get("effective_from", "1900-01-01"), where)
    if "formula" in v:
        if "dataset" in v or "agg" in v:
            raise ModelError(f"{where}: a metric is either base (dataset+agg) or derived (formula), not both")
        f = Formula(str(v["formula"]), where=where)
        for n in f.names:
            if n not in metric_names and n not in model.params:
                raise ModelError(f"{where}: formula refers to unknown metric or parameter {n!r}")
        return MetricVersion(eff, "derived", formula=f, note=v.get("note", ""))
    ds = _need(v, "dataset", where)
    if ds not in model.datasets:
        raise ModelError(f"{where}: dataset {ds!r} does not exist")
    agg = _need(v, "agg", where)
    if agg not in AGGS:
        raise ModelError(f"{where}: agg must be one of {sorted(AGGS)} (averages and ratios are derived "
                         f"metrics so their arithmetic is exact)")
    expr = str(v.get("expr", "*" if agg == "count" else ""))
    if expr != "*":
        check_fragment(model, ds, expr, f"{where}.expr")
    elif agg != "count":
        raise ModelError(f"{where}: expr is required for {agg}")
    if v.get("filter"):
        check_fragment(model, ds, str(v["filter"]), f"{where}.filter")
    mv = MetricVersion(eff, "base", ds, agg, expr, v.get("filter"), note=v.get("note", ""))
    add = v.get("additivity") or {"type": "full"}
    if add.get("type") not in {"full", "semi"}:
        raise ModelError(f"{where}: additivity.type must be full or semi")
    if add["type"] == "semi":
        if not model.datasets[ds].valid_time:
            raise ModelError(f"{where}: a semi-additive metric needs temporal.valid_time on {ds} (the snapshot date)")
        if agg not in {"sum", "count", "count_distinct"}:
            raise ModelError(f"{where}: semi-additivity applies to sum/count metrics")
        mv.additivity = "semi"
        mv.semi_method = add.get("method", "last")
        if mv.semi_method not in {"last", "first", "average"}:
            raise ModelError(f"{where}: additivity.method must be last, first or average")
    if unit == "money":
        if agg not in {"sum", "min", "max"}:
            raise ModelError(f"{where}: money metrics must be sum/min/max")
        cur = _need(v, "currency", f"{where} (money metrics must declare where the currency code lives)")
        check_fragment(model, ds, cur, f"{where}.currency")
        mv.currency = cur
        fxc = v.get("fx") or {}
        mv.fx_rate_type = fxc.get("rate_type")
        mv.fx_date = fxc.get("date", "valid_time")
        if mv.fx_date not in {"valid_time", "period_end"}:
            raise ModelError(f"{where}: fx.date must be valid_time or period_end")
        if mv.fx_date == "valid_time" and not model.datasets[ds].valid_time:
            raise ModelError(f"{where}: fx.date valid_time needs temporal.valid_time on {ds}")
    elif v.get("currency"):
        raise ModelError(f"{where}: only money metrics take a currency")
    return mv


def _metric_deps(model: Model, mn: str, trail: list[str]) -> None:
    if mn in trail:
        raise ModelError(f"derived metrics form a cycle: {' -> '.join(trail + [mn])}")
    for v in model.metrics[mn].versions:
        if v.formula:
            for n in v.formula.names:
                if n in model.metrics:
                    _metric_deps(model, n, trail + [mn])


def metric_closure(model: Model, mn: str, on: dt.date | None = None) -> list[str]:
    """All metrics ``mn`` depends on (any version, or only the version in force ``on``)."""
    out: list[str] = []

    def walk(n: str) -> None:
        met = model.metrics[n]
        vs = [met.version_for(on)[1]] if on else met.versions
        for v in vs:
            if v.formula:
                for d in sorted(v.formula.names):
                    if d in model.metrics and d not in out:
                        out.append(d)
                        walk(d)

    walk(mn)
    return out


def _parse_roles(model: Model, roles: dict) -> None:
    for rn, r in roles.items():
        _name(rn, f"role {rn}")
        where = f"role {rn}"
        rfs = []
        for f in r.get("row_filters") or []:
            ds = _need(f, "dataset", where)
            if ds not in model.datasets:
                raise ModelError(f"{where}: row filter dataset {ds!r} does not exist")
            pred = str(_need(f, "predicate", where))
            refs = field_refs(pred)
            if any(d not in (None, ds) for d, _ in refs):
                raise ModelError(f"{where}: a row filter may only reference fields of {ds}")
            check_fragment(model, ds, pred, f"{where}.row_filters", allow_params=False)
            rfs.append((ds, pred))
        for pat in (r.get("allow_metrics") or []) + (r.get("deny_metrics") or []):
            if not any(fnmatch.fnmatchcase(mn, pat) for mn in model.metrics):
                raise ModelError(f"{where}: metric pattern {pat!r} matches nothing (typo?)")
        model.roles[rn] = Role(rn, list(r.get("allow_metrics") or []), list(r.get("deny_metrics") or []),
                               _classes(r.get("deny_classifications"), where), rfs,
                               list(r.get("allow_decisions") or []), r.get("description", ""))


def _parse_decisions(model: Model, items: list) -> None:
    protected = model.fields_with("PROTECTED")
    for i, d in enumerate(items):
        where = f"decisions[{i}]"
        dn = _name(_need(d, "name", where), where)
        where = f"decision {dn}"
        if dn in model.decisions:
            raise ModelError(f"{where}: duplicate name")
        status = d.get("status", "draft")
        if status not in STATUSES:
            raise ModelError(f"{where}: status must be one of {sorted(STATUSES)}")
        if status == "certified" and not (d.get("owner") and d.get("approved_by")):
            raise ModelError(f"{where}: a certified decision needs an owner and approved_by")
        metrics = list(_need(d, "metrics", where))
        for mn in metrics:
            if mn not in model.metrics:
                raise ModelError(f"{where}: unknown metric {mn}")
            if status == "certified" and model.metrics[mn].status != "certified":
                raise ModelError(f"{where}: certified decisions may only use certified metrics ({mn} is "
                                 f"{model.metrics[mn].status})")
        params = list(d.get("parameters") or [])
        for p in params:
            if p not in model.params:
                raise ModelError(f"{where}: unknown parameter {p}")
        names = set(metrics) | set(params)

        def rule(r: dict, w: str, needs_when: bool) -> Rule:
            when = None
            if needs_when:
                when = Formula(str(_need(r, "when", w)), where=w)
                extra = when.names - names
                if extra:
                    raise ModelError(f"{w}: uses {sorted(extra)}, which are not declared in the decision's "
                                     f"metrics or parameters")
            return Rule(str(r.get("id", w)), when, str(_need(r, "outcome", w)), r.get("action", ""),
                        r.get("severity", ""))

        rules = [rule(r, f"{where}.rules[{j}]", True) for j, r in enumerate(_need(d, "rules", where))]
        ids = [r.id for r in rules]
        if len(set(ids)) != len(ids):
            raise ModelError(f"{where}: rule ids must be unique")
        dec = Decision(dn, int(d.get("version", 1)), status, d.get("owner", ""), d.get("approved_by", ""),
                       d.get("description", ""), list(d.get("grain") or []), metrics, list(d.get("filters") or []),
                       params, rules, rule(_need(d, "default", where), f"{where}.default", False),
                       rule(_need(d, "on_missing", where), f"{where}.on_missing", False),
                       int(d.get("max_rows", 10000)))
        # fair-lending guard: no PROTECTED attribute may influence a decision, directly or through
        # a metric's definition, filter or currency field
        used = set(dec.grain) | {f.get("field", "") for f in dec.filters}
        for mn in metrics:
            for dep in [mn] + metric_closure(model, mn):
                for v in model.metrics[dep].versions:
                    if v.kind == "base":
                        for txt in filter(None, [v.expr if v.expr != "*" else None, v.filter, v.currency]):
                            used |= {f"{ds or v.dataset}.{f}" for ds, f in field_refs(txt)}
        hit = sorted(used & protected)
        if hit:
            raise ModelError(f"{where}: uses PROTECTED attributes {hit}; protected characteristics may not "
                             f"drive decisions", code="protected_attribute")
        model.decisions[dn] = dec


def _check_agent_policy(model: Model) -> None:
    ap = model.agent_policy
    _classes(ap.get("deny_classifications"), "agent_policy")
    for dn in ap.get("allow_decisions") or []:
        if dn not in model.decisions:
            raise ModelError(f"agent_policy: unknown decision {dn}")


# --------------------------------------------------------------------------- identity directory

@dataclass
class Principal:
    name: str
    roles: list[str]
    kind: str = "human"     # human | agent | service
    display: str = ""


def load_directory(path: str | Path, model: Model) -> dict[str, Principal]:
    raw = yaml.safe_load(Path(path).read_text()) or {}
    out = {}
    for pn, p in (raw.get("principals") or {}).items():
        roles = list(p.get("roles") or [])
        for r in roles:
            if r not in model.roles:
                raise ModelError(f"principal {pn}: role {r!r} is not defined in the model")
        kind = p.get("kind", "human")
        if kind not in {"human", "agent", "service"}:
            raise ModelError(f"principal {pn}: kind must be human, agent or service")
        out[pn] = Principal(pn, roles, kind, p.get("display", pn))
    return out


def lock_model(model: Model, approver: str, note: str = "") -> dict:
    lock = {"model": model.name, "model_version": model.version, "model_hash": model.hash,
            "approved_by": approver, "approved_at": dt.datetime.now(dt.timezone.utc).isoformat(timespec="seconds"),
            "note": note}
    model.lock_path().write_text(json.dumps(lock, indent=2) + "\n")
    return lock
