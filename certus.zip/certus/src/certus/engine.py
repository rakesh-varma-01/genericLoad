"""Planning and executing governed, deterministic metric queries on DuckDB.

How a request is answered:

1. Governance runs first (``governance.py``); nothing is planned for a refused request.
2. The definition of every metric in force on the definition date (period end by default) is
   chosen, so a report for 2025-Q2 uses the definitions that applied then.
3. Each *base* metric is planned on its own, rooted at its own dataset, joining only
   many-to-one (or through a declared allocation bridge, whose weight is applied). Fan-out and
   chasm-trap double counting are therefore impossible by construction.
4. Every dataset is read as it was known at ``known_at`` (bitemporal visibility): rows recorded
   later are invisible, the latest version per key wins, tombstoned rows disappear.
5. Stocks (semi-additive metrics) take the last, first or average period-end snapshot instead
   of summing over time. Money is converted row by row at the declared FX rate type.
6. Contract checks run against the visible data: duplicate keys, overlapping type-2 versions,
   allocation weights that do not sum to one, missing or stale FX rates. A violation refuses
   the query instead of returning a number that might be wrong.
7. SQL returns only exact counts and sums. Ratios, averages, currency translation and rounding
   happen in Python ``Decimal`` with round-half-even, so the answer is identical everywhere.
8. Results are sorted deterministically and hashed together with the data they were computed
   from, so anyone can later prove which data and definitions produced a number.
"""
from __future__ import annotations

import calendar as _cal
import datetime as dt
import decimal
import hashlib
import json
import re
from dataclasses import dataclass, field
from decimal import Decimal
from pathlib import Path
from typing import Any

import duckdb

from .errors import AccessDenied, DataIntegrityError, ModelError, QueryError
from .expr import CONTEXT, lint_and_rewrite, quantize, to_decimal
from .governance import Access, check_fields, check_metrics, resolve_access
from .model import GRAINS, Dataset, Hop, MetricVersion, Model, Principal, load_directory, metric_closure

OPS = {"=": "=", "!=": "<>", "<>": "<>", "<": "<", "<=": "<=", ">": ">", ">=": ">=", "like": "LIKE",
       "in": "IN", "not_in": "NOT IN", "between": "BETWEEN"}


# --------------------------------------------------------------------------- requests

@dataclass
class Request:
    metrics: list[str]
    period: str
    dimensions: list[str] = field(default_factory=list)
    filters: list[dict] = field(default_factory=list)
    known_at: str | None = None
    parameters: dict = field(default_factory=dict)
    reporting_currency: str | None = None
    order_by: list[dict] = field(default_factory=list)
    limit: int | None = None
    role: str | None = None
    definitions_as_of: str | None = None

    @classmethod
    def from_dict(cls, d: dict) -> "Request":
        allowed = set(cls.__dataclass_fields__)
        unknown = set(d) - allowed
        if unknown:
            raise QueryError(f"unknown request keys {sorted(unknown)}; allowed: {sorted(allowed)}")
        if not d.get("metrics"):
            raise QueryError("request needs at least one metric")
        if not d.get("period"):
            raise QueryError("request needs a period (e.g. 2025, 2025Q4, 2025-12, 2025-12-31, "
                             "FY2026, or 2025-01-01..2025-06-30)")
        return cls(**d)

    def to_dict(self) -> dict:
        return {k: getattr(self, k) for k in self.__dataclass_fields__ if getattr(self, k) not in (None, [], {})}


def parse_period(text: str, fy_start: int = 1) -> tuple[dt.date, dt.date]:
    s = str(text).strip()
    try:
        if ".." in s:
            a, b = s.split("..", 1)
            start, end = dt.date.fromisoformat(a.strip()), dt.date.fromisoformat(b.strip())
        elif re.fullmatch(r"\d{4}", s):
            y = int(s)
            start, end = dt.date(y, 1, 1), dt.date(y, 12, 31)
        elif m := re.fullmatch(r"(\d{4})Q([1-4])", s):
            y, q = int(m[1]), int(m[2])
            start = dt.date(y, 3 * q - 2, 1)
            end = dt.date(y, 3 * q, _cal.monthrange(y, 3 * q)[1])
        elif m := re.fullmatch(r"(\d{4})-(\d{2})", s):
            y, mo = int(m[1]), int(m[2])
            start, end = dt.date(y, mo, 1), dt.date(y, mo, _cal.monthrange(y, mo)[1])
        elif m := re.fullmatch(r"FY(\d{4})", s):
            fy = int(m[1])
            if fy_start == 1:
                start, end = dt.date(fy, 1, 1), dt.date(fy, 12, 31)
            else:
                start = dt.date(fy - 1, fy_start, 1)
                end = dt.date(fy, fy_start, 1) - dt.timedelta(days=1)
        else:
            start = end = dt.date.fromisoformat(s)
    except ValueError:
        raise QueryError(f"cannot read period {text!r}") from None
    if end < start:
        raise QueryError(f"period {text!r} ends before it starts")
    return start, end


@dataclass
class Dim:
    token: str
    kind: str                 # field | time | hier
    dataset: str | None = None
    field: str | None = None
    grain: str | None = None
    level: int | None = None


@dataclass
class QueryResult:
    columns: list[str]
    rows: list[dict]
    meta: dict

    def to_dict(self) -> dict:
        return {"columns": self.columns, "rows": [{k: _jsonable(v) for k, v in r.items()} for r in self.rows],
                "meta": self.meta}


def _jsonable(v: Any) -> Any:
    if isinstance(v, Decimal):
        return format(v, "f")
    if isinstance(v, (dt.date, dt.datetime)):
        return v.isoformat()
    return v


def canonical_hash(obj: Any) -> str:
    return hashlib.sha256(json.dumps(obj, sort_keys=True, separators=(",", ":"), default=_jsonable)
                          .encode()).hexdigest()


# --------------------------------------------------------------------------- engine

class Engine:
    def __init__(self, model: Model, directory: dict[str, Principal] | str | Path | None = None):
        self.model = model
        if isinstance(directory, (str, Path)):
            directory = load_directory(directory, model)
        self.directory = directory or {}
        self.con = duckdb.connect(":memory:")
        self._checked: set[tuple] = set()
        self._watermark: str | None = None

    # ---------------------------------------------------------------- sources
    def _source(self, ds: Dataset) -> str:
        src = ds.source
        p = Path(src)
        if not p.suffix:
            p = Path(src + ".parquet")
        if not p.is_absolute():
            p = self.model.data_dir / p
        if not p.exists():
            raise ModelError(f"dataset {ds.name}: source file {p} does not exist", code="missing_source")
        lit = "'" + str(p).replace("'", "''") + "'"
        if p.suffix == ".parquet":
            return f"read_parquet({lit})"
        if p.suffix == ".csv":
            return f"read_csv({lit}, header=true, auto_detect=true, sample_size=-1)"
        raise ModelError(f"dataset {ds.name}: unsupported source type {p.suffix} (parquet or csv)")

    def _base_select(self, ds: Dataset) -> str:
        cols = []
        for f in ds.fields.values():
            frag = lint_and_rewrite(f.expr, lambda d, c: f'"{c}"', where=f"{ds.name}.{f.name}")
            cols.append(f'{frag.sql} AS "{f.name}"')
        return f"SELECT {', '.join(cols)} FROM {self._source(ds)}"

    def visible_cte(self, ds: Dataset) -> str:
        base = self._base_select(ds)
        if not ds.knowledge_time:
            inner = base
        else:
            pk = ", ".join(f'"{k}"' for k in ds.primary_key)
            inner = (f"SELECT * EXCLUDE (_certus_rn) FROM (SELECT s.*, row_number() OVER (PARTITION BY {pk} "
                     f'ORDER BY s."{ds.knowledge_time}" DESC) AS _certus_rn FROM ({base}) s '
                     f'WHERE s."{ds.knowledge_time}" <= CAST($k_at AS TIMESTAMP)) WHERE _certus_rn = 1')
        if ds.deleted:
            inner = f'SELECT * FROM ({inner}) WHERE NOT coalesce("{ds.deleted}", FALSE)'
        return f"v_{ds.name} AS ({inner})"

    def watermark(self) -> str:
        """Latest knowledge time across all bitemporal datasets: the default ``known_at``."""
        if self._watermark is None:
            stamps = []
            for ds in self.model.datasets.values():
                if ds.knowledge_time:
                    row = self.con.execute(
                        f'SELECT max("{ds.knowledge_time}") FROM ({self._base_select(ds)})').fetchone()
                    if row and row[0] is not None:
                        stamps.append(row[0])
            if not stamps:
                self._watermark = "9999-12-31T23:59:59"
            else:
                self._watermark = max(stamps).isoformat()
        return self._watermark

    # ---------------------------------------------------------------- public API
    def principal(self, name: str | None) -> Principal | None:
        return self.directory.get(name) if name else None

    def query(self, request: Request | dict, principal: str | Principal | None) -> QueryResult:
        req = Request.from_dict(request) if isinstance(request, dict) else request
        p = principal if isinstance(principal, Principal) else self.principal(principal)
        access = resolve_access(self.model, p, req.role)
        return self._run(req, access)

    # ---------------------------------------------------------------- planning
    def _run(self, req: Request, access: Access, *, decision_rows: int | None = None) -> QueryResult:
        m = self.model
        start, end = parse_period(req.period, m.fiscal_year_start_month)
        def_date = dt.date.fromisoformat(req.definitions_as_of) if req.definitions_as_of else end
        known_at, known_src = (req.known_at, "request") if req.known_at else (self.watermark(), "data watermark")
        try:
            k_at = dt.datetime.fromisoformat(str(known_at))
        except ValueError:
            raise QueryError(f"known_at {known_at!r} is not an ISO timestamp") from None
        params = {n: p.default for n, p in m.params.items()}
        for n, v in (req.parameters or {}).items():
            if n not in m.params:
                raise QueryError(f"unknown parameter {n!r}")
            params[n] = m.params[n].coerce(v)
        dims = [self._parse_dim(t) for t in req.dimensions]
        if len({d.token for d in dims}) != len(dims):
            raise QueryError("a dimension is requested twice")
        warnings: list[str] = []
        if k_at.date() < end:
            warnings.append(f"the period ends {end} but data is only known up to {k_at.isoformat()}; "
                            f"facts recorded later are excluded")

        # governance before planning
        for mn in req.metrics:
            if mn not in m.metrics:
                raise QueryError(f"unknown metric {mn!r}")
        check_metrics(m, access, req.metrics, def_date)
        dim_refs = [f"{d.dataset}.{d.field}" for d in dims if d.kind == "field"]
        dim_refs += [f"{m.hierarchies[d.dataset].dataset}.{m.hierarchies[d.dataset].label_field}"
                     for d in dims if d.kind == "hier"]
        check_fields(m, access, dim_refs, "dimension")
        check_fields(m, access, [f.get("field", "") for f in req.filters], "filter field")
        if access.is_agent and dims and decision_rows is None and (req.limit is None or req.limit > access.agent_max_rows):
            raise AccessDenied(f"agents must set a limit of at most {access.agent_max_rows} rows when grouping",
                               code="agent_limit")

        # which metric definitions apply
        needed = list(dict.fromkeys(req.metrics + [d for mn in req.metrics
                                                   for d in metric_closure(m, mn, def_date)]))
        chosen: dict[str, tuple[int, MetricVersion]] = {mn: m.metrics[mn].version_for(def_date) for mn in needed}
        base = [mn for mn in needed if chosen[mn][1].kind == "base"]

        ctx = _Ctx(start, end, k_at.isoformat(), params, dims, req.filters, access)
        per_metric: dict[str, dict[tuple, Decimal | None]] = {}
        sqls: dict[str, str] = {}
        datasets_used: set[str] = set()
        fx_info: dict[str, Any] = {}
        for mn in base:
            sql, binds, used, info = self._plan_base(mn, chosen[mn][1], ctx)
            datasets_used |= used
            sqls[mn] = sql
            if info:
                fx_info[mn] = info
            rows = self._exec(sql, binds)
            vals: dict[tuple, Decimal | None] = {}
            for r in rows:
                key = tuple(r[:len(dims)])
                if chosen[mn][1].additivity == "semi" and chosen[mn][1].semi_method == "average":
                    s, n = r[len(dims)], r[len(dims) + 1]
                    with decimal.localcontext(CONTEXT):
                        vals[key] = None if not n or s is None else to_decimal(s) / Decimal(n)
                else:
                    vals[key] = to_decimal(r[len(dims)])
            per_metric[mn] = vals

        # currency translation (base currency -> requested reporting currency) at the closing rate
        rep = req.reporting_currency or m.reporting_currency
        if rep != m.reporting_currency:
            rate = self._closing_rate(rep, end, ctx)
            for mn in base:
                if m.metrics[mn].unit == "money":
                    with decimal.localcontext(CONTEXT):
                        per_metric[mn] = {k: (None if v is None else v / rate) for k, v in per_metric[mn].items()}
            fx_info["translation"] = {"to": rep, "rate_date": end.isoformat(), "rate": format(rate, "f")}

        keys = sorted({k for vals in per_metric.values() for k in vals}, key=_sort_key)
        if not dims and not keys:
            keys = [()]
        rows_out: list[dict] = []
        order = _topo(m, needed, chosen)
        for key in keys:
            env: dict[str, Any] = dict(params)
            for mn in order:
                ver = chosen[mn][1]
                if ver.kind == "base":
                    v = per_metric[mn].get(key)
                    if v is None and key not in per_metric[mn] and ver.agg in {"count", "count_distinct"}:
                        v = Decimal(0)
                    env[mn] = v
                else:
                    env[mn] = ver.formula.evaluate(env)  # type: ignore[union-attr]
            row = {d.token: key[i] for i, d in enumerate(dims)}
            for mn in req.metrics:
                row[mn] = self._present(mn, env[mn])
            rows_out.append(row)

        rows_out = self._order(rows_out, req, dims)
        if access.is_agent and decision_rows is None and len(rows_out) > (access.agent_max_rows or 0) and dims:
            raise AccessDenied("result exceeds the agent row limit", code="agent_limit")
        columns = [d.token for d in dims] + list(req.metrics)
        data_hashes = {ds: self._data_hash(ds, ctx) for ds in sorted(datasets_used)}
        meta = {
            "model": m.name, "model_version": m.version, "model_hash": m.hash,
            "model_locked": m.lock_status()["locked"],
            "period": req.period, "period_start": start.isoformat(), "period_end": end.isoformat(),
            "known_at": ctx.known_at, "known_at_source": known_src,
            "definitions_as_of": def_date.isoformat(),
            "definitions": {mn: {"version": chosen[mn][0], "effective_from": chosen[mn][1].effective_from.isoformat(),
                                 "kind": chosen[mn][1].kind,
                                 **({"formula": chosen[mn][1].formula.text} if chosen[mn][1].formula else {}),
                                 **({"note": chosen[mn][1].note} if chosen[mn][1].note else {})}
                            for mn in needed},
            "units": {mn: m.metrics[mn].unit for mn in req.metrics},
            "reporting_currency": rep, "parameters": {k: _jsonable(v) for k, v in sorted(params.items())},
            "access": access.to_dict(), "fx": fx_info, "warnings": warnings,
            "data_hashes": data_hashes, "data_hash": canonical_hash(data_hashes),
            "sql": sqls,
        }
        meta["result_hash"] = canonical_hash({"columns": columns, "rows": [
            {k: _jsonable(v) for k, v in r.items()} for r in rows_out]})
        return QueryResult(columns, rows_out, meta)

    def _present(self, mn: str, v: Any) -> Any:
        unit = self.model.metrics[mn].unit
        if not isinstance(v, Decimal):
            return v
        if unit == "money":
            return quantize(v, self.model.money_scale)
        if unit == "count":
            return quantize(v, 0) if v == v.to_integral_value() else quantize(v, self.model.ratio_scale)
        return quantize(v, self.model.ratio_scale)

    def _order(self, rows: list[dict], req: Request, dims: list[Dim]) -> list[dict]:
        tie = [d.token for d in dims]
        for ob in reversed(req.order_by or []):
            fld = ob.get("field")
            if rows and fld not in rows[0]:
                raise QueryError(f"order_by field {fld!r} is not a requested metric or dimension")
            desc = str(ob.get("direction", "asc")).lower() == "desc"
            rows = sorted(rows, key=lambda r: tuple(_sort_key((r[t],)) for t in tie))
            present = [r for r in rows if r[fld] is not None]
            missing = [r for r in rows if r[fld] is None]
            rows = sorted(present, key=lambda r: r[fld], reverse=desc) + missing
        if req.limit is not None:
            if req.limit < 0:
                raise QueryError("limit must be positive")
            rows = rows[:req.limit]
        return rows

    def _parse_dim(self, token: str) -> Dim:
        m = self.model
        if token.startswith("time:"):
            g = token.split(":", 1)[1]
            if g not in GRAINS:
                raise QueryError(f"time grain {g!r} must be one of {sorted(GRAINS)}")
            return Dim(token, "time", grain=g)
        if "@" in token:
            h, _, lvl = token.partition("@")
            if h not in m.hierarchies or not lvl.isdigit() or int(lvl) < 1:
                raise QueryError(f"hierarchy dimension {token!r} must be <hierarchy>@<level>, level >= 1")
            return Dim(token, "hier", dataset=h, level=int(lvl))
        ds, _, f = token.partition(".")
        if ds not in m.datasets or f not in m.datasets[ds].fields:
            raise QueryError(f"unknown dimension {token!r} (use dataset.field, time:<grain> or <hierarchy>@<level>)")
        if not m.datasets[ds].fields[f].dimension:
            raise QueryError(f"{token} is not declared as a dimension")
        return Dim(token, "field", ds, f)

    # ---------------------------------------------------------------- base metric plan
    def _plan_base(self, mn: str, v: MetricVersion, ctx: "_Ctx"):
        m = self.model
        root = m.datasets[v.dataset]  # type: ignore[index]
        binds: dict[str, Any] = {"k_at": ctx.known_at, "p_start": ctx.start.isoformat(),
                                 "p_end": ctx.end.isoformat()}
        binds.update({f"p_{k}": _bind(val) for k, val in ctx.params.items()})
        targets: set[str] = set()
        aliases: dict[str, str] = {root.name: f't_{root.name}'}

        def resolver(home: str):
            def r(ds: str | None, f: str) -> str:
                dsn = ds or home
                if dsn not in m.datasets or f not in m.datasets[dsn].fields:
                    raise KeyError(f"({dsn}.{f})")
                targets.add(dsn)
                return f'{{{dsn}}}."{f}"'
            return r

        def frag(text: str, home: str, where: str) -> str:
            return lint_and_rewrite(text, resolver(home), where=where).sql

        value = "1" if v.expr == "*" else frag(v.expr, root.name, f"{mn}.expr")  # type: ignore[arg-type]
        where: list[str] = []
        if v.filter:
            where.append(f"({frag(v.filter, root.name, f'{mn}.filter')})")
        cur = frag(v.currency, root.name, f"{mn}.currency") if v.currency else None
        for i, f in enumerate(ctx.filters):
            where.append(self._filter_sql(f, i, binds, targets))
        for i, (ds, pred) in enumerate(ctx.access.row_filters):
            try:
                self.model.graph.path(root.name, ds) if ds != root.name else None
            except ModelError:
                raise AccessDenied(f"role {ctx.access.role} has a row filter on {ds}, which metric {mn} cannot "
                                   f"reach; refusing rather than returning unfiltered data",
                                   code="row_filter_unenforceable") from None
            where.append(f"({frag(pred, ds, f'row filter on {ds}')})")
        group: list[str] = []
        hier_joins: list[str] = []
        for d in ctx.dims:
            if d.kind == "field":
                targets.add(d.dataset)  # type: ignore[arg-type]
                group.append(f'{{{d.dataset}}}."{d.field}"')
            elif d.kind == "time":
                if not root.valid_time:
                    raise QueryError(f"metric {mn} has no business date ({root.name} declares no valid_time), "
                                     f"so it cannot be grouped by time")
                group.append(self._bucket(f'{{{root.name}}}."{root.valid_time}"', d.grain))  # type: ignore[arg-type]
            else:
                h = m.hierarchies[d.dataset]  # type: ignore[index]
                targets.add(h.dataset)
                hn = f"hh_{h.name}"
                if hn not in "".join(hier_joins):
                    hier_joins.append(f'LEFT JOIN h_{h.name} AS {hn} ON {hn}.id = {{{h.dataset}}}."{h.id_field}"')
                group.append(f"{hn}.path[least({d.level}, len({hn}.path))]")

        # joins along the grain-safe join tree
        hops: list[Hop] = []
        for t in sorted(targets):
            if t == root.name:
                continue
            try:
                for h in self.model.graph.path(root.name, t):
                    if h not in hops:
                        hops.append(h)
            except ModelError as e:
                raise QueryError(f"metric {mn} (rooted at {root.name}) cannot be broken down by or filtered on "
                                 f"{t}: {e}", code=e.code) from None
        fact_time = (f'{{{root.name}}}."{root.valid_time}"' if root.valid_time else "CAST($p_end AS DATE)")
        joins: list[str] = []
        weights: list[str] = []
        used = {root.name}
        for h in hops:
            r = h.rel
            if not h.reverse:
                dst = m.datasets[r.dst]
                aliases[dst.name] = f"t_{dst.name}"
                cond = " AND ".join(f'{{{r.src}}}."{a}" = {{{r.dst}}}."{b}"' for a, b in zip(r.src_cols, r.dst_cols))
                if r.as_of:
                    vf, vt = dst.scd  # type: ignore[misc]
                    cond += (f' AND {fact_time} >= {{{dst.name}}}."{vf}" AND ({{{dst.name}}}."{vt}" IS NULL '
                             f'OR {fact_time} < {{{dst.name}}}."{vt}")')
                joins.append(f"LEFT JOIN v_{dst.name} AS t_{dst.name} ON {cond}")
                used.add(dst.name)
                self._check_dimension(dst, r.dst_cols, ctx)
            else:
                br = m.datasets[r.src]
                aliases[br.name] = f"t_{br.name}"
                cond = " AND ".join(f'{{{r.src}}}."{a}" = {{{r.dst}}}."{b}"' for a, b in zip(r.src_cols, r.dst_cols))
                joins.append(f"LEFT JOIN v_{br.name} AS t_{br.name} ON {cond}")
                used.add(br.name)
                weights.append(f'{{{br.name}}}."{br.bridge_weight}"')
                self._check_bridge(br, r.src_cols, ctx)
        if weights and v.agg == "count":
            raise QueryError(f"metric {mn}: a plain count cannot be allocated across the {hops[-1].rel.src} "
                             f"bridge; use count_distinct or a weighted sum")
        factors = [f"CAST({w} AS DECIMAL(38,6))" for w in weights] if v.agg == "sum" else []

        info = None
        fx_join = ""
        if v.currency:
            fx = m.fx
            if not fx:
                raise ModelError(f"metric {mn} is money but the model declares no fx block")
            fxd = m.datasets[fx["dataset"]]
            used.add(fxd.name)
            rate_type = v.fx_rate_type or fx.get("default_rate_type", "SPOT")
            binds["fx_type"] = rate_type
            binds["base_ccy"] = m.reporting_currency
            c, d, rt, t = fx["currency_field"], fx["date_field"], fx["rate_field"], fx["type_field"]
            if v.fx_date == "valid_time":
                fx_join = (f'ASOF LEFT JOIN (SELECT * FROM v_{fxd.name} WHERE "{t}" = $fx_type) AS fx '
                           f'ON fx."{c}" = {cur} AND {fact_time} >= fx."{d}"')
            else:  # one closing rate per currency: the latest on or before the period end
                fx_join = (f'LEFT JOIN (SELECT "{c}", max("{d}") AS "{d}", arg_max("{rt}", "{d}") AS "{rt}" '
                           f'FROM v_{fxd.name} WHERE "{t}" = $fx_type AND "{d}" <= CAST($p_end AS DATE) '
                           f'GROUP BY "{c}") AS fx ON fx."{c}" = {cur}')
            factors.append(f"(CASE WHEN {cur} = $base_ccy THEN CAST(1 AS DECIMAL(38,10)) "
                           f'ELSE CAST(fx."{fx["rate_field"]}" AS DECIMAL(38,10)) END)')
            info = {"rate_type": rate_type, "rate_date": v.fx_date, "base_currency": m.reporting_currency,
                    "max_staleness_days": int(fx.get("max_staleness_days", 7))}
        if factors:
            # exact decimal products: amount (scale 4) x share (scale 6) x rate (scale 10) leaves 18 integer
            # digits of headroom per row; an overflow is an engine error, never a silent rounding
            value = f"CAST({value} AS DECIMAL(38,4)) * " + " * ".join(factors)

        if root.valid_time:
            where.append(f'{{{root.name}}}."{root.valid_time}" BETWEEN CAST($p_start AS DATE) AND CAST($p_end AS DATE)')
        agg = {"sum": "SUM({})", "count": "COUNT({})", "count_distinct": "COUNT(DISTINCT {})",
               "min": "MIN({})", "max": "MAX({})"}[v.agg]  # type: ignore[index]
        agg_sql = agg.format("*" if v.expr == "*" and not weights else value)

        ctes = [self.visible_cte(m.datasets[d]) for d in sorted(used)]
        for hname in sorted({d.dataset for d in ctx.dims if d.kind == "hier"}):  # type: ignore[type-var]
            h = m.hierarchies[hname]
            ctes.append(self._hier_cte(h))
            self._check_hierarchy(h, ctx)
        from_sql = f"FROM v_{root.name} AS t_{root.name} " + " ".join(joins + hier_joins) + (" " + fx_join if fx_join else "")
        where_sql = ("WHERE " + " AND ".join(where)) if where else ""

        n = len(group)
        if v.additivity == "semi":
            vt = f'{{{root.name}}}."{root.valid_time}"'
            bucket_of = (lambda col: self._bucket(col, next(d.grain for d in ctx.dims if d.kind == "time"))) \
                if any(d.kind == "time" for d in ctx.dims) else (lambda col: "1")
            tpos = next((i for i, d in enumerate(ctx.dims) if d.kind == "time"), None)
            gsel = ", ".join(f"{g} AS g{i}" for i, g in enumerate(group))
            ctes.append(f'snap AS (SELECT DISTINCT "{root.valid_time}" AS d, {bucket_of(chr(34) + root.valid_time + chr(34))} '
                        f'AS b FROM v_{root.name} WHERE "{root.valid_time}" BETWEEN CAST($p_start AS DATE) AND '
                        f'CAST($p_end AS DATE))')
            ctes.append(f"facts AS (SELECT {gsel + ', ' if gsel else ''}{bucket_of(vt)} AS b, {vt} AS d, "
                        f"{agg_sql} AS v {from_sql} {where_sql} GROUP BY ALL)")
            gcols = ", ".join(f"f.g{i}" for i in range(n))
            if v.semi_method in {"last", "first"}:
                pick = "max" if v.semi_method == "last" else "min"
                ctes.append(f"pick AS (SELECT b, {pick}(d) AS d FROM snap GROUP BY b)")
                body = f"SELECT {gcols + ', ' if gcols else ''}f.v FROM facts f JOIN pick p ON f.b = p.b AND f.d = p.d"
            else:
                ctes.append("nb AS (SELECT b, count(*) AS n FROM snap GROUP BY b)")
                body = (f"SELECT {gcols + ', ' if gcols else ''}sum(f.v) AS v, any_value(nb.n) AS n FROM facts f "
                        f"JOIN nb ON f.b = nb.b GROUP BY {', '.join([f'f.g{i}' for i in range(n)] + ['f.b'])}")
            _ = tpos
        else:
            gsel = ", ".join(group)
            body = f"SELECT {gsel + ', ' if gsel else ''}{agg_sql} AS v {from_sql} {where_sql}" + \
                   (f" GROUP BY {', '.join(str(i + 1) for i in range(n))}" if n else "")
        sql = "WITH RECURSIVE " + ",\n".join(ctes) + "\n" + body
        sql = self._alias(sql, aliases)
        if v.currency or weights:
            fx_time = (fact_time if v.fx_date == "valid_time" else "CAST($p_end AS DATE)") if v.currency else None
            self._check_rows(mn, from_sql, where_sql, cur, weights, info, binds, ctes, aliases, fx_time)
        return sql, binds, used, info

    @staticmethod
    def _alias(sql: str, aliases: dict[str, str]) -> str:
        return re.sub(r"\{([a-z][a-z0-9_]*)\}", lambda mt: aliases.get(mt[1], f"t_{mt[1]}"), sql)

    def _bucket(self, col: str, grain: str) -> str:
        s = self.model.fiscal_year_start_month
        if grain == "day":
            return f"strftime({col}, '%Y-%m-%d')"
        if grain == "month":
            return f"strftime({col}, '%Y-%m')"
        if grain == "quarter":
            return f"concat(year({col}), 'Q', quarter({col}))"
        if grain == "year":
            return f"CAST(year({col}) AS VARCHAR)"
        fy = f"(year({col}) + CASE WHEN month({col}) >= {s} AND {s} > 1 THEN 1 ELSE 0 END)"
        if grain == "fiscal_year":
            return f"concat('FY', {fy})"
        return f"concat('FY', {fy}, 'Q', (month({col}) - {s} + 12) % 12 // 3 + 1)"

    def _filter_sql(self, f: dict, i: int, binds: dict, targets: set[str]) -> str:
        fld = f.get("field", "")
        ds, _, name = fld.partition(".")
        if ds not in self.model.datasets or name not in self.model.datasets[ds].fields:
            raise QueryError(f"filter field {fld!r} must be dataset.field")
        op = str(f.get("op", "=")).lower()
        if op not in OPS:
            raise QueryError(f"filter op {op!r} must be one of {sorted(OPS)}")
        targets.add(ds)
        dtp = self.model.datasets[ds].fields[name].datatype
        cast = {"Date": "DATE", "DateTime": "TIMESTAMP", "DateTimeTz": "TIMESTAMPTZ", "Integer": "BIGINT",
                "Decimal": "DECIMAL(38,10)", "Boolean": "BOOLEAN"}.get(dtp or "", "VARCHAR")
        col = f'{{{ds}}}."{name}"'
        if op in {"in", "not_in", "between"}:
            vals = f.get("values")
            if not isinstance(vals, list) or not vals or (op == "between" and len(vals) != 2):
                raise QueryError(f"filter {fld} {op} needs 'values' ({'two' if op == 'between' else 'a list'})")
            names = []
            for j, val in enumerate(vals):
                binds[f"f{i}_{j}"] = _bind(val)
                names.append(f"CAST($f{i}_{j} AS {cast})")
            if op == "between":
                return f"{col} BETWEEN {names[0]} AND {names[1]}"
            return f"{col} {OPS[op]} ({', '.join(names)})"
        if "value" not in f:
            raise QueryError(f"filter {fld} {op} needs a 'value'")
        binds[f"f{i}"] = _bind(f["value"])
        return f"{col} {OPS[op]} CAST($f{i} AS {cast})"

    def _hier_cte(self, h) -> str:
        return (f'h_{h.name} AS (SELECT id, path FROM (WITH RECURSIVE walk(id, path, depth) AS ('
                f'SELECT "{h.id_field}", ["{h.label_field}"], 1 FROM v_{h.dataset} WHERE "{h.parent_field}" IS NULL '
                f'UNION ALL SELECT c."{h.id_field}", list_append(w.path, c."{h.label_field}"), w.depth + 1 '
                f'FROM v_{h.dataset} c JOIN walk w ON c."{h.parent_field}" = w.id WHERE w.depth < 64) '
                f"SELECT * FROM walk))")

    def _closing_rate(self, ccy: str, end: dt.date, ctx: "_Ctx") -> Decimal:
        fx = self.model.fx
        if not fx:
            raise QueryError("reporting in another currency needs an fx block in the model")
        fxd = self.model.datasets[fx["dataset"]]
        rtype = fx.get("closing_rate_type", "MONTH_END")
        rows = self._exec(
            f'WITH {self.visible_cte(fxd)} SELECT "{fx["rate_field"]}", "{fx["date_field"]}" FROM v_{fxd.name} '
            f'WHERE "{fx["currency_field"]}" = $c AND "{fx["type_field"]}" = $t AND "{fx["date_field"]}" <= CAST($e AS DATE) '
            f'ORDER BY "{fx["date_field"]}" DESC LIMIT 1',
            {"c": ccy, "t": rtype, "e": end.isoformat(), "k_at": ctx.known_at})
        row = rows[0] if rows else None
        if not row:
            raise DataIntegrityError(f"no {rtype} {ccy} rate on or before {end} to translate into {ccy}")
        if (end - row[1]).days > int(fx.get("max_staleness_days", 7)):
            raise DataIntegrityError(f"latest {rtype} {ccy} rate is from {row[1]}, too stale for {end}")
        return to_decimal(row[0])

    # ---------------------------------------------------------------- execution & checks
    def _exec(self, sql: str, binds: dict) -> list[tuple]:
        names = set(re.findall(r"\$([A-Za-z_][A-Za-z0-9_]*)", sql))
        try:
            return self.con.execute(sql, {k: v for k, v in binds.items() if k in names}).fetchall()
        except duckdb.Error as e:
            raise QueryError(f"engine error: {e}", code="engine_error") from None

    def _once(self, key: tuple, fn) -> None:
        if key not in self._checked:
            fn()
            self._checked.add(key)

    def _check_dimension(self, ds: Dataset, keys: list[str], ctx: "_Ctx") -> None:
        def run():
            kc = ", ".join(f'"{k}"' for k in keys)
            if ds.scd:
                vf, vt = ds.scd
                sql = (f"WITH {self.visible_cte(ds)} SELECT count(*) FROM (SELECT \"{vf}\" AS vf, lag(\"{vt}\") OVER "
                       f"(PARTITION BY {kc} ORDER BY \"{vf}\") AS pvt, row_number() OVER (PARTITION BY {kc} ORDER BY "
                       f"\"{vf}\") AS rn FROM v_{ds.name}) WHERE rn > 1 AND (pvt IS NULL OR vf < pvt)")
                bad = self._exec(sql, {"k_at": ctx.known_at})[0][0]
                if bad:
                    raise DataIntegrityError(f"{ds.name}: {bad} type-2 versions overlap in time; an as-of join "
                                             f"would match more than one version")
            else:
                sql = (f"WITH {self.visible_cte(ds)} SELECT count(*) FROM (SELECT {kc} FROM v_{ds.name} "
                       f"GROUP BY ALL HAVING count(*) > 1)")
                bad = self._exec(sql, {"k_at": ctx.known_at})[0][0]
                if bad:
                    raise DataIntegrityError(f"{ds.name}: {bad} key values appear more than once; joining it would "
                                             f"duplicate facts")
        self._once(("dim", ds.name, tuple(keys), ctx.known_at), run)
        self._check_versions(ds, ctx)

    def _check_versions(self, ds: Dataset, ctx: "_Ctx") -> None:
        if not ds.knowledge_time:
            return

        def run():
            pk = ", ".join(f'"{k}"' for k in ds.primary_key)
            sql = (f'SELECT count(*) FROM (SELECT {pk}, "{ds.knowledge_time}" FROM ({self._base_select(ds)}) '
                   f'WHERE "{ds.knowledge_time}" <= CAST($k_at AS TIMESTAMP) GROUP BY ALL HAVING count(*) > 1)')
            bad = self._exec(sql, {"k_at": ctx.known_at})[0][0]
            if bad:
                raise DataIntegrityError(f"{ds.name}: {bad} keys have two versions recorded at the same instant; "
                                         f"the current version is ambiguous")
        self._once(("ver", ds.name, ctx.known_at), run)

    def _check_bridge(self, br: Dataset, cols: list[str], ctx: "_Ctx") -> None:
        def run():
            kc = ", ".join(f'"{c}"' for c in cols)
            sql = (f'WITH {self.visible_cte(br)} SELECT count(*) FROM (SELECT {kc}, sum("{br.bridge_weight}") AS s '
                   f"FROM v_{br.name} GROUP BY ALL) WHERE s <> 1")
            bad = self._exec(sql, {"k_at": ctx.known_at})[0][0]
            if bad:
                raise DataIntegrityError(f"{br.name}: allocation weights do not sum to 1 for {bad} keys; totals "
                                         f"would not be preserved")
        self._once(("bridge", br.name, ctx.known_at), run)
        self._check_versions(br, ctx)

    def _check_hierarchy(self, h, ctx: "_Ctx") -> None:
        def run():
            ds = self.model.datasets[h.dataset]
            sql = (f"WITH RECURSIVE {self.visible_cte(ds)}, {self._hier_cte(h)} SELECT (SELECT count(*) FROM "
                   f"v_{ds.name}), (SELECT count(DISTINCT id) FROM h_{h.name}), (SELECT count(*) FROM h_{h.name})")
            total, reached, rows = self._exec(sql, {"k_at": ctx.known_at})[0]
            if total != reached or rows != reached:
                raise DataIntegrityError(f"hierarchy {h.name}: {total - reached} nodes are orphaned or in a cycle, "
                                         f"or a node has two parents")
        self._once(("hier", h.name, ctx.known_at), run)

    def _check_rows(self, mn, from_sql, where_sql, cur, weights, info, binds, ctes, aliases, fx_time) -> None:
        checks = []
        if cur:
            fx = self.model.fx
            checks.append(f"count(*) FILTER (WHERE {cur} IS NULL)")
            checks.append(f'count(*) FILTER (WHERE {cur} <> $base_ccy AND fx."{fx["rate_field"]}" IS NULL)')
            checks.append(f'count(*) FILTER (WHERE {cur} <> $base_ccy AND date_diff(\'day\', fx."{fx["date_field"]}", '
                          f'{fx_time}) > {info["max_staleness_days"]})')
        else:
            checks += ["0", "0", "0"]
        checks.append(" + ".join(f"count(*) FILTER (WHERE {w} IS NULL)" for w in weights) if weights else "0")
        sql = self._alias("WITH RECURSIVE " + ",\n".join(c for c in ctes if not c.startswith(("snap", "facts", "pick", "nb")))
                          + f"\nSELECT {', '.join(checks)} {from_sql} {where_sql}", aliases)
        no_ccy, no_rate, stale, unalloc = self._exec(sql, binds)[0]
        if no_ccy:
            raise DataIntegrityError(f"metric {mn}: {no_ccy} rows have no currency code")
        if no_rate:
            raise DataIntegrityError(f"metric {mn}: {no_rate} rows have no {info['rate_type']} FX rate on or before "
                                     f"their {info['rate_date']}; refusing to guess a rate")
        if stale:
            raise DataIntegrityError(f"metric {mn}: {stale} rows would use an FX rate older than "
                                     f"{info['max_staleness_days']} days")
        if unalloc:
            raise DataIntegrityError(f"metric {mn}: {unalloc} rows have no allocation in the bridge; their amounts "
                                     f"would be dropped")

    def _data_hash(self, ds_name: str, ctx: "_Ctx") -> str:
        ds = self.model.datasets[ds_name]
        sql = (f"WITH {self.visible_cte(ds)} SELECT sha256(coalesce(string_agg(CAST(to_json(x) AS VARCHAR), chr(10) "
               f"ORDER BY CAST(to_json(x) AS VARCHAR)), '')), count(*) FROM v_{ds.name} x")
        h, n = self._exec(sql, {"k_at": ctx.known_at})[0]
        return f"{h}:{n}"

    def dataset_hashes(self, known_at: str | None = None) -> dict:
        ctx = _Ctx(dt.date.min, dt.date.max, known_at or self.watermark(), {}, [], [], None)  # type: ignore[arg-type]
        return {d: self._data_hash(d, ctx) for d in sorted(self.model.datasets)}


@dataclass
class _Ctx:
    start: dt.date
    end: dt.date
    known_at: str
    params: dict
    dims: list[Dim]
    filters: list[dict]
    access: Access


def _bind(v: Any) -> Any:
    if isinstance(v, Decimal):
        return format(v, "f")
    if isinstance(v, (dt.date, dt.datetime)):
        return v.isoformat()
    if isinstance(v, float):
        raise QueryError(f"floating-point value {v!r} is not allowed; pass decimals as strings")
    return v


def _sort_key(key: tuple) -> tuple:
    return tuple((v is None, str(type(v).__name__), v if v is not None else 0) for v in key)


def _topo(model: Model, names: list[str], chosen: dict) -> list[str]:
    done: list[str] = []

    def visit(n: str) -> None:
        if n in done:
            return
        v = chosen[n][1]
        if v.formula:
            for d in sorted(v.formula.names):
                if d in model.metrics:
                    visit(d)
        done.append(n)

    for n in names:
        visit(n)
    return done
