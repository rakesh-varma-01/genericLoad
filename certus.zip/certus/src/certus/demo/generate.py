"""Deterministic synthetic retail bank ("Acme Bank") for the Certus demo.

Fictional and generated from a fixed seed: no real customer, account or institution data.
The data deliberately contains the situations that break naive semantic layers:

* multi-currency deposit accounts (EUR, GBP, MXN) with daily SPOT and MONTH_END FX rates
* joint accounts (an allocation bridge with 50/50 ownership)
* customer risk ratings that change over time (a type-2 dimension)
* a large wire that was posted, flagged, and later reversed (a tombstoned version)
* a December 2025 loan balance that was restated two weeks after month end (bitemporal)
* a ragged organisation hierarchy (a private-bank branch with no region)
"""
from __future__ import annotations

import csv
import datetime as dt
import random
from decimal import Decimal
from pathlib import Path

import duckdb

SEED = 20261101
START, END = dt.date(2024, 1, 1), dt.date(2025, 12, 31)

ORG = [  # unit_id, parent_id, name, level
    (1, None, "Acme Bank Group", "Group"),
    (2, 1, "Acme Bank N.A.", "Legal entity"),
    (3, 1, "Acme Private Bank", "Legal entity"),
    (4, 2, "South", "Region"), (5, 2, "Northeast", "Region"), (6, 2, "Midwest", "Region"), (7, 2, "West", "Region"),
]
BRANCHES = [  # id, name, city, state, region, org_unit
    (1, "Dallas Main", "Dallas", "TX", "South", 4), (2, "Plano Legacy", "Plano", "TX", "South", 4),
    (3, "Houston Galleria", "Houston", "TX", "South", 4), (4, "Austin Domain", "Austin", "TX", "South", 4),
    (5, "Manhattan Midtown", "New York", "NY", "Northeast", 5), (6, "Brooklyn Heights", "New York", "NY", "Northeast", 5),
    (7, "Boston Back Bay", "Boston", "MA", "Northeast", 5), (8, "Chicago Loop", "Chicago", "IL", "Midwest", 6),
    (9, "Columbus Short North", "Columbus", "OH", "Midwest", 6), (10, "San Jose Downtown", "San Jose", "CA", "West", 7),
    (11, "Los Angeles Wilshire", "Los Angeles", "CA", "West", 7), (12, "Phoenix Camelback", "Phoenix", "AZ", "West", 7),
    (13, "Private Bank Dallas", "Dallas", "TX", "Private", 3),
]
PRODUCTS = [("Checking", "DEPOSIT", 38), ("Savings", "DEPOSIT", 25), ("Money Market", "DEPOSIT", 10),
            ("Credit Card", "CREDIT", 20), ("Personal Loan", "CREDIT", 7)]
CHANNELS = [("Card", 40), ("Online", 25), ("ATM", 12), ("Branch", 10), ("Wire", 5), ("Mobile Check", 8)]
FIRST = ["James", "Mary", "Robert", "Patricia", "John", "Jennifer", "Michael", "Linda", "Ana", "Wei", "Ravi",
         "Sofia", "Omar", "Yuki", "Priya", "Diego"]
LAST = ["Smith", "Johnson", "Garcia", "Miller", "Davis", "Chen", "Patel", "Kim", "Nguyen", "Khan", "Lopez", "Silva"]
FX_BASE = {"EUR": 1.0850, "GBP": 1.2700, "MXN": 0.0550}

SCHEMA = {
    "org_unit": "unit_id INTEGER, parent_id INTEGER, unit_name VARCHAR, level_name VARCHAR",
    "branch": "branch_id INTEGER, branch_name VARCHAR, city VARCHAR, state VARCHAR, region VARCHAR, "
              "headcount INTEGER, org_unit_id INTEGER",
    "customer": "customer_id INTEGER, customer_number VARCHAR, full_name VARCHAR, email VARCHAR, phone VARCHAR, "
                "birth_year INTEGER, segment VARCHAR, home_state VARCHAR, recorded_at TIMESTAMP",
    "customer_risk": "customer_id INTEGER, risk_rating VARCHAR, valid_from DATE, valid_to DATE, recorded_at TIMESTAMP",
    "account": "account_id INTEGER, account_number VARCHAR, branch_id INTEGER, product_type VARCHAR, "
               "product_family VARCHAR, currency VARCHAR, credit_limit DECIMAL(18,2), status VARCHAR, open_date DATE, "
               "recorded_at TIMESTAMP",
    "account_owner": "account_id INTEGER, customer_id INTEGER, share DECIMAL(9,6), recorded_at TIMESTAMP",
    "txn": "txn_id BIGINT, account_id INTEGER, customer_id INTEGER, txn_date DATE, channel VARCHAR, direction VARCHAR, "
           "amount DECIMAL(18,2), fee_amount DECIMAL(18,2), is_flagged INTEGER, is_void BOOLEAN, recorded_at TIMESTAMP",
    "balance_snapshot": "account_id INTEGER, snapshot_date DATE, balance DECIMAL(18,2), recorded_at TIMESTAMP",
    "fx_rate": "currency VARCHAR, rate_date DATE, rate_type VARCHAR, rate DECIMAL(18,8), recorded_at TIMESTAMP",
}


def _pick(rng: random.Random, weighted):
    return rng.choices([w[0] for w in weighted], weights=[w[-1] for w in weighted], k=1)[0]


def _money(cents: int) -> str:
    sign = "-" if cents < 0 else ""
    return f"{sign}{abs(cents) // 100}.{abs(cents) % 100:02d}"


def _ts(d: dt.date, hour: int = 6) -> str:
    return f"{d.isoformat()} {hour:02d}:00:00"


def D_last(rows, aid) -> Decimal:
    return Decimal(next(r[2] for r in rows if r[0] == aid and r[1] == END.isoformat()))


def month_ends(start: dt.date, end: dt.date):
    y, m = start.year, start.month
    while True:
        nxt = dt.date(y + (m == 12), m % 12 + 1, 1)
        me = nxt - dt.timedelta(days=1)
        if me > end:
            return
        yield me
        y, m = nxt.year, nxt.month


def generate(profile: str = "full") -> dict[str, list[tuple]]:
    n_cust, n_acct, n_txn = {"full": (1500, 2500, 60000), "small": (200, 350, 6000)}[profile]
    t: dict[str, list[tuple]] = {k: [] for k in SCHEMA}
    t["org_unit"] = list(ORG)
    rng = random.Random(SEED + 1)
    t["branch"] = [(b[0], b[1], b[2], b[3], b[4], rng.randint(8, 60), b[5]) for b in BRANCHES]

    rng = random.Random(SEED + 2)
    for i in range(1, n_cust + 1):
        fn, ln = rng.choice(FIRST), rng.choice(LAST)
        seg = _pick(rng, [("Retail", 72), ("Small Business", 20), ("Private Banking", 8)])
        t["customer"].append((i, f"CUS{i:07d}", f"{fn} {ln}", f"{fn.lower()}.{ln.lower()}.{i}@example.invalid",
                              f"555-01{i % 100:02d}", rng.randint(1945, 2004), seg,
                              rng.choice(["TX", "NY", "MA", "IL", "OH", "CA", "AZ", "FL"]), _ts(dt.date(2023, 12, 1))))
        rating = _pick(rng, [("LOW", 75), ("MEDIUM", 20), ("HIGH", 5)])
        if rng.random() < 0.15:  # rating changes once during the period
            change = START + dt.timedelta(days=rng.randint(60, (END - START).days - 60))
            new = {"LOW": "MEDIUM", "MEDIUM": "HIGH", "HIGH": "MEDIUM"}[rating]
            t["customer_risk"].append((i, rating, "2018-01-01", change.isoformat(), _ts(dt.date(2023, 12, 1))))
            t["customer_risk"].append((i, new, change.isoformat(), None, _ts(change)))
        else:
            t["customer_risk"].append((i, rating, "2018-01-01", None, _ts(dt.date(2023, 12, 1))))

    rng = random.Random(SEED + 3)
    accounts = []
    for i in range(1, n_acct + 1):
        ptype = _pick(rng, PRODUCTS)
        fam = next(f for p, f, _ in PRODUCTS if p == ptype)
        branch = 13 if rng.random() < 0.04 else rng.randint(1, 12)
        ccy = "USD"
        if fam == "DEPOSIT":
            ccy = _pick(rng, [("USD", 85), ("EUR", 6), ("GBP", 4), ("MXN", 5)])
        limit = _money(rng.randint(20, 300) * 10000) if ptype == "Credit Card" else None
        opened = dt.date(2018, 1, 1) + dt.timedelta(days=rng.randint(0, (dt.date(2025, 9, 30) - dt.date(2018, 1, 1)).days))
        status = "OPEN" if rng.random() > 0.08 else "DORMANT"
        owners = [rng.randint(1, n_cust)]
        if rng.random() < 0.2:
            other = rng.randint(1, n_cust)
            if other != owners[0]:
                owners.append(other)
        accounts.append((i, fam, ptype, ccy, opened, owners))
        t["account"].append((i, f"ACC{i:09d}", branch, ptype, fam, ccy, limit, status, opened.isoformat(),
                             _ts(max(opened, dt.date(2023, 12, 1)))))
        share = "1.000000" if len(owners) == 1 else "0.500000"
        for c in owners:
            t["account_owner"].append((i, c, share, _ts(max(opened, dt.date(2023, 12, 1)))))

    rng = random.Random(SEED + 4)
    span = (END - START).days
    for i in range(1, n_txn + 1):
        acct = rng.choice(accounts)
        aid, fam, ptype, ccy, opened, owners = acct
        day = START + dt.timedelta(days=rng.randint(0, span))
        channel = _pick(rng, CHANNELS)
        direction = ("CREDIT" if rng.random() < 0.46 else "DEBIT") if fam == "DEPOSIT" else \
                    ("DEBIT" if rng.random() < 0.62 else "CREDIT")
        cents = rng.randint(50000, 2500000) if channel == "Wire" else rng.randint(300, 40000) if channel == "Card" \
            else rng.randint(100, 300000)
        fee = 0
        if channel == "Wire":
            fee = 2500 if direction == "DEBIT" else 1500
        elif channel == "ATM" and rng.random() < 0.3:
            fee = 300
        elif fam == "CREDIT" and direction == "DEBIT" and rng.random() < 0.05:
            fee = 3900
        flagged = 1 if rng.random() < (0.06 if channel == "Wire" else 0.01) else 0
        t["txn"].append((i, aid, rng.choice(owners), day.isoformat(), channel, direction, _money(cents),
                         _money(fee), flagged, False, _ts(day + dt.timedelta(days=1), 2)))
    # A $480,000 wire posted and flagged on 2025-11-10, reversed (voided) on 2025-11-20.
    rev_id = n_txn + 1
    t["txn"].append((rev_id, 1, accounts[0][5][0], "2025-11-10", "Wire", "DEBIT", "480000.00", "25.00", 1, False,
                     _ts(dt.date(2025, 11, 11), 2)))
    t["txn"].append((rev_id, 1, accounts[0][5][0], "2025-11-10", "Wire", "DEBIT", "480000.00", "25.00", 1, True,
                     _ts(dt.date(2025, 11, 20), 9)))

    rng = random.Random(SEED + 5)
    restate = None
    for aid, fam, ptype, ccy, opened, owners in accounts:
        base = {"Checking": 450000, "Savings": 1800000, "Money Market": 5500000, "Credit Card": 260000,
                "Personal Loan": 1400000}[ptype]
        level = rng.randint(base // 4, base * 2)
        cap = None
        if ptype == "Credit Card":
            cap = int(float(t["account"][aid - 1][6]) * 100)  # cents
            level = rng.randint(cap // 20, cap * 19 // 20)
        if ccy == "MXN":
            level *= 18
        for me in month_ends(START, END):
            if me < opened:
                continue
            level = max(0, int(level * (1 + rng.uniform(-0.06, 0.08))))
            if cap is not None:
                level = min(level, cap * 102 // 100)  # a little over-limit is possible
            t["balance_snapshot"].append((aid, me.isoformat(), _money(level), _ts(me + dt.timedelta(days=2))))
            if restate is None and me == END and ptype == "Personal Loan" and t["account"][aid - 1][2] == 10:
                restate = (aid, level)
    # December 2025 restatement: a $500,000 loan disbursement on a San Jose (West region) personal
    # loan was booked twice in the load of 2026-01-02 and corrected on 2026-01-15.
    if restate is None:  # small profiles may have no personal loan in San Jose: use any personal loan
        aid = next(a[0] for a in accounts if a[2] == "Personal Loan" and a[4] <= dt.date(2025, 11, 30))
        level = int(D_last(t["balance_snapshot"], aid) * 100)
        restate = (aid, level)
    aid, level = restate  # type: ignore[misc]
    t["balance_snapshot"] = [r for r in t["balance_snapshot"] if not (r[0] == aid and r[1] == END.isoformat())]
    t["balance_snapshot"].append((aid, END.isoformat(), _money(level + 50000000), _ts(dt.date(2026, 1, 2))))
    t["balance_snapshot"].append((aid, END.isoformat(), _money(level), _ts(dt.date(2026, 1, 15), 10)))

    rng = random.Random(SEED + 6)
    d = dt.date(2023, 11, 1)
    rates = dict(FX_BASE)
    ends = set(month_ends(d, END))
    last_spot: dict[str, float] = {}
    while d <= END:
        if d.weekday() < 5:
            for c in sorted(rates):
                rates[c] *= 1 + rng.uniform(-0.004, 0.004)
                last_spot[c] = rates[c]
                t["fx_rate"].append((c, d.isoformat(), "SPOT", f"{rates[c]:.8f}", _ts(d, 18)))
        if d in ends:
            for c in sorted(last_spot):
                t["fx_rate"].append((c, d.isoformat(), "MONTH_END", f"{last_spot[c]:.8f}", _ts(d, 20)))
        d += dt.timedelta(days=1)
    return t


def write(out_dir: str | Path, profile: str = "full") -> dict[str, int]:
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    tables = generate(profile)
    con = duckdb.connect()
    counts = {}
    for name, rows in tables.items():
        tmp = out / f".{name}.csv"
        with tmp.open("w", newline="") as fh:
            w = csv.writer(fh)
            for r in rows:
                w.writerow(["" if v is None else v for v in r])
        cols = ", ".join(f"'{c.split()[0]}': '{' '.join(c.split()[1:])}'" for c in SCHEMA[name].split(", "))
        target = out / f"{name}.parquet"
        con.execute(f"COPY (SELECT * FROM read_csv('{tmp}', header=false, columns={{{cols}}}, nullstr='')) "
                    f"TO '{target}' (FORMAT parquet)")
        tmp.unlink()
        counts[name] = len(rows)
    return counts


if __name__ == "__main__":
    import sys
    print(write(sys.argv[1] if len(sys.argv) > 1 else "data"))
