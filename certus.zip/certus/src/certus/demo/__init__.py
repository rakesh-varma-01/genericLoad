"""The Acme Bank demonstration: synthetic data, a model and an identity directory."""
