"""Exception types. Every refusal names a stable code so callers can branch on it."""


class CertusError(Exception):
    code = "error"

    def __init__(self, message: str, *, code: str | None = None, details: dict | None = None):
        super().__init__(message)
        if code:
            self.code = code
        self.details = details or {}

    def to_dict(self) -> dict:
        return {"error": str(self), "code": self.code, **({"details": self.details} if self.details else {})}


class ModelError(CertusError):
    """The model document is invalid. Raised at load time, never at query time."""
    code = "model_invalid"


class QueryError(CertusError):
    """The request is malformed or cannot be answered correctly, so it is refused."""
    code = "query_invalid"


class AccessDenied(CertusError):
    """Governance refused the request before any SQL ran."""
    code = "access_denied"


class DataIntegrityError(CertusError):
    """The visible data violates a declared contract (duplicate versions, bad allocations, missing FX)."""
    code = "data_integrity"


class LedgerError(CertusError):
    code = "ledger_invalid"
