"""Command line interface: ``certus <command>``."""
from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path

from . import __version__
from .errors import CertusError


def _table(columns: list[str], rows: list[dict]) -> str:
    if not rows:
        return "(no rows)"
    cells = [[("" if r.get(c) is None else str(r.get(c))) for c in columns] for r in rows]
    widths = [max(len(c), *(len(row[i]) for row in cells)) for i, c in enumerate(columns)]
    num = [all(_isnum(row[i]) for row in cells) for i in range(len(columns))]
    line = lambda vals: "  ".join(v.rjust(w) if n else v.ljust(w) for v, w, n in zip(vals, widths, num))  # noqa: E731
    return "\n".join([line(columns), line(["-" * w for w in widths])] + [line(r) for r in cells])


def _isnum(s: str) -> bool:
    try:
        float(s)
        return True
    except ValueError:
        return s == ""


def _parse_filter(text: str) -> dict:
    parts = text.split(None, 2)
    if len(parts) < 3:
        raise CertusError(f"filter {text!r} must be 'dataset.field op value'", code="bad_filter")
    field, op, value = parts
    op = op.lower()
    if op in {"in", "not_in", "between"}:
        return {"field": field, "op": op, "values": [v.strip() for v in value.split(",")]}
    return {"field": field, "op": op, "value": value}


def _params(items: list[str] | None) -> dict:
    out = {}
    for it in items or []:
        k, sep, v = it.partition("=")
        if not sep:
            raise CertusError(f"--param {it!r} must be name=value", code="bad_param")
        out[k.strip()] = v.strip()
    return out


def _who(args) -> str:
    who = args.as_ or os.environ.get("CERTUS_PRINCIPAL")
    if not who:
        raise CertusError("say who is asking: --as <principal> or CERTUS_PRINCIPAL", code="unknown_principal")
    return who


def _ws(args):
    from .workspace import open_workspace
    return open_workspace(args.model, args.directory, args.ledger)


def _print(obj) -> None:
    print(json.dumps(obj, indent=2, default=str))


def cmd_init(args) -> int:
    from .workspace import init_demo
    info = init_demo(args.folder, args.profile)
    print(f"Demo bank created in {info['folder']}")
    for k, v in info["rows"].items():
        print(f"  {k:<18} {v:>7,} rows")
    print("\nNext:\n  cd " + args.folder + "\n  certus validate\n  certus lock --approver \"<your name>\"\n"
          "  certus query --as tess.treasury -m deposit_balance,loan_to_deposit_ratio -p 2025 -d branch.region\n"
          "  certus decide liquidity_watch --as tess.treasury -p 2025-12\n  certus ui")
    return 0


def cmd_validate(args) -> int:
    from .workspace import open_workspace
    ws = open_workspace(args.model, args.directory, args.ledger)
    m = ws.model
    print(f"OK  {m.name} {m.version}  hash {m.hash[:16]}")
    print(f"    {len(m.datasets)} datasets, {len(m.relationships)} relationships, {len(m.metrics)} metrics "
          f"({sum(1 for x in m.metrics.values() if x.status == 'certified')} certified), {len(m.decisions)} decisions, "
          f"{len(m.roles)} roles, {len(ws.engine.directory)} principals")
    lock = m.lock_status()
    print("    lock: " + (f"approved by {lock['lock']['approved_by']} at {lock['lock']['approved_at']}" if lock["locked"]
                          else f"NOT LOCKED ({lock['reason']}); certified decisions will refuse to run"))
    return 0


def cmd_lock(args) -> int:
    from .model import lock_model
    from .workspace import open_workspace
    ws = open_workspace(args.model, args.directory, args.ledger)
    lock = lock_model(ws.model, args.approver, args.note or "")
    ws.ledger.append("model_lock", lock, None)
    print(f"Locked {lock['model']} {lock['model_version']} hash {lock['model_hash'][:16]} approved by {args.approver}")
    return 0


def cmd_metrics(args) -> int:
    ws = _ws(args)
    rows = []
    for mn, met in ws.model.metrics.items():
        v = met.versions[-1]
        rows.append({"metric": mn, "status": met.status, "unit": met.unit, "kind": v.kind,
                     "versions": len(met.versions), "owner": met.owner,
                     "classification": ",".join(sorted(met.classification))})
    if args.json:
        _print(rows)
    else:
        print(_table(list(rows[0]), rows))
    return 0


def cmd_describe(args) -> int:
    ws = _ws(args)
    m = ws.model
    if args.name not in m.metrics:
        raise CertusError(f"unknown metric {args.name}", code="unknown_metric")
    met = m.metrics[args.name]
    out = {"metric": met.name, "status": met.status, "unit": met.unit, "owner": met.owner, "steward": met.steward,
           "approved_by": met.approved_by, "description": met.description,
           "classification": sorted(met.classification), "concept": met.concept, "ai_context": met.ai_context,
           "versions": []}
    for i, v in enumerate(met.versions, 1):
        d = {"version": i, "effective_from": v.effective_from.isoformat(), "kind": v.kind}
        if v.kind == "derived":
            d["formula"] = v.formula.text
        else:
            d.update({"dataset": v.dataset, "agg": v.agg, "expr": v.expr, "filter": v.filter,
                      "additivity": v.additivity + (f" ({v.semi_method})" if v.additivity == "semi" else ""),
                      "currency": v.currency, "fx_rate_type": v.fx_rate_type, "fx_date": v.fx_date if v.currency else None})
        if v.note:
            d["note"] = v.note
        out["versions"].append({k: val for k, val in d.items() if val is not None})
    _print(out)
    return 0


def cmd_query(args) -> int:
    ws = _ws(args)
    req = {"metrics": [s.strip() for s in args.metrics.split(",") if s.strip()], "period": args.period}
    if args.dims:
        req["dimensions"] = [s.strip() for s in args.dims.split(",") if s.strip()]
    if args.filter:
        req["filters"] = [_parse_filter(f) for f in args.filter]
    for k, attr in (("known_at", "known_at"), ("reporting_currency", "currency"), ("limit", "limit"),
                    ("role", "role"), ("definitions_as_of", "definitions_as_of")):
        if getattr(args, attr) is not None:
            req[k] = getattr(args, attr)
    if args.param:
        req["parameters"] = _params(args.param)
    if args.order:
        req["order_by"] = [{"field": o.split(":")[0], "direction": (o.split(":") + ["asc"])[1]} for o in args.order]
    res = ws.engine.query(req, _who(args))
    if args.json:
        _print(res.to_dict())
        return 0
    print(_table(res.columns, [{k: (format(v, "f") if hasattr(v, "is_finite") else v) for k, v in r.items()}
                               for r in res.rows]))
    meta = res.meta
    print(f"\nperiod {meta['period']} ({meta['period_start']}..{meta['period_end']})  known at {meta['known_at']} "
          f"[{meta['known_at_source']}]  currency {meta['reporting_currency']}  role {meta['access']['role']}")
    print(f"result {meta['result_hash'][:16]}  data {meta['data_hash'][:16]}  model {meta['model_hash'][:16]}"
          f"{'' if meta['model_locked'] else '  (model not locked)'}")
    for w in meta["warnings"]:
        print(f"warning: {w}")
    if args.explain:
        print("\ndefinitions:")
        for mn, d in meta["definitions"].items():
            print(f"  {mn}: v{d['version']} from {d['effective_from']} ({d['kind']})"
                  + (f"  {d['formula']}" if "formula" in d else "") + (f"  -- {d['note']}" if "note" in d else ""))
        if meta["fx"]:
            print("fx:", json.dumps(meta["fx"]))
        print("data hashes:")
        for ds, h in meta["data_hashes"].items():
            print(f"  {ds:<18} {h[:16]}  ({h.split(':')[1]} rows visible)")
        if args.sql:
            for mn, sql in meta["sql"].items():
                print(f"\n-- {mn}\n{sql}")
    return 0


def cmd_decide(args) -> int:
    from .decisions import run_decision
    ws = _ws(args)
    run = run_decision(ws.engine, args.name, period=args.period, principal=_who(args), role=args.role,
                       known_at=args.known_at, parameters=_params(args.param), ledger=None if args.dry_run else ws.ledger,
                       allow_unlocked=args.allow_unlocked)
    rec = run.record
    if args.json:
        _print({"record": rec, "ledger_seq": run.ledger_entry and run.ledger_entry["seq"]})
        return 0
    cols = rec["grain"] + list(rec["outcomes"][0]["inputs"]) + ["outcome", "rule"] if rec["outcomes"] else []
    rows = [{**{g: o[g] for g in rec["grain"]}, **o["inputs"], "outcome": o["outcome"], "rule": o["rule"]}
            for o in rec["outcomes"]]
    print(f"{rec['decision']} v{rec['decision_version']} ({rec['decision_status']}, owner {rec['owner']}, approved by "
          f"{rec['approved_by']})  period {rec['period']}  known at {rec['known_at']}")
    print(_table(cols, rows))
    print("\nsummary: " + ", ".join(f"{k} {v}" for k, v in rec["summary"].items()))
    print(f"decision id {rec['decision_id']}")
    print(f"result {rec['result_hash'][:16]}  data {rec['data_hash'][:16]}  model {rec['model_hash'][:16]}")
    if run.ledger_entry:
        print(f"recorded as ledger entry #{run.ledger_entry['seq']} in {ws.ledger.path.name}")
    if args.why:
        print()
        for o in rec["outcomes"]:
            key = ", ".join(f"{g}={o[g]}" for g in rec["grain"]) or "(portfolio)"
            print(f"{key}: {o['outcome']}  because {o['reason']}" + (f"  -> {o['action']}" if o["action"] else ""))
    return 0


def cmd_replay(args) -> int:
    from .decisions import replay
    ws = _ws(args)
    entry = ws.ledger.find(args.id)
    report = replay(ws.engine, entry["payload"], principal=_who(args), ledger=ws.ledger)
    if args.json:
        _print(report)
        return 0
    print(f"replay of ledger #{entry['seq']} ({entry['payload']['decision']}, {entry['payload']['period']}, known at "
          f"{entry['payload']['known_at']}): {report['verdict']}")
    for k, ok in report["checks"].items():
        print(f"  {'same' if ok else 'DIFFERENT':<9} {k}")
    print(report["explanation"])
    for d in report["differences"][:10]:
        print(f"  {d['key']}: {d['before'] and d['before']['outcome']} -> {d['after'] and d['after']['outcome']}")
    return 0 if report["verdict"] == "IDENTICAL" else 3


def cmd_ledger(args) -> int:
    ws = _ws(args)
    if args.action == "verify":
        res = ws.ledger.verify()
        _print(res) if args.json else print(
            f"ledger {ws.ledger.path.name}: {'VALID' if res['valid'] else 'BROKEN'}, {res['entries']} entries"
            + (f", head {res['head'][:16]}" if res["valid"] else f", broken at #{res['broken_at']}: {res['reason']}"))
        return 0 if res["valid"] else 4
    if args.action == "show":
        _print(ws.ledger.find(args.id))
        return 0
    rows = []
    for e in ws.ledger.entries():
        p = e["payload"]
        rows.append({"seq": e["seq"], "kind": e["kind"], "logged_at": e["logged_at"], "principal": e["principal"] or "",
                     "subject": p.get("decision") or p.get("model") or "",
                     "detail": (f"{p.get('period')} -> {', '.join(f'{k} {v}' for k, v in p.get('summary', {}).items())}"
                                if e["kind"] == "decision" else p.get("verdict") or p.get("approved_by") or ""),
                     "id": (p.get("decision_id") or p.get("model_hash") or "")[:12]})
    _print(rows) if args.json else print(_table(["seq", "kind", "logged_at", "principal", "subject", "detail", "id"], rows))
    return 0


def cmd_export(args) -> int:
    from .ossie import export_ossie, validate_ossie
    ws = _ws(args)
    doc, losses = export_ossie(ws.model)
    errors = validate_ossie(doc)
    text = json.dumps(doc, indent=2) if args.output and args.output.endswith(".json") else _yaml(doc)
    if args.output:
        Path(args.output).write_text(text)
        print(f"wrote {args.output} (Ossie {doc['version']}, {'valid' if not errors else 'INVALID'})")
    else:
        print(text)
    print(f"\n{len(losses)} capabilities have no Ossie form and travel in the CERTUS extension:", file=sys.stderr)
    for l_ in losses:
        print(f"  - {l_}", file=sys.stderr)
    for e in errors:
        print(f"schema error: {e}", file=sys.stderr)
    return 1 if errors else 0


def cmd_import(args) -> int:
    import yaml

    from .ossie import import_ossie
    src = Path(args.file).read_text()
    doc = json.loads(src) if args.file.endswith(".json") else yaml.safe_load(src)
    raw, notes = import_ossie(doc)
    Path(args.output).write_text(_yaml(raw))
    print(f"wrote {args.output}")
    for n in notes:
        print(f"  - {n}")
    return 0


def _yaml(obj) -> str:
    import yaml
    return yaml.safe_dump(obj, sort_keys=False, allow_unicode=True, width=110)


def cmd_doctor(args) -> int:
    ws = _ws(args)
    m, e = ws.model, ws.engine
    print(f"model {m.name} {m.version}: valid")
    print(f"data watermark (default known_at): {e.watermark()}")
    hashes = e.dataset_hashes()
    for ds, h in hashes.items():
        print(f"  {ds:<18} {h.split(':')[1]:>8} visible rows  {h[:16]}")
    who = next((p for p in e.directory.values() if any(m.roles[r].allow_metrics == ['*'] for r in p.roles)), None)
    problems = 0
    if who:
        for mn, met in m.metrics.items():
            try:
                e.query({"metrics": [mn], "period": f"1900-01-01..{e.watermark()[:10]}",
                         "role": who.roles[0]}, who)
                print(f"  ok       {mn}")
            except CertusError as ex:
                if ex.code in {"access_denied", "classified", "metric_denied", "not_certified", "no_definition"}:
                    print(f"  skipped  {mn} ({ex.code})")
                else:
                    problems += 1
                    print(f"  PROBLEM  {mn}: {ex}")
    print("ledger: " + json.dumps(ws.ledger.verify()))
    print("lock: " + json.dumps(m.lock_status()))
    return 0 if problems == 0 else 5


def cmd_mcp(args) -> int:
    from .mcp_server import serve
    ws = _ws(args)
    serve(ws, _who(args))
    return 0


def cmd_ui(args) -> int:
    from .web import serve
    ws = _ws(args)
    serve(ws, host=args.host, port=args.port, open_browser=not args.no_browser)
    return 0


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(prog="certus", description="Deterministic, governed semantics and decisions for banking.")
    ap.add_argument("--version", action="version", version=f"certus {__version__}")
    ap.add_argument("--model", help="model file (default: the one *.certus.yaml here, or $CERTUS_MODEL)")
    ap.add_argument("--directory", help="identity directory (default: principals.yaml next to the model)")
    ap.add_argument("--ledger", help="decision ledger (default: <model>.ledger.jsonl next to the model)")
    sub = ap.add_subparsers(dest="cmd", required=True)

    s = sub.add_parser("init", help="create the Acme Bank demo in a folder")
    s.add_argument("folder")
    s.add_argument("--profile", choices=["full", "small"], default="full")
    s.set_defaults(fn=cmd_init)

    sub.add_parser("validate", help="validate the model and identity directory").set_defaults(fn=cmd_validate)
    s = sub.add_parser("lock", help="approve the current model version (change control)")
    s.add_argument("--approver", required=True)
    s.add_argument("--note")
    s.set_defaults(fn=cmd_lock)
    s = sub.add_parser("metrics", help="list metrics")
    s.add_argument("--json", action="store_true")
    s.set_defaults(fn=cmd_metrics)
    s = sub.add_parser("describe", help="show a metric's definitions over time")
    s.add_argument("name")
    s.set_defaults(fn=cmd_describe)

    def who(p):
        p.add_argument("--as", dest="as_", metavar="PRINCIPAL", help="who is asking ($CERTUS_PRINCIPAL)")
        p.add_argument("--role", help="act in this role (must be one the principal holds)")
        p.add_argument("--json", action="store_true")

    s = sub.add_parser("query", help="query certified metrics")
    who(s)
    s.add_argument("-m", "--metrics", required=True, help="comma-separated metric names")
    s.add_argument("-p", "--period", required=True, help="2025, 2025Q4, 2025-12, 2025-12-31, FY2026, a..b")
    s.add_argument("-d", "--dims", help="comma-separated: dataset.field, time:<grain>, <hierarchy>@<level>")
    s.add_argument("-f", "--filter", action="append", help="'dataset.field op value' (op: = != < <= > >= like in not_in between)")
    s.add_argument("--known-at", help="knowledge cut-off (ISO timestamp); default: data watermark")
    s.add_argument("--param", action="append", help="name=value")
    s.add_argument("--currency", help="reporting currency (default: the model's)")
    s.add_argument("--order", action="append", help="field[:desc]")
    s.add_argument("--limit", type=int)
    s.add_argument("--definitions-as-of", help="use metric definitions in force on this date")
    s.add_argument("--explain", action="store_true", help="show definitions, FX and data hashes")
    s.add_argument("--sql", action="store_true", help="with --explain, print the generated SQL")
    s.set_defaults(fn=cmd_query)

    s = sub.add_parser("decide", help="run a certified decision and record it")
    who(s)
    s.add_argument("name")
    s.add_argument("-p", "--period", required=True)
    s.add_argument("--known-at")
    s.add_argument("--param", action="append")
    s.add_argument("--why", action="store_true", help="print the reason for every outcome")
    s.add_argument("--dry-run", action="store_true", help="do not write to the ledger")
    s.add_argument("--allow-unlocked", action="store_true", help="run on an unapproved model (recorded as such)")
    s.set_defaults(fn=cmd_decide)

    s = sub.add_parser("replay", help="re-run a recorded decision and prove it is reproducible")
    who(s)
    s.add_argument("id", help="ledger sequence number or decision id prefix")
    s.set_defaults(fn=cmd_replay)

    s = sub.add_parser("ledger", help="list, show or verify the decision ledger")
    s.add_argument("action", choices=["list", "verify", "show"], nargs="?", default="list")
    s.add_argument("id", nargs="?")
    s.add_argument("--json", action="store_true")
    s.set_defaults(fn=cmd_ledger)

    s = sub.add_parser("export-ossie", help="write the model as an Apache Ossie document")
    s.add_argument("-o", "--output")
    s.set_defaults(fn=cmd_export)
    s = sub.add_parser("import-ossie", help="convert an Apache Ossie document into a Certus model")
    s.add_argument("file")
    s.add_argument("-o", "--output", required=True)
    s.set_defaults(fn=cmd_import)
    sub.add_parser("doctor", help="check data contracts and every metric against the data").set_defaults(fn=cmd_doctor)

    s = sub.add_parser("mcp", help="serve the model to AI agents over MCP (stdio)")
    s.add_argument("--as", dest="as_", metavar="PRINCIPAL", help="the agent identity (fixed for the session)")
    s.set_defaults(fn=cmd_mcp)
    s = sub.add_parser("ui", help="open the local decision cockpit in a browser")
    s.add_argument("--host", default="127.0.0.1")
    s.add_argument("--port", type=int, default=8765)
    s.add_argument("--no-browser", action="store_true")
    s.set_defaults(fn=cmd_ui)

    args = ap.parse_args(argv)
    try:
        return args.fn(args)
    except CertusError as e:
        if getattr(args, "json", False):
            _print(e.to_dict())
        else:
            print(f"refused [{e.code}]: {e}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    sys.exit(main())
