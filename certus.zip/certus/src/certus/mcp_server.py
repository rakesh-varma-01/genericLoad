"""MCP server for AI agents (stdio transport, e.g. Claude Desktop).

The agent's identity is fixed when the server starts (``certus mcp --as claude.agent``): an
agent cannot claim another identity or role through a tool call. It sees only certified
metrics its role and the model's agent policy allow, never writes SQL, and every decision it
runs is recorded in the ledger under its own name.
"""
from __future__ import annotations

import functools
import threading
from typing import Any

from .errors import CertusError
from .governance import check_fields, check_metrics, resolve_access
from .model import metric_closure
from .workspace import Workspace


def build_server(ws: Workspace, principal: str):
    try:
        from mcp.server.fastmcp import FastMCP
    except ImportError as e:  # pragma: no cover
        raise CertusError("the MCP server needs the 'mcp' package: pip install 'certus[mcp]'", code="missing_mcp") from e
    m, eng = ws.model, ws.engine
    p = eng.principal(principal)
    access = resolve_access(m, p, None)
    instructions = (str((m.ai_context or {}).get("instructions", "")) if isinstance(m.ai_context, dict)
                    else str(m.ai_context or "")) + (
        " Use list_metrics and list_dimensions first, then query. Never compute or adjust numbers yourself; "
        "quote the values, the period and the known_at cut-off that the tools return.")
    srv = FastMCP("certus", instructions=instructions.strip(), log_level="WARNING")
    ws_lock = threading.Lock()

    def visible_metrics() -> list[str]:
        out = []
        for mn, met in m.metrics.items():
            try:
                check_metrics(m, access, [mn], met.versions[-1].effective_from)
                out.append(mn)
            except CertusError:
                pass
        return out

    def guard(fn):
        @functools.wraps(fn)
        def wrapped(*a, **kw):
            try:
                with ws_lock:
                    return fn(*a, **kw)
            except CertusError as e:
                return {"refused": True, **e.to_dict()}
        return wrapped

    @srv.tool()
    @guard
    def list_metrics() -> dict:
        """List the certified metrics you may use, with meaning, unit, synonyms and how their definition changed over time."""
        out = []
        for mn in visible_metrics():
            met = m.metrics[mn]
            out.append({"name": mn, "unit": met.unit, "description": met.description, "owner": met.owner,
                        "ai_context": met.ai_context,
                        "point_in_time": any(v.additivity == "semi" for v in met.versions if v.kind == "base"),
                        "definitions": [{"effective_from": v.effective_from.isoformat(),
                                         **({"formula": v.formula.text} if v.formula else {}),
                                         **({"note": v.note} if v.note else {})} for v in met.versions]})
        return {"model": m.name, "model_version": m.version, "reporting_currency": m.reporting_currency,
                "metrics": out}

    @srv.tool()
    @guard
    def list_dimensions(metric: str) -> dict:
        """List the dimensions a metric can be grouped or filtered by (dataset.field, time:<grain>, <hierarchy>@<level>)."""
        if metric not in visible_metrics():
            return {"refused": True, "error": f"metric {metric} is not available to you"}
        roots = set()
        for dep in [metric] + metric_closure(m, metric):
            for v in m.metrics[dep].versions:
                if v.kind == "base":
                    roots.add(v.dataset)
        reach = None
        for r in roots:
            ok = {d for d, path in m.graph.paths_from(r).items() if path is not None}
            reach = ok if reach is None else reach & ok
        dims = []
        for dsn in sorted(reach or []):
            for f in m.datasets[dsn].fields.values():
                if not f.dimension:
                    continue
                try:
                    check_fields(m, access, [f"{dsn}.{f.name}"], "dimension")
                except CertusError:
                    continue
                dims.append({"dimension": f"{dsn}.{f.name}", "datatype": f.datatype, "description": f.description})
        if all(m.datasets[r].valid_time for r in roots):
            dims += [{"dimension": f"time:{g}"} for g in ["day", "month", "quarter", "year", "fiscal_quarter", "fiscal_year"]]
        for h in m.hierarchies.values():
            if reach and h.dataset in reach:
                dims += [{"dimension": f"{h.name}@{i}", "level": name} for i, name in enumerate(h.levels, 1)]
        return {"metric": metric, "dimensions": dims}

    @srv.tool()
    @guard
    def query(metrics: list[str], period: str, dimensions: list[str] | None = None,
              filters: list[dict[str, Any]] | None = None, known_at: str | None = None,
              reporting_currency: str | None = None, order_by: list[dict[str, str]] | None = None,
              limit: int | None = None) -> dict:
        """Query certified metrics. period: 2025, 2025Q4, 2025-12, 2025-12-31, FY2026 or 2025-01-01..2025-06-30.
        filters: [{"field": "dataset.field", "op": "=", "value": "x"}] (ops = != < <= > >= like in not_in between;
        in/not_in/between take "values"). order_by: [{"field": "<metric or dimension>", "direction": "desc"}].
        Set a limit when you group by dimensions. Returns exact values plus the definitions, the data cut-off
        (known_at) and hashes that prove which data produced them."""
        req = {"metrics": metrics, "period": period, "dimensions": dimensions or [], "filters": filters or [],
               "known_at": known_at, "reporting_currency": reporting_currency, "order_by": order_by or [],
               "limit": limit}
        res = eng.query({k: v for k, v in req.items() if v not in (None, [])}, p).to_dict()
        meta = res["meta"]
        return {"columns": res["columns"], "rows": res["rows"],
                "period": f"{meta['period_start']}..{meta['period_end']}", "known_at": meta["known_at"],
                "reporting_currency": meta["reporting_currency"], "units": meta["units"],
                "definitions": meta["definitions"], "warnings": meta["warnings"],
                "result_hash": meta["result_hash"], "data_hash": meta["data_hash"], "model_hash": meta["model_hash"]}

    @srv.tool()
    @guard
    def list_decisions() -> dict:
        """List the certified decisions you may run, with their rules."""
        allowed = set(m.agent_policy.get("allow_decisions") or [])
        out = []
        for dn, d in m.decisions.items():
            if dn in allowed:
                out.append({"name": dn, "version": d.version, "description": d.description, "grain": d.grain,
                            "metrics": d.metrics, "parameters": {k: str(m.params[k].default) for k in d.params},
                            "rules": [{"id": r.id, "when": r.when.text, "outcome": r.outcome} for r in d.rules],
                            "default": d.default.outcome, "on_missing": d.on_missing.outcome})
        return {"decisions": out}

    @srv.tool()
    @guard
    def run_decision(name: str, period: str, known_at: str | None = None) -> dict:
        """Run a certified decision with its approved parameters. The run is recorded in the tamper-evident
        ledger under your identity. Report the outcomes and the decision_id exactly as returned."""
        from .decisions import run_decision as _run
        run = _run(eng, name, period=period, principal=p, known_at=known_at, ledger=ws.ledger)
        r = run.record
        return {"decision": r["decision"], "version": r["decision_version"], "period": r["period"],
                "known_at": r["known_at"], "summary": r["summary"], "outcomes": r["outcomes"],
                "decision_id": r["decision_id"], "ledger_seq": run.ledger_entry["seq"] if run.ledger_entry else None}

    @srv.tool()
    @guard
    def verify_decision(decision_id: str) -> dict:
        """Replay a recorded decision (by id prefix or ledger number) and report whether it reproduces exactly."""
        from .decisions import replay
        entry = ws.ledger.find(decision_id)
        if entry["payload"]["decision"] not in (m.agent_policy.get("allow_decisions") or []):
            return {"refused": True, "error": "you may not verify this decision"}
        return replay(eng, entry["payload"], principal=p, ledger=ws.ledger)

    srv._certus = {"principal": principal, "role": access.role}  # type: ignore[attr-defined]
    return srv


def serve(ws: Workspace, principal: str) -> None:
    build_server(ws, principal).run("stdio")
