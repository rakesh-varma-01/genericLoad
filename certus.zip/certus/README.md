# Certus

**A deterministic, governed semantic layer and decision engine for banking, interoperable with Apache Ossie.**

Certus runs on a laptop. It needs Python and nothing else: no Docker, no Kubernetes, no server.
It reads and writes [Apache Ossie](https://ossie.apache.org/) models. It also adds what regulated
finance needs and Ossie (v0.2.0.dev0) doesn't define yet, and enforces it in the engine rather than
leaving it to documentation.

> The demo bank, people and data are fictional and synthetic. Certus is a reference
> implementation for evaluation and design work. It has not been validated for production or
> regulatory reporting. Treat any production use as a model-risk exercise in its own right.

## Quick start

```bash
python3 -m venv .venv && source .venv/bin/activate      # Python 3.10+
pip install -e ".[mcp]"                                  # or: pip install -e ".[dev]" to run the tests

certus init acme && cd acme                              # synthetic bank: 9 tables, ~120k rows
certus validate
certus lock --approver "Your Name"                       # change control: certified decisions need this
certus query --as tess.treasury -m deposit_balance,loan_to_deposit_ratio -p 2025-12 -d branch.region
certus decide liquidity_watch --as tess.treasury -p 2025-12 --why
certus ui                                                # local cockpit at http://127.0.0.1:8765
```

## How it closes the gaps in Ossie for banking

| Gap in Ossie today | What Certus does | Proven by |
|---|---|---|
| Unstable spec; no conformance tests | Versioned model format, a model hash, `certus lock` approval, and 53 tests that pin behaviour | `tests/` |
| No semi-additive measures, no as-of time | `additivity: semi` (last, first or average snapshot); bitemporal datasets (`knowledge_time`, tombstones); every answer states its `known_at` cut-off | `test_balances_are_point_in_time_not_summed`, `test_bitemporal_restatement`, `test_reversal_tombstone` |
| No currency or exact decimals | Money metrics must declare their currency; row-level FX at a declared rate type and date; missing or stale rates are refused; Decimal arithmetic with round-half-even | `test_fx_*`, `test_missing_fx_rate_is_refused_not_guessed` |
| Engines disagree on division, NULLs and `CURRENT_DATE` | SQL only filters, joins, counts and sums. Ratios, averages and rules run in Python `Decimal`. Non-deterministic or inexact SQL is rejected when the model loads | `test_non_deterministic_or_inexact_definitions_rejected`, `test_physical_row_order_does_not_matter` |
| Metrics can't reference metrics; no parameters | Derived metrics (formulas over metrics), each component computed at its own grain, so fan-out is impossible; typed parameters | `test_ratio_components_at_own_grain` |
| Only simple equi-joins | As-of joins to type-2 dimensions, allocation bridges with weights that must sum to 1, ragged parent-child hierarchies, and runtime checks for duplicate keys and overlapping versions | `test_type2_*`, `test_bridge_*`, `test_ragged_hierarchy` |
| Governance doesn't travel with the model | Roles, classifications (PII, PROTECTED, RESTRICTED, CONFIDENTIAL, MNPI), row filters, an agent policy and certification all live in the model. Rules that can't be enforced fail closed | `test_pii_and_restricted_refused_before_sql`, `test_unenforceable_row_filter_fails_closed` |
| No effective-dated definitions | `versions:` with `effective_from`; a report uses the definitions in force at its period end, or at `definitions_as_of` | `test_effective_dated_definitions` |
| Lossy portability | Ossie export validates against the official schema. All Certus semantics travel in a `CERTUS` extension, so Certus → Ossie → Certus is byte-identical. Importing plain Ossie splits ratios into own-grain parts | `test_ossie_export_is_valid_and_round_trips` |
| `ai_context` is free text with no controls | Agents get a fixed identity, certified metrics only, a classification deny-list, row caps, MCP-only access, and decisions only from an allow-list | `test_agent_policy`, `test_mcp_tools` |
| Doesn't line up with banking standards | `concept:` IRIs (FIBO in the demo) on datasets and metrics, exported with the model | demo model |
| Fair-lending risk | Fields marked `PROTECTED` can't influence a decision, directly or through any metric definition. The model won't load if they do | `test_protected_attributes_cannot_drive_decisions` |

## Deterministic decisions

A decision is a certified, versioned rule table over certified metrics:

```yaml
- name: liquidity_watch
  grain: [branch.region]
  metrics: [loan_to_deposit_ratio, deposit_balance]
  parameters: [ldr_amber, ldr_red]
  rules:
    - {id: L1, when: loan_to_deposit_ratio >= ldr_red,   outcome: RED}
    - {id: L2, when: loan_to_deposit_ratio >= ldr_amber, outcome: AMBER}
  default:    {id: L0, outcome: GREEN}
  on_missing: {id: LM, outcome: DATA_GAP}   # a data gap never falls through to GREEN
```

Every run produces:

- **A deterministic `decision_id`.** It's a hash of the decision version, model hash, period,
  knowledge cut-off, parameters, role and the hash of the visible data. Same inputs, same id.
- **A reason for every outcome.** For example, "rule L1 holds: loan_to_deposit_ratio >= ldr_red
  with ldr_red=0.24, loan_to_deposit_ratio=0.264255".
- **An entry in a hash-chained ledger** (`*.ledger.jsonl`). Editing, deleting or reordering any
  line is detected by `certus ledger verify`.
- **Replay.** `certus replay <n>` re-runs a decision and proves it is IDENTICAL, or names what
  changed: the model, the data or the rules.

The demo shows why this matters. A San Jose loan was booked twice in the 2 January 2026 load and
corrected on 15 January:

```bash
certus decide liquidity_watch --as tess.treasury -p 2025-12 --known-at 2026-01-05T00:00:00   # West: RED
certus decide liquidity_watch --as tess.treasury -p 2025-12                                    # West: AMBER
certus replay 2 --as audrey.audit                                                              # IDENTICAL
```

Both decisions remain reproducible. Corrections are appended as new versions, so they don't
rewrite history. If someone edits data in place, replay reports DIFFERENT and names the changed
data hash.

## Everyday commands

```bash
certus metrics                                  # what is defined, its status and owner
certus describe active_customers                # definitions over time
certus query --as rita.risk -m aml_flag_rate,transaction_count -p 2025 -d customer_risk.risk_rating
certus query --as tess.treasury -m deposit_balance -p 2025 -d time:quarter --explain --sql
certus query --as tess.treasury -m deposit_balance -p 2025-12 --currency EUR
certus query --as tom.txbranch -m deposit_balance -p 2025-12 -d branch.branch_name     # Texas only
certus decide aml_channel_monitoring --as rita.risk -p 2025Q4 --why
certus decide card_limit_action --as carl.credit -p 2025-12
certus ledger            # list
certus ledger verify     # check the hash chain
certus doctor            # run every metric and data contract against the data
certus export-ossie -o acme_bank.ossie.yaml     # valid Ossie, plus a loss report
certus import-ossie some_model.ossie.yaml -o some_model.certus.yaml
```

Periods: `2025`, `2025Q4`, `2025-12`, `2025-12-31`, `FY2026`, `2025-01-01..2025-06-30`.
Dimensions: `dataset.field`, `time:day|month|quarter|year|fiscal_quarter|fiscal_year`, and
`<hierarchy>@<level>` (for example `org@2`).

## AI agents (MCP)

`certus mcp --as claude.agent` serves the model over MCP on stdio. The agent's identity is fixed
when the server starts. To add it to Claude Desktop, put this in `claude_desktop_config.json`:

```json
{
  "mcpServers": {
    "certus": {
      "command": "/absolute/path/to/.venv/bin/certus",
      "args": ["--model", "/absolute/path/to/acme/acme_bank.certus.yaml", "mcp", "--as", "claude.agent"]
    }
  }
}
```

The server offers these tools: `list_metrics`, `list_dimensions`, `query`, `list_decisions`,
`run_decision` and `verify_decision`. The agent never writes SQL. Every number it returns carries
its period, its `known_at` cut-off and hashes.

## Writing your own model

Start from `acme_bank.certus.yaml`. The core is Ossie-shaped: `datasets`, `fields`,
`relationships` and `metrics`. The Certus additions are:

- `temporal`: `valid_time`, `knowledge_time`, `deleted`, `valid_from`/`valid_to`
- `bridge`: `weight` and `per`
- `classification` on fields and datasets
- `concept` IRIs
- on metrics: `unit`, `currency`, `fx`, `additivity`, `formula`, `versions`, and `status`, `owner` and `approved_by` for certification
- top level: `parameters`, `hierarchies`, `roles`, `agent_policy` and `decisions`

Data sources are Parquet (or CSV) files in `data/`. People and agents are mapped to roles in
`principals.yaml`. That file is the only environment-specific piece.

## What this does not solve

Some of the Ossie problems aren't technical, and Certus doesn't address them:

- **Who governs the spec.** That's for the FSI working group and the ASF.
- **Industry adoption.**
- **Real identity.** Certus has no OIDC or SSO. The identity directory is a local file, so the
  cockpit and the CLI trust whoever runs them.
- **Scale.** DuckDB on one machine is plenty for evaluation, but it isn't a warehouse.
- **Native FIBO and BIRD semantics.** Concepts are mapped by IRI, not reasoned over.
- **Production validation.** That needs independent model-risk validation, real reconciliations and controls testing.

## Layout

```
src/certus/model.py        model format and load-time validation
src/certus/expr.py         SQL fragment allow-list and exact Decimal formula language
src/certus/engine.py       planner and executor (DuckDB), data contracts, hashing
src/certus/governance.py   roles, classifications, row filters, agent policy
src/certus/decisions.py    rule evaluation, decision records, ledger, replay
src/certus/ossie.py        Apache Ossie export and import
src/certus/mcp_server.py   MCP tools for agents
src/certus/web.py, static/ local cockpit
src/certus/demo/           synthetic Acme Bank: generator, model, identity directory
tests/                     53 tests, one or more per gap
```

Licensed under Apache-2.0. `src/certus/schemas/ossie-schema.json` is copied unmodified from
apache/ossie (Apache-2.0); see NOTICE.
