#!/usr/bin/env python3
"""Northstar CDE scan: suggest which fields in an OpenAPI / JSON Schema file may need CDE review.

Suggestions only. The exit code is 0 whatever the scan finds: a data steward decides, and
CDE Guardian is the only release gate. Reads field metadata (names, descriptions, types), never data values.

    python northstar_scan.py head.json                                # every field
    python northstar_scan.py head.json --base base.json               # only fields the change adds
    python northstar_scan.py head.json --base base.json --format markdown > comment.md
    python northstar_scan.py head.json --model cde_model_artifacts/cde_candidate_model.json

Standard library only (Python 3.8+). Features and rules match cde_idea.html and cde_candidate_model.ipynb (tokenizer v1).
"""
import argparse, json, math, pathlib, re, sys

TOKENIZER_VERSION = "v1"
MODEL_FORMAT = "northstar-cde-candidate-model"
STOP = set("the an of to for on in by and or is that when with from each was be after before into at as this its it are has have no not any per which whether".split())
CUES = [("cue:money",     r"\b(amount|balance|balances|usd|fee|fees|interest|rate|apr|ledger|payment|principal)\b"),
        ("cue:decision",  r"(decision|delinquen|authoriz|underwrit|regulat|reporting|reconcil|charge.?off|capital|credit line)"),
        ("cue:display",   r"(display|decorative|cosmetic|icon|image|logo|theme|layout|artwork)"),
        ("cue:no-effect", r"(no effect on|does not affect|not used (in|for))"),
        ("cue:engagement",r"(notification|reminder|alert|survey|marketing|session|sign-in|login)")]
# Same discovery rules as FIELD_RULES in cde_idea.html: (names, description pattern, critical).
RULES = [
    (["statementbalance", "closingbalance", "currentbalance", "balance", "amountdue"], r"amount owed|statement balance|autopay", True),
    (["paymentduedate", "duedate"], r"payment deadline|payment due|delinquency", True),
    (["minimumpayment", "minimumpaymentdue"], r"minimum payment", True),
    (["creditscore", "fico"], r"credit decision|credit score", True),
    (["pan", "primaryaccountnumber", "cardnumber"], r"full payment card|primary account number", False),
    (["email", "customeremail"], r"email address|servicing contact", False),
    (["ssn", "socialsecuritynumber", "taxid"], r"social security|tax identifier", False),
]

def split_camel(s): return re.sub(r"([a-z0-9])([A-Z])", r"\1 \2", str(s or ""))

def tokens(text):
    out = []
    for w in re.split(r"[^a-z0-9]+", split_camel(text).lower()):
        if len(w) > 1 and w not in STOP:
            out.append(w[:-1] if len(w) > 3 and w.endswith("s") and not w.endswith("ss") else w)
    return out

def features(name, description):
    f = set()
    for t in tokens(name): f.update({"name:" + t, "word:" + t})
    for t in tokens(description): f.add("word:" + t)
    text = (split_camel(name) + " " + str(description or "")).lower()
    f.update(k for k, rx in CUES if re.search(rx, text))
    return sorted(f)

def rule_for(name, description):
    n = re.sub(r"[^a-z0-9]", "", str(name).lower())
    for names, rx, critical in RULES:
        if n in names: return critical
    if re.search(r"display.only|decorative|no effect on", str(description), re.I): return None
    for names, rx, critical in RULES:
        if re.search(rx, str(description), re.I): return critical
    return None

def extract_fields(spec):
    """Walk OpenAPI / JSON Schema, resolving local $ref. A referenced schema gets its own path root (Statement.x)."""
    rows, seen = [], set()
    is_spec = isinstance(spec, dict) and any(k in spec for k in ("openapi", "swagger", "$schema"))
    def resolve(ref):
        node = spec
        for part in ref[2:].split("/"):
            node = node.get(part.replace("~1", "/").replace("~0", "~")) if isinstance(node, dict) else None
        return node
    def visit(node, path, refs, depth):
        if depth > 32 or not isinstance(node, (dict, list)): return
        if isinstance(node, list):
            for i, x in enumerate(node[:20]): visit(x, f"{path}[{i}]", refs, depth + 1)
            return
        ref = node.get("$ref")
        if isinstance(ref, str):
            if ref.startswith("#/") and ref not in refs and resolve(ref) is not None:
                visit(resolve(ref), ref.split("/")[-1], refs | {ref}, depth + 1)
            return
        if isinstance(node.get("properties"), dict):
            for k, v in node["properties"].items():
                if not isinstance(v, dict): continue
                p = f"{path}.{k}"
                if p not in seen:
                    seen.add(p); rows.append({"field": k, "path": p, "type": v.get("type", ""), "description": v.get("description", "")})
                visit(v, p, refs, depth + 1)
            return
        if node.get("type") == "array" and "items" in node:
            visit(node["items"], path + "[]", refs, depth + 1); return
        for kw in ("allOf", "oneOf", "anyOf"):
            for part in node.get(kw, []) if isinstance(node.get(kw), list) else []: visit(part, path, refs, depth + 1)
        if isinstance(node.get("type"), str) or "format" in node: return
        for k, v in node.items():
            if k in ("info", "example", "examples", "description", "required", "servers", "tags", "security", "allOf", "oneOf", "anyOf"): continue
            if is_spec and depth == 0 and k in ("components", "definitions", "$defs"): continue
            if isinstance(v, (dict, list)): visit(v, path if is_spec else f"{path}.{k}", refs, depth + 1)
            elif not is_spec and f"{path}.{k}" not in seen:
                seen.add(f"{path}.{k}"); rows.append({"field": k, "path": f"{path}.{k}", "type": type(v).__name__, "description": ""})
    visit(spec, "$", frozenset(), 0)
    return rows

def load_model(path):
    try:
        m = json.loads(pathlib.Path(path).read_text())
    except (OSError, ValueError) as e:
        sys.exit(f"error: cannot read model {path}: {e}")
    if not isinstance(m, dict) or m.get("format") != MODEL_FORMAT: sys.exit(f"error: {path} is not a {MODEL_FORMAT} file")
    if m.get("tokenizer") != TOKENIZER_VERSION: sys.exit(f"error: model tokenizer {m.get('tokenizer')} != {TOKENIZER_VERSION}")
    return m

def scan(head, base, model, threshold):
    old = {r["path"] for r in extract_fields(base)} if base is not None else set()
    out = []
    for f in (r for r in extract_fields(head) if r["path"] not in old):
        critical = rule_for(f["field"], f["description"])
        p, why = None, []
        if model:
            contrib = sorted(((k, model["weights"][k]) for k in features(f["field"], f["description"]) if k in model["weights"]), key=lambda x: -abs(x[1]))
            p = 1 / (1 + math.exp(-(model["bias"] + sum(w for _, w in contrib))))
            why = [f"{w:+.2f} {k}" for k, w in contrib[:3]]
        signal = ("Rule: CDE candidate" if critical else "Rule: sensitive, needs context" if critical is False
                  else "Model: suggest review" if p is not None and why and p >= threshold else None)
        out.append({**f, "signal": signal, "p": p, "why": why})
    return out

def to_markdown(rows, file, model_label, threshold):
    flagged, rest = [r for r in rows if r["signal"]], [r for r in rows if not r["signal"]]
    line = lambda r: "| `{}` | {} | {} | {} |".format(r["field"], r["signal"] or "—", "n/a" if r["p"] is None else f"{r['p']:.2f}",
        " ".join(f"`{w}`" for w in r["why"]) if r["why"] else ("rule match" if (r["signal"] or "").startswith("Rule") else "—"))
    head = "| Field | Signal | Model score | Top reasons |\n|---|---|---|---|"
    parts = ["### Northstar CDE review — suggestion, not a gate", "",
             f"{len(rows)} new field(s) in `{file}`; **{len(flagged)}** may need CDE review.", ""]
    parts += [head] + [line(r) for r in flagged] if flagged else ["No new field needs CDE review."]
    parts += [""]
    if rest: parts += [f"<details><summary>{len(rest)} field(s) below threshold</summary>", "", head] + [line(r) for r in rest] + ["", "</details>", ""]
    parts += [f"_Rules + {model_label} · threshold {threshold}. A data steward decides; nothing in the catalog changed. "
              "Breaking changes to tagged CDEs are gated separately by CDE Guardian._"]
    return "\n".join(parts)

def to_text(rows, model_label, threshold):
    flagged = sum(1 for r in rows if r["signal"])
    lines = [f"Northstar CDE scan · {len(rows)} new field(s) · {flagged} may need CDE review · {model_label} · threshold {threshold}",
             f"{'FIELD':<22}{'SIGNAL':<32}{'SCORE':>6}  TOP REASONS"]
    for r in sorted(rows, key=lambda r: (r["signal"] is None, -(r["p"] or 0))):
        score = "n/a" if r["p"] is None else format(r["p"], ".2f")
        lines.append(f"{r['field']:<22}{(r['signal'] or '—'):<32}{score:>6}  {', '.join(r['why'])}")
    lines.append("Suggestions only · exit code 0 · a data steward decides.")
    return "\n".join(lines)

def main(argv=None):
    ap = argparse.ArgumentParser(description="Suggest fields that may need CDE review (never blocks a build).")
    ap.add_argument("spec", help="OpenAPI / JSON Schema file to scan (the pull request's version)")
    ap.add_argument("--base", help="previous version; only fields added since it are scanned")
    ap.add_argument("--model", help="model JSON exported by cde_candidate_model.ipynb (default: cde_model_artifacts/cde_candidate_model.json if present)")
    ap.add_argument("--threshold", type=float, help="review threshold (default: the model's own, else 0.5)")
    ap.add_argument("--format", choices=["text", "markdown", "json"], default="text")
    a = ap.parse_args(argv)
    head = json.loads(pathlib.Path(a.spec).read_text())
    base = json.loads(pathlib.Path(a.base).read_text()) if a.base else None
    default = pathlib.Path(__file__).with_name("cde_model_artifacts") / "cde_candidate_model.json"
    model_path = a.model or (str(default) if default.exists() else None)
    model = load_model(model_path) if model_path else None
    threshold = a.threshold if a.threshold is not None else round(float(model.get("threshold", 0.5)), 3) if model else 0.5
    label = f"model {pathlib.Path(model_path).name}" if model else "rules only (no model found; pass --model)"
    rows = scan(head, base, model, threshold)
    if a.format == "json": print(json.dumps({"file": a.spec, "threshold": threshold, "model": model_path, "fields": rows}, indent=1))
    elif a.format == "markdown": print(to_markdown(rows, pathlib.Path(a.spec).name, label, threshold))
    else: print(to_text(rows, label, threshold))
    return 0

if __name__ == "__main__":
    sys.exit(main())
