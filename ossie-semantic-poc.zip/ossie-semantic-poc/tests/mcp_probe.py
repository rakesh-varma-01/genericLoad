"""Call one Semantic Server MCP tool as a given identity and print a JSON verdict.

    python3 tests/mcp_probe.py --user agent-bot --role analyst \
        --tool query_metric --args '{"metrics":["fee_revenue"],"dimensions":["txn.channel"],"limit":10}'

Prints {"ok": true|false, "rowCount": n, "text": "..."} and exits 0, so shell
tests can assert on the outcome.
"""
from __future__ import annotations

import argparse
import asyncio
import json
import os

from mcp import ClientSession
from mcp.client.streamable_http import streamablehttp_client


async def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--url", default=os.getenv("SEMANTIC_URL", "http://127.0.0.1:8090") + "/mcp")
    ap.add_argument("--user", required=True)
    ap.add_argument("--role", required=True)
    ap.add_argument("--tool", default="query_metric")
    ap.add_argument("--args", default="{}")
    a = ap.parse_args()
    headers = {"X-Semantic-User": a.user, "X-Semantic-Role": a.role}
    async with streamablehttp_client(a.url, headers=headers) as (read, write, _):
        async with ClientSession(read, write) as session:
            await session.initialize()
            out = await session.call_tool(a.tool, json.loads(a.args))
            text = "\n".join(c.text for c in out.content if getattr(c, "type", "") == "text")
            payload = out.structuredContent or {}
            print(json.dumps({"ok": not out.isError, "rowCount": payload.get("rowCount"),
                              "rows": payload.get("rows"), "text": text[:400]}))


if __name__ == "__main__":
    asyncio.run(main())
