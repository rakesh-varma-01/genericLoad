#!/usr/bin/env bash
# Goal 2: governance. Proves that model-level rules (role metric allowlists,
# PII deny-lists, a Texas row filter) and the OPA policy (identity directory,
# role entitlement, AML separation of duties, AI-agent data minimisation) are
# enforced before any SQL runs, over both REST and MCP.
source "$(dirname "$0")/../scripts/lib.sh"
pf_server

PY="$VENV/bin/python"
jget() { "$PY" -c "import json,sys; d=json.loads(sys.argv[1]); print(eval(sys.argv[2], {}, {'d': d}))" "$1" "$2"; }
DEC='{"field":"date_dim.year_month","op":"=","value":"2025-12"}'
Y25='{"field":"date_dim.cal_year","op":"=","value":2025}'

expect() {  # expect <code> <label> <user> <role> <body>
  sq "$3" "$4" "$5"
  if [[ "$HTTP_CODE" == "$1" ]]; then ok "$2 -> $HTTP_CODE"
  else bad "$2 -> got $HTTP_CODE, want $1: ${BODY:0:200}"; fi
}

log "A. Model governance (compiled into SQL by the planner)"
expect 200 "analyst: fee revenue by channel" ana.analyst analyst \
  "{\"metrics\":[\"fee_revenue\"],\"dimensions\":[\"txn.channel\"],\"filters\":[$Y25]}"
[[ "$(jget "$BODY" "d['rowCount']")" == 6 ]] && ok "6 channels returned" || bad "expected 6 rows: ${BODY:0:200}"

expect 403 "analyst: group by customer.email (PII)" ana.analyst analyst \
  '{"metrics":["transaction_count"],"dimensions":["customer.email"]}'
expect 403 "analyst: filter on customer.full_name (PII)" ana.analyst analyst \
  '{"metrics":["transaction_count"],"filters":[{"field":"customer.full_name","op":"LIKE","value":"Ana%"}]}'
expect 403 "analyst: group by customer.risk_rating (restricted)" ana.analyst analyst \
  '{"metrics":["transaction_count"],"dimensions":["customer.risk_rating"]}'
expect 200 "risk officer: group by customer.risk_rating" rita.risk risk_officer \
  '{"metrics":["transaction_count"],"dimensions":["customer.risk_rating"]}'
expect 403 "marketing: total_deposits (not in role allowMetrics)" mia.marketing marketing \
  "{\"metrics\":[\"total_deposits\"],\"filters\":[$DEC]}"
expect 200 "marketing: fee revenue per active customer by segment" mia.marketing marketing \
  "{\"metrics\":[\"fee_revenue_per_active_customer\"],\"dimensions\":[\"customer.segment\"],\"filters\":[$Y25]}"
expect 200 "admin: PII is visible to admin" dba.admin admin \
  '{"metrics":["transaction_count"],"dimensions":["customer.email"],"limit":3}'

log "B. Row-level security: tx_branch_manager sees Texas branches only"
sq ana.analyst analyst "{\"metrics\":[\"total_deposits\"],\"dimensions\":[\"branch.state\"],\"filters\":[$DEC]}"
all_states="$BODY"
sq tom.txbranch tx_branch_manager "{\"metrics\":[\"total_deposits\"],\"dimensions\":[\"branch.state\"],\"filters\":[$DEC]}"
tx_only="$BODY"
states="$(jget "$tx_only" "sorted({r[0] for r in d['rows']})")"
[[ "$states" == "['TX']" ]] && ok "tx_branch_manager rows limited to $states" || bad "expected only TX, got $states"
analyst_tx="$(jget "$all_states" "[r[1] for r in d['rows'] if r[0]=='TX'][0]")"
sq tom.txbranch tx_branch_manager "{\"metrics\":[\"total_deposits\"],\"filters\":[$DEC]}"
mgr_total="$(jget "$BODY" "d['rows'][0][0]")"
"$PY" -c "import sys; a,b=map(float,sys.argv[1:]); sys.exit(0 if abs(a-b)<0.01 else 1)" "$analyst_tx" "$mgr_total" \
  && ok "manager's unfiltered total ($mgr_total) equals the analyst's TX row ($analyst_tx)" \
  || bad "manager total $mgr_total != analyst TX row $analyst_tx"
grep -q "'TX'" <<<"$(jget "$BODY" "d['sql']")" && ok "row filter is visible in the compiled SQL" || bad "row filter not found in SQL"

log "C. OPA policy (external gate, evaluated before planning and cache)"
expect 403 "unknown principal eve.unknown" eve.unknown analyst '{"metrics":["fee_revenue"]}'
expect 403 "role escalation: ana.analyst claims admin" ana.analyst admin '{"metrics":["fee_revenue"]}'
expect 403 "AML metric for analyst (separation of duties)" ana.analyst analyst '{"metrics":["aml_flag_rate"]}'
expect 200 "AML metric for risk officer" rita.risk risk_officer \
  "{\"metrics\":[\"aml_flag_rate\"],\"dimensions\":[\"txn.channel\"],\"filters\":[$Y25]}"
expect 403 "agent-bot over REST (agents must use MCP)" agent-bot analyst '{"metrics":["fee_revenue"]}'

log "D. AI agent over MCP (data minimisation)"
probe() { "$PY" -I "$POC_DIR/tests/mcp_probe.py" --user "$1" --role "$2" --args "$3"; }
r="$(probe agent-bot analyst '{"metrics":["fee_revenue"],"dimensions":["txn.channel"],"limit":100}')"
[[ "$(jget "$r" "d['ok']")" == True ]] && ok "agent: fee revenue by channel with limit -> allowed" || bad "agent bounded query denied: $r"
r="$(probe agent-bot analyst '{"metrics":["fee_revenue"],"dimensions":["txn.channel"]}')"
[[ "$(jget "$r" "d['ok']")" == False ]] && ok "agent: grouped query without limit -> denied" || bad "agent unbounded query allowed: $r"
r="$(probe agent-bot analyst '{"metrics":["fee_revenue"],"dimensions":["customer.segment"],"limit":10}')"
[[ "$(jget "$r" "d['ok']")" == False ]] && ok "agent: customer-level dimension -> denied" || bad "agent customer dimension allowed: $r"
r="$(probe ana.analyst analyst '{"metrics":["fee_revenue"],"dimensions":["customer.email"],"limit":10}')"
[[ "$(jget "$r" "d['ok']")" == False ]] && ok "analyst over MCP: PII denied the same way as REST" || bad "PII allowed over MCP: $r"

log "E. Determinism and provenance"
req="{\"metrics\":[\"deposits_per_branch_employee\"],\"dimensions\":[\"branch.region\"],\"filters\":[$DEC]}"
sq ana.analyst analyst "$req"; h1="$(jget "$BODY" "d['requestHash']")"; s1="$(jget "$BODY" "d['sql']")"
sq ana.analyst analyst "$req"; h2="$(jget "$BODY" "d['requestHash']")"; s2="$(jget "$BODY" "d['sql']")"
[[ "$h1" == "$h2" && "$s1" == "$s2" ]] && ok "same request -> same requestHash ($h1) and identical SQL" || bad "non-deterministic plan"
echo "  compiled SQL for deposits_per_branch_employee (note the headcount de-duplication):"
sed 's/^/    /' <<<"$s1"

log "F. OPA decision log (audit trail)"
n="$("${KNS[@]}" logs deploy/opa --since=10m 2>/dev/null | grep -c '"decision_id"' || true)"
(( n > 0 )) && ok "$n decisions logged by OPA in the last 10 minutes" || warn "no OPA decision logs found"

echo
(( FAILURES == 0 )) && log "Governance: all checks passed" || { log "Governance: $FAILURES check(s) failed"; exit 1; }
