#!/usr/bin/env bash
# Goal 1: agent accuracy. Runs bench/run_bench.py with the needed port-forwards.
#   ANTHROPIC_API_KEY=... ./tests/run_bench.sh                 # everything
#   ANTHROPIC_API_KEY=... ./tests/run_bench.sh --only q03,q04  # a subset
source "$(dirname "$0")/../scripts/lib.sh"
[[ -n "${ANTHROPIC_API_KEY:-}" ]] || { echo "Set ANTHROPIC_API_KEY first (synthetic data only)." >&2; exit 1; }
pf_server
pf_trino
SEMANTIC_URL="http://127.0.0.1:$SERVER_PORT" TRINO_PORT="$TRINO_PORT" py "$POC_DIR/bench/run_bench.py" "$@"
