#!/usr/bin/env bash
# Goal 3: drift detection.
#   A. Spec drift: a new model version references a column that does not
#      exist. The operator must reject it and keep serving the last good one.
#   B. Physical drift: a column the live model depends on is renamed in the
#      warehouse. The periodic resync (30s in deploy/helm-values.yaml) must
#      flag it. The column is then restored and the flag must clear.
source "$(dirname "$0")/../scripts/lib.sh"
pf_server
PY="$VENV/bin/python"
MODEL_FILE="$POC_DIR/model/retail-banking.yaml"
REQ='{"metrics":["fee_revenue"],"filters":[{"field":"date_dim.cal_year","op":"=","value":2025}]}'

wait_cond() {  # wait_cond <Type> <True|False> <seconds>
  for _ in $(seq "$3"); do [[ "$(model_condition "$1")" == "$2" ]] && return 0; sleep 1; done; return 1
}
drift_msg() {
  "${KNS[@]}" get "semanticmodel/$MODEL_RESOURCE" \
    -o jsonpath='{.status.conditions[?(@.type=="DriftDetected")].message}'
}
served_version() { sq ana.analyst analyst "$REQ"; "$PY" -c 'import json,sys; print(json.load(sys.stdin)["modelVersion"])' <<<"$BODY"; }

log "Baseline"
v1="$(model_version)"
[[ "$(model_condition DriftDetected)" == False ]] && ok "no drift; published version $v1" || bad "model already shows drift"
[[ "$(served_version)" == "$v1" ]] && ok "server answers with version $v1" || bad "server version mismatch"

# ---------------------------------------------------------------- A -------
log "A. Apply v2 that references txn.merchant_category (no such column)"
"$PY" - "$MODEL_FILE" <<'EOF' | "${KNS[@]}" apply -f -
import sys, yaml
doc = yaml.safe_load(open(sys.argv[1]))
txn = next(d for d in doc["spec"]["ossie"]["datasets"] if d["name"] == "txn")
txn["fields"].append({"name": "merchant_category",
                      "expression": {"dialects": [{"dialect": "ANSI_SQL", "expression": "merchant_category"}]},
                      "dimension": {}, "description": "Merchant category code (not yet in the warehouse)"})
print(yaml.safe_dump(doc, sort_keys=False))
EOF
if wait_cond DriftDetected True 90; then ok "DriftDetected=True: $(drift_msg)"; else bad "drift not detected for v2"; fi
[[ "$(model_version)" == "$v1" ]] && ok "status.modelVersion still $v1 (v2 not published)" || bad "published version changed to $(model_version)"
[[ "$(served_version)" == "$v1" ]] && ok "queries keep being answered by $v1" || bad "server switched versions"

log "A. Roll back to v1"
"${KNS[@]}" apply -f "$MODEL_FILE"
wait_cond DriftDetected False 90 && ok "drift cleared after rollback" || bad "drift did not clear"

# ---------------------------------------------------------------- B -------
log "B. Rename branch.headcount -> fte_count in the warehouse (physical drift)"
rename_col() {  # rename_col <from> <to>
  if ! trino_sql "ALTER TABLE memory.bank_demo.branch RENAME COLUMN $1 TO $2" >/dev/null 2>&1; then
    # Fallback for connectors without RENAME COLUMN: rebuild the table.
    cols="branch_id, branch_name, city, state, region"
    trino_sql "CREATE TABLE memory.bank_demo.branch_tmp AS SELECT $cols, $1 AS $2 FROM memory.bank_demo.branch" >/dev/null
    trino_sql "DROP TABLE memory.bank_demo.branch" >/dev/null
    trino_sql "ALTER TABLE memory.bank_demo.branch_tmp RENAME TO branch" >/dev/null
  fi
}
restore() { rename_col fte_count headcount 2>/dev/null || true; }
trap 'restore; cleanup_pf' EXIT
rename_col headcount fte_count
start=$(date +%s)
if wait_cond DriftDetected True 120; then
  ok "detected after $(( $(date +%s) - start ))s: $(drift_msg)"
else
  bad "physical drift not detected within 120s (resyncPeriod is 30s)"
fi
sq ana.analyst analyst '{"metrics":["deposits_per_branch_employee"],"filters":[{"field":"date_dim.year_month","op":"=","value":"2025-12"}]}'
[[ "$HTTP_CODE" != 200 ]] && ok "dependent metric now fails loudly (HTTP $HTTP_CODE) instead of returning a wrong number" \
  || warn "dependent metric still answered (HTTP 200); check whether a result cache served it"
sq ana.analyst analyst "$REQ"
[[ "$HTTP_CODE" == 200 ]] && ok "metrics that do not touch branch.headcount keep working" || bad "unrelated metric failed: $HTTP_CODE"

log "B. Restore the column"
rename_col fte_count headcount
trap cleanup_pf EXIT
if wait_cond DriftDetected False 120; then ok "drift cleared on the next resync"; else bad "drift did not clear"; fi

echo
(( FAILURES == 0 )) && log "Drift: all checks passed" || { log "Drift: $FAILURES check(s) failed"; exit 1; }
