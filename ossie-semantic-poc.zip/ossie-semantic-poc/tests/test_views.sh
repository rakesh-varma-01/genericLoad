#!/usr/bin/env bash
# Goal 4: BI through governed SQL views. A BI tool connects to Trino like any
# SQL client and reads memory.semantic_views.*. Each view was compiled by the
# operator from certified metrics under a role, so its numbers must equal the
# Semantic Server's answer and its role's row filter must be baked in.
source "$(dirname "$0")/../scripts/lib.sh"
pf_server
PY="$VENV/bin/python"

log "Views published by the operator"
views="$(trino_sql "SHOW TABLES FROM memory.semantic_views")"
sed 's/^/    /' <<<"$views"
for v in monthly_transaction_summary deposits_by_region_month aml_rate_by_channel_year tx_branch_deposits_month; do
  grep -qx "$v" <<<"$views" && ok "view $v exists" || bad "view $v missing"
done

log "Show the SQL behind one view"
trino_sql "SHOW CREATE VIEW memory.semantic_views.deposits_by_region_month" | head -30 | sed 's/^/    /'

log "View numbers equal the semantic API (same certified definition)"
# deposits_by_region_month, December 2025, South region
view_val="$(TRINO_FORMAT=TSV_HEADER trino_sql "SELECT * FROM memory.semantic_views.deposits_by_region_month" |
  "$PY" -c '
import sys
rows = [l.rstrip("\n").split("\t") for l in sys.stdin if l.strip()]
hdr = rows[0]
col = lambda key: next(i for i, h in enumerate(hdr) if key in h)
r_i, d_i, v_i = col("region"), col("cal_date"), col("total_deposits")
print(next(r[v_i] for r in rows[1:] if r[r_i] == "South" and r[d_i].startswith("2025-12")))')"
sq ana.analyst analyst '{"metrics":["total_deposits"],"dimensions":["branch.region"],"filters":[{"field":"date_dim.year_month","op":"=","value":"2025-12"}]}'
api_val="$("$PY" -c 'import json,sys; d=json.load(sys.stdin); print([r[1] for r in d["rows"] if r[0]=="South"][0])' <<<"$BODY")"
if "$PY" -c "import sys; a,b=map(float,sys.argv[1:]); sys.exit(0 if abs(a-b) < 0.01 else 1)" "${view_val:-nan}" "${api_val:-nan}"; then
  ok "South deposits, Dec 2025: view $view_val = API $api_val"
else
  bad "view ($view_val) and API ($api_val) disagree"
fi

log "Role baked into the view: tx_branch_deposits_month holds Texas branches only"
branches="$(TRINO_FORMAT=TSV_HEADER trino_sql "SELECT * FROM memory.semantic_views.tx_branch_deposits_month" |
  "$PY" -c '
import sys
rows = [l.rstrip("\n").split("\t") for l in sys.stdin if l.strip()]
i = next(i for i, h in enumerate(rows[0]) if "branch_name" in h)
print(",".join(sorted({r[i] for r in rows[1:]})))')"
echo "    branches in view: $branches"
if grep -Eq 'Manhattan|Chicago|Boston|Phoenix|San Jose|Los Angeles|Columbus|Brooklyn' <<<"$branches"; then
  bad "non-Texas branch found in the Texas view"
else
  ok "only Texas branches present"
fi

log "PII is not reachable through any view"
cols="$(trino_sql "SELECT table_name || '.' || column_name FROM memory.information_schema.columns WHERE table_schema = 'semantic_views'")"
grep -Eqi 'email|phone|full_name' <<<"$cols" && bad "a view exposes a PII column" || ok "no PII columns in any view"

echo
echo "  Point a BI tool (DBeaver, Tableau, Power BI via the Trino ODBC/JDBC driver) at"
echo "  localhost:$TRINO_PORT after: kubectl -n $NAMESPACE port-forward svc/trino $TRINO_PORT:8080"
echo "  catalog=memory, schema=semantic_views, any username, no password (laptop POC only)."
echo
(( FAILURES == 0 )) && log "Views: all checks passed" || { log "Views: $FAILURES check(s) failed"; exit 1; }
