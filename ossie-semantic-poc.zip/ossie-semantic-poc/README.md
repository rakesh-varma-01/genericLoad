# Apache Ossie + Kubeflow Semantic Operator — laptop POC

A self-contained proof of concept that runs an **Apache Ossie** semantic model on the
**Kubeflow Semantic Operator** in a local kind cluster, over a **synthetic retail-banking**
dataset, and tests four claims:

| # | Goal | How it is tested | Command |
|---|------|------------------|---------|
| 1 | AI agents answer more accurately through certified metrics (MCP) than by writing SQL | 12 banking questions × 3 phrasings, raw text-to-SQL vs MCP, scored against ground truth | `make bench` |
| 2 | Governance is enforced before any SQL runs | 20+ allow/deny checks: PII deny-lists, metric allowlists, Texas row filter, OPA identity/entitlement/AML/agent rules, REST and MCP | `make test-governance` |
| 3 | Schema drift is caught | A bad model version is rejected while the last good one keeps serving; a renamed warehouse column is flagged by the resync loop | `make test-drift` |
| 4 | BI tools get the same numbers | Operator-built SQL views compared with the API; role filter baked into a view; no PII in views | `make test-views` |

> **Data and scope.** Every row is generated from a fixed seed by `data/bankgen.py`. No real
> customer, account or employer data is used, and nothing here should be pointed at real data.
> Header authentication is used for simplicity, so the services are only reachable through a
> local `port-forward`. This is not a production configuration.

## Prerequisites

- Docker with **≥ 6 GiB memory** and 4 CPUs, `kind`, `kubectl`, `helm` (v3.12+ or v4), `git`, `make`, `curl`
- Python 3.10+
- Optional: Go (matching the upstream `go.mod`) to run the authoritative `ossiectl validate`; `opa` CLI for policy unit tests
- For `make bench` only: an `ANTHROPIC_API_KEY` (questions and table DDL are sent to the API; data is synthetic)

`make prereqs` checks all of this.

## Run it

```bash
make setup            # ~10–15 min first time: kind, Trino, build + install operator, OPA, data, model
make test             # governance, views, drift (no LLM needed)
export ANTHROPIC_API_KEY=...
make bench            # writes bench/RESULTS.md and bench/RESULTS.json
make down             # delete the cluster
```

`make help` lists every step; each is idempotent. `PROFILE=small make data` loads a lighter dataset.

To explore by hand:

```bash
export KUBECONFIG=$PWD/.kube/config
kubectl -n semantic-system port-forward svc/semantic-operator-server 8090:8090 &
curl -s -X POST localhost:8090/v1/models/retail_banking_model/query \
  -H 'X-Semantic-User: ana.analyst' -H 'X-Semantic-Role: analyst' -H 'Content-Type: application/json' \
  -d '{"metrics":["deposits_per_branch_employee"],"dimensions":["branch.region"],
       "filters":[{"field":"date_dim.year_month","op":"=","value":"2025-12"}]}'
```

MCP clients (Claude Desktop, an agent framework) connect to `http://localhost:8090/mcp` with
the same two headers. A BI tool connects to Trino at `localhost:18080` after
`kubectl -n semantic-system port-forward svc/trino 18080:8080`, catalog `memory`, schema
`semantic_views`.

## What is in the kit

```
model/retail-banking.yaml   SemanticModel: spec.ossie is plain Apache Ossie; governance/views are operator extensions
data/bankgen.py             deterministic synthetic data (6 tables, ~115k rows)
data/load_trino.py          idempotent loader into Trino's memory catalog
policy/banking.rego         OPA policy (+ banking_test.rego, 14 unit tests)
deploy/helm-values.yaml     chart values: header auth, OPA provider, 30s drift resync
deploy/opa.yaml             OPA Deployment/Service
validate/validate_model.py  offline pre-flight: CRD schema + Python port of the operator's checks
bench/questions.yaml        12 questions, paraphrases, ground-truth SQL, the trap each one targets
bench/run_bench.py          raw-vs-semantic agent benchmark (Anthropic API + MCP client)
tests/*.sh                  governance, drift, views tests; mcp_probe.py helper
scripts/*.sh                setup steps 00–04 and teardown
```

The upstream operator is cloned into `./semantic-operator` at a pinned commit
(`SO_COMMIT` in `scripts/lib.sh`). The POC uses its Trino quickstart manifest, Dockerfile and
Helm chart unchanged.

## Identities used in the tests

| Principal | Roles it may assume (OPA) | What the model lets the role do |
|---|---|---|
| `ana.analyst` | analyst | all metrics; no PII, no risk rating |
| `tom.txbranch` | tx_branch_manager | as analyst, rows limited to Texas branches |
| `mia.marketing` | marketing | 6 activity metrics only; no balances, no AML |
| `rita.risk` | risk_officer, analyst | all metrics incl. AML; sees risk rating, not email/phone |
| `dba.admin` | admin | everything |
| `agent-bot` | analyst | MCP only, must set a row limit, no customer-level fields |

Any other principal, or a role the principal is not entitled to, is denied by OPA.

## Things the POC surfaced (worth knowing before you extend it)

- **Semi-additive measures are not expressible in Ossie v0.1 or the planner.** Balance metrics
  are correct only for one month at a time; the model relies on descriptions and AI context to
  tell agents to filter `date_dim.year_month`. A good candidate for an Ossie spec proposal.
- **Join-tree rooting can change a metric's meaning.** `COUNT(DISTINCT account.customer_id)`
  alone roots the query at `account` and counts every account holder; `active_customers`
  references `txn` deliberately to force transaction-based counting.
- **Filter values are untyped.** Comparing `date_dim.cal_date` (DATE) with a string fails on
  Trino, so the model exposes varchar `year_month` / `quarter_name` for filtering.
- **The OPA decision contract is strict:** the server accepts only `{allow, revision}`, so
  denial reasons live in the policy (`deny_reasons`) and OPA's decision log, not in the response.
- **Trino's memory catalog is volatile.** If the Trino pod restarts, re-run `make data`; the
  operator recreates views on its next resync.
