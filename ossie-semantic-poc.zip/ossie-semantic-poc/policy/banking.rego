# OPA policy for the retail-banking POC model.
#
# This is an ADDITIVE gate evaluated by the Semantic Server before a query is
# planned or served from cache. The SemanticModel's own governance (role
# allowMetrics, PII denyFields, the Texas row filter) still applies; this
# policy adds controls the model cannot express:
#
#   1. Identity directory: only known principals may query.
#   2. Role entitlement: a principal may assume only roles it is entitled to.
#      (Header auth trusts X-Semantic-Role; OPA closes that gap for the POC.
#      In production you would use OIDC/JWT and map groups to roles.)
#   3. AI-agent data minimisation: the agent principal may only use the MCP
#      adapter, may not group or filter by customer-level attributes, and must
#      cap result size.
#   4. Separation of duties: AML metrics are reserved for risk roles.
package semantic.banking

import rego.v1

policy_revision := "banking-opa-v1"

# Principal -> roles it may assume. Synthetic users for the POC.
entitlements := {
	"ana.analyst": {"analyst"},
	"tom.txbranch": {"tx_branch_manager"},
	"mia.marketing": {"marketing"},
	"rita.risk": {"risk_officer", "analyst"},
	"dba.admin": {"admin"},
	"agent-bot": {"analyst"},
}

agent_principals := {"agent-bot"}

aml_metrics := {"aml_flag_rate", "flagged_transaction_count"}

risk_roles := {"risk_officer", "admin"}

agent_max_rows := 1000

default allow := false

allow if {
	input.apiVersion == "authorization.semantic.ossie.io/v1alpha1"
	input.action == "query"
	input.model.namespace == "semantic-system"
	input.model.resource == "retail-banking"
	input.model.name == "retail_banking_model"
	count(input.request.metrics) > 0
	input.environment.accessTimeUnixMilli > 0
	count(deny_reasons) == 0
}

# ---- deny reasons (any reason blocks the query) --------------------------

deny_reasons contains "unknown principal" if {
	not entitlements[input.identity.principal]
}

deny_reasons contains msg if {
	some role in input.identity.roles
	not role in entitlements[input.identity.principal]
	msg := sprintf("principal %q is not entitled to role %q", [input.identity.principal, role])
}

deny_reasons contains "AML metrics require a risk role" if {
	some metric in input.request.metrics
	metric in aml_metrics
	count({r | some r in input.identity.roles; r in risk_roles}) == 0
}

deny_reasons contains "agent principals must use the MCP adapter" if {
	input.identity.principal in agent_principals
	input.environment.adapter != "mcp"
}

deny_reasons contains "agent principals may not use customer-level attributes" if {
	input.identity.principal in agent_principals
	some ref in agent_refs
	startswith(ref, "customer.")
}

deny_reasons contains "agent principals must set a limit of at most 1000 rows" if {
	input.identity.principal in agent_principals
	count(input.request.dimensions) > 0
	not bounded_limit
}

bounded_limit if {
	input.request.limit > 0
	input.request.limit <= agent_max_rows
}

agent_refs contains ref if {
	some ref in input.request.dimensions
}

agent_refs contains f.field if {
	some f in input.request.filters
}

# The Semantic Server accepts only {allow, revision} from the decision path,
# so deny_reasons is not returned to it. Query it directly from OPA's data API
# when debugging a denial (see tests/test_governance.sh).
decision := {
	"allow": allow,
	"revision": policy_revision,
}
