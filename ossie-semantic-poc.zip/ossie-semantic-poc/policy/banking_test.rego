# Unit tests for banking.rego. Run with:  opa test policy/ -v
package semantic.banking_test

import rego.v1

import data.semantic.banking

base := {
	"apiVersion": "authorization.semantic.ossie.io/v1alpha1",
	"action": "query",
	"identity": {"principal": "ana.analyst", "roles": ["analyst"]},
	"model": {
		"name": "retail_banking_model",
		"version": "abc123",
		"namespace": "semantic-system",
		"resource": "retail-banking",
	},
	"request": {"metrics": ["fee_revenue"], "dimensions": ["txn.channel"]},
	"environment": {"accessTimeUnixMilli": 1767225600000, "adapter": "rest"},
}

# object.union merges nested objects recursively, so replace whole
# sub-objects by removing them first.
replace(obj, key, value) := object.union(object.remove(obj, [key]), {key: value})

with_identity(principal, roles) := replace(base, "identity", {"principal": principal, "roles": roles})

with_request(req) := replace(base, "request", req)

agent(req) := replace(
	replace(with_identity("agent-bot", ["analyst"]), "environment", {"accessTimeUnixMilli": 1767225600000, "adapter": "mcp"}),
	"request", req,
)

test_entitled_analyst_allowed if {
	banking.decision.allow with input as base
}

test_unknown_principal_denied if {
	not banking.allow with input as with_identity("eve.unknown", ["analyst"])
}

test_role_escalation_denied if {
	not banking.allow with input as with_identity("ana.analyst", ["admin"])
}

test_risk_officer_may_hold_two_roles if {
	banking.allow with input as with_identity("rita.risk", ["analyst"])
}

test_aml_metric_denied_for_analyst if {
	not banking.allow with input as with_request({"metrics": ["aml_flag_rate"]})
}

test_aml_metric_allowed_for_risk_officer if {
	inp := replace(with_identity("rita.risk", ["risk_officer"]), "request", {"metrics": ["aml_flag_rate"]})
	banking.allow with input as inp
}

test_agent_must_use_mcp if {
	inp := replace(with_identity("agent-bot", ["analyst"]), "request", {"metrics": ["fee_revenue"]})
	not banking.allow with input as inp
}

test_agent_on_mcp_allowed_with_limit if {
	inp := agent({"metrics": ["fee_revenue"], "dimensions": ["txn.channel"], "limit": 100})
	banking.allow with input as inp
}

test_agent_without_limit_denied if {
	inp := agent({"metrics": ["fee_revenue"], "dimensions": ["txn.channel"]})
	not banking.allow with input as inp
}

test_agent_scalar_query_needs_no_limit if {
	inp := agent({"metrics": ["fee_revenue"]})
	banking.allow with input as inp
}

test_agent_customer_dimension_denied if {
	inp := agent({"metrics": ["fee_revenue"], "dimensions": ["customer.segment"], "limit": 10})
	not banking.allow with input as inp
}

test_agent_customer_filter_denied if {
	inp := agent({"metrics": ["fee_revenue"], "filters": [{"field": "customer.home_state", "op": "=", "value": "TX"}]})
	not banking.allow with input as inp
}

test_wrong_model_denied if {
	inp := replace(base, "model", {"name": "other", "version": "x", "namespace": "semantic-system", "resource": "other"})
	not banking.allow with input as inp
}

test_decision_shape_is_allow_and_revision_only if {
	d := banking.decision with input as base
	object.keys(d) == {"allow", "revision"}
}
