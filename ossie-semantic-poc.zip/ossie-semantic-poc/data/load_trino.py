"""Load the synthetic banking dataset into Trino (the kind quickstart's memory catalog).

Idempotent: a table whose row count already matches is skipped; --force drops
and reloads everything. Run it against a port-forward to the in-cluster Trino:

    kubectl -n semantic-system port-forward svc/trino 18080:8080 &
    python3 data/load_trino.py --profile full

Env / flags:
    TRINO_HOST (127.0.0.1)  TRINO_PORT (18080)  TRINO_USER (semantic-manager)
    TRINO_CATALOG (memory)  DEMO_SCHEMA (bank_demo)
"""
from __future__ import annotations

import argparse
import os
import sys
import time

import trino

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from bankgen import generate, sql_literal  # noqa: E402

BATCH = 500


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--profile", default="full", choices=["full", "small"])
    ap.add_argument("--force", action="store_true", help="drop and reload all tables")
    args = ap.parse_args()

    catalog = os.getenv("TRINO_CATALOG", "memory")
    schema = os.getenv("DEMO_SCHEMA", "bank_demo")
    conn = trino.dbapi.connect(
        host=os.getenv("TRINO_HOST", "127.0.0.1"),
        port=int(os.getenv("TRINO_PORT", "18080")),
        user=os.getenv("TRINO_USER", "semantic-manager"),
        http_scheme="http",
    )
    cur = conn.cursor()

    def run(sql: str):
        cur.execute(sql)
        return cur.fetchall()

    run(f"CREATE SCHEMA IF NOT EXISTS {catalog}.{schema}")
    for t in generate(args.profile):
        fq = f"{catalog}.{schema}.{t.name}"
        if args.force:
            run(f"DROP TABLE IF EXISTS {fq}")
        run(f"CREATE TABLE IF NOT EXISTS {fq} {t.ddl}")
        have = run(f"SELECT COUNT(*) FROM {fq}")[0][0]
        if have == len(t.rows):
            print(f"{t.name:18s} already loaded ({have:,} rows), skipping")
            continue
        if have:
            print(f"{t.name:18s} has {have:,} rows, want {len(t.rows):,}: reloading")
            run(f"DROP TABLE {fq}")
            run(f"CREATE TABLE {fq} {t.ddl}")
        start = time.time()
        cols = ", ".join(t.columns)
        for i in range(0, len(t.rows), BATCH):
            values = ",".join("(" + ", ".join(sql_literal(v) for v in row) + ")"
                              for row in t.rows[i:i + BATCH])
            run(f"INSERT INTO {fq} ({cols}) VALUES {values}")
        got = run(f"SELECT COUNT(*) FROM {fq}")[0][0]
        print(f"{t.name:18s} loaded {got:,} rows in {time.time() - start:.1f}s")
        if got != len(t.rows):
            sys.exit(f"{t.name}: expected {len(t.rows)} rows, found {got}")
    print(f"banking demo data ready in {catalog}.{schema} ({args.profile} profile)")


if __name__ == "__main__":
    main()
