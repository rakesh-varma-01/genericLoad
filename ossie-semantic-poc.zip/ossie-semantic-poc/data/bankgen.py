"""Deterministic synthetic retail-banking dataset for the Ossie / Semantic Operator POC.

Every value is generated from a fixed seed, so the data (and therefore every
benchmark ground-truth answer) is identical on every machine. No real customer,
account or institution data is used or modeled; names, emails and phone numbers
are obviously fake.

Tables (star schema, two fact tables sharing conformed dimensions):

    date_dim          one row per calendar day, 2024-01-01 .. 2025-12-31
    branch            branches with state, region and employee headcount
    customer          customers with segment, risk rating and PII columns
    account           accounts (deposit and credit products) owned by customers
    txn               transactions (fact) -> account, date_dim
    balance_snapshot  month-end balances (fact, semi-additive) -> account, date_dim

Money is generated in integer cents and rendered as DECIMAL(14,2) text, so
there is no float drift between engines.

Usage as a library:  from bankgen import generate; tables = generate("full")
"""
from __future__ import annotations

import datetime as dt
import random
from dataclasses import dataclass

SEED = 20261101

PROFILES = {
    # name: (customers, accounts, transactions)
    "full": (1500, 2500, 60_000),
    "small": (200, 350, 5_000),
}

START = dt.date(2024, 1, 1)
END = dt.date(2025, 12, 31)

BRANCHES = [
    # branch_id, name, city, state, region
    (1, "Dallas Main", "Dallas", "TX", "South"),
    (2, "Plano Legacy", "Plano", "TX", "South"),
    (3, "Houston Galleria", "Houston", "TX", "South"),
    (4, "Austin Domain", "Austin", "TX", "South"),
    (5, "Manhattan Midtown", "New York", "NY", "Northeast"),
    (6, "Brooklyn Heights", "New York", "NY", "Northeast"),
    (7, "Boston Back Bay", "Boston", "MA", "Northeast"),
    (8, "Chicago Loop", "Chicago", "IL", "Midwest"),
    (9, "Columbus Short North", "Columbus", "OH", "Midwest"),
    (10, "San Jose Downtown", "San Jose", "CA", "West"),
    (11, "Los Angeles Wilshire", "Los Angeles", "CA", "West"),
    (12, "Phoenix Camelback", "Phoenix", "AZ", "West"),
]

SEGMENTS = [("Retail", 70), ("Small Business", 20), ("Private Banking", 10)]
RISK = [("LOW", 75), ("MEDIUM", 20), ("HIGH", 5)]
KYC = [("VERIFIED", 92), ("PENDING", 8)]
STATES = ["TX", "NY", "MA", "IL", "OH", "CA", "AZ", "FL", "GA", "WA"]
FIRST = ["James", "Mary", "Robert", "Patricia", "John", "Jennifer", "Michael", "Linda",
         "David", "Elizabeth", "Ana", "Wei", "Ravi", "Sofia", "Omar", "Yuki", "Priya", "Diego"]
LAST = ["Smith", "Johnson", "Williams", "Brown", "Jones", "Garcia", "Miller", "Davis",
        "Rodriguez", "Martinez", "Chen", "Patel", "Kim", "Nguyen", "Khan", "Lopez", "Okafor", "Silva"]

# product_type -> product_family. DEPOSIT balances are money customers hold at
# the bank; CREDIT balances are money customers owe the bank. Summing both as
# "deposits" is the classic naive-SQL mistake this POC benchmarks.
PRODUCTS = [
    ("Checking", "DEPOSIT", 38),
    ("Savings", "DEPOSIT", 25),
    ("Money Market", "DEPOSIT", 10),
    ("Credit Card", "CREDIT", 20),
    ("Personal Loan", "CREDIT", 7),
]
CHANNELS = [("Card", 40), ("Online", 25), ("ATM", 12), ("Branch", 10), ("Wire", 5), ("Mobile Check", 8)]


@dataclass
class Table:
    name: str
    ddl: str                 # column list for CREATE TABLE (Trino / ANSI types)
    columns: list[str]
    rows: list[tuple]        # Python values; None = NULL


def _pick(rng: random.Random, weighted):
    names = [w[0] for w in weighted]
    weights = [w[-1] for w in weighted]
    return rng.choices(names, weights=weights, k=1)[0]


def _date_key(d: dt.date) -> int:
    return int(d.strftime("%Y%m%d"))


def _month_ends(start: dt.date, end: dt.date):
    y, m = start.year, start.month
    while True:
        nxt = dt.date(y + (m == 12), (m % 12) + 1, 1)
        me = nxt - dt.timedelta(days=1)
        if me > end:
            return
        if me >= start:
            yield me
        y, m = nxt.year, nxt.month


def _money(cents: int) -> str:
    sign = "-" if cents < 0 else ""
    cents = abs(cents)
    return f"{sign}{cents // 100}.{cents % 100:02d}"


def generate(profile: str = "full") -> list[Table]:
    if profile not in PROFILES:
        raise ValueError(f"unknown profile {profile!r}; want one of {sorted(PROFILES)}")
    n_cust, n_acct, n_txn = PROFILES[profile]

    # ---- date_dim -------------------------------------------------------
    dates = []
    d = START
    while d <= END:
        q = (d.month - 1) // 3 + 1
        dates.append((_date_key(d), d, d.year, f"{d.year}Q{q}", d.month, d.strftime("%B"),
                      d.strftime("%Y-%m")))
        d += dt.timedelta(days=1)

    # ---- branch ---------------------------------------------------------
    rng = random.Random(SEED + 1)
    branches = [(bid, name, city, st, region, rng.randint(8, 60))
                for bid, name, city, st, region in BRANCHES]

    # ---- customer -------------------------------------------------------
    rng = random.Random(SEED + 2)
    customers = []
    for i in range(1, n_cust + 1):
        fn, ln = rng.choice(FIRST), rng.choice(LAST)
        customers.append((
            i, f"CUS{i:07d}", f"{fn} {ln}",
            f"{fn.lower()}.{ln.lower()}.{i}@example.invalid",
            f"555-01{i % 100:02d}",            # 555-01xx is reserved for fiction
            _pick(rng, SEGMENTS), rng.choice(STATES), _pick(rng, RISK), _pick(rng, KYC),
            rng.randint(2010, 2025),
        ))

    # ---- account --------------------------------------------------------
    rng = random.Random(SEED + 3)
    accounts = []
    for i in range(1, n_acct + 1):
        cust = rng.randint(1, n_cust)
        branch = rng.randint(1, len(BRANCHES))
        ptype = _pick(rng, PRODUCTS)
        family = next(f for p, f, _ in PRODUCTS if p == ptype)
        opened = dt.date(2018, 1, 1) + dt.timedelta(days=rng.randint(0, (END - dt.date(2018, 1, 1)).days))
        status = "OPEN"
        closed = None
        r = rng.random()
        if r < 0.06 and opened < dt.date(2025, 6, 1):
            status = "CLOSED"
            closed = opened + dt.timedelta(days=rng.randint(60, (dt.date(2025, 12, 1) - opened).days))
            closed = min(closed, dt.date(2025, 11, 30))
        elif r < 0.10:
            status = "DORMANT"
        credit_limit = (rng.randint(20, 300) * 10_000) if ptype == "Credit Card" else None
        accounts.append((i, f"ACC{i:09d}", cust, branch, ptype, family, status,
                         _date_key(opened), _date_key(closed) if closed else None,
                         _money(credit_limit) if credit_limit is not None else None))

    # ---- txn ------------------------------------------------------------
    rng = random.Random(SEED + 4)
    span = (END - START).days
    open_or_dormant = [a for a in accounts]
    txns = []
    for i in range(1, n_txn + 1):
        a = rng.choice(open_or_dormant)
        acct_id, family = a[0], a[5]
        day = START + dt.timedelta(days=rng.randint(0, span))
        channel = _pick(rng, CHANNELS)
        if family == "DEPOSIT":
            direction = "CREDIT" if rng.random() < 0.46 else "DEBIT"
        else:  # card purchases and loan draws are debits, payments are credits
            direction = "DEBIT" if rng.random() < 0.62 else "CREDIT"
        if channel == "Wire":
            cents = rng.randint(50_000, 2_500_000)
        elif channel == "Card":
            cents = rng.randint(300, 40_000)
        else:
            cents = rng.randint(1_000, 300_000)
        fee = 0
        if channel == "Wire":
            fee = 2_500 if direction == "DEBIT" else 1_500
        elif channel == "ATM" and rng.random() < 0.30:
            fee = 300
        elif family == "CREDIT" and direction == "DEBIT" and rng.random() < 0.05:
            fee = 3_900   # late / over-limit fee
        flagged = 1 if (rng.random() < (0.06 if channel == "Wire" else 0.01)) else 0
        txns.append((i, acct_id, _date_key(day), channel, direction,
                     _money(cents), _money(fee), flagged))

    # ---- balance_snapshot (month-end, semi-additive) --------------------
    rng = random.Random(SEED + 5)
    snaps = []
    for a in accounts:
        acct_id, family, opened_k, closed_k, ptype = a[0], a[5], a[7], a[8], a[4]
        if family == "DEPOSIT":
            base = {"Checking": 450_000, "Savings": 1_800_000, "Money Market": 5_500_000}[ptype]
        else:
            base = {"Credit Card": 260_000, "Personal Loan": 1_400_000}[ptype]
        level = rng.randint(base // 4, base * 2)
        for me in _month_ends(START, END):
            k = _date_key(me)
            if k < opened_k or (closed_k is not None and k >= closed_k):
                continue
            level = max(0, int(level * (1 + rng.uniform(-0.06, 0.08))))
            snaps.append((acct_id, k, family, _money(level)))

    return [
        Table("date_dim",
              "(date_key INTEGER, cal_date DATE, cal_year INTEGER, quarter_name VARCHAR(7), "
              "month_num INTEGER, month_name VARCHAR(12), year_month VARCHAR(7))",
              ["date_key", "cal_date", "cal_year", "quarter_name", "month_num", "month_name", "year_month"],
              dates),
        Table("branch",
              "(branch_id INTEGER, branch_name VARCHAR(40), city VARCHAR(40), state VARCHAR(2), "
              "region VARCHAR(12), headcount INTEGER)",
              ["branch_id", "branch_name", "city", "state", "region", "headcount"],
              branches),
        Table("customer",
              "(customer_id INTEGER, customer_number VARCHAR(12), full_name VARCHAR(60), "
              "email VARCHAR(80), phone VARCHAR(12), segment VARCHAR(20), home_state VARCHAR(2), "
              "risk_rating VARCHAR(8), kyc_status VARCHAR(10), onboard_year INTEGER)",
              ["customer_id", "customer_number", "full_name", "email", "phone", "segment",
               "home_state", "risk_rating", "kyc_status", "onboard_year"],
              customers),
        Table("account",
              "(account_id INTEGER, account_number VARCHAR(14), customer_id INTEGER, branch_id INTEGER, "
              "product_type VARCHAR(20), product_family VARCHAR(8), status VARCHAR(8), "
              "open_date_key INTEGER, close_date_key INTEGER, credit_limit DECIMAL(14,2))",
              ["account_id", "account_number", "customer_id", "branch_id", "product_type",
               "product_family", "status", "open_date_key", "close_date_key", "credit_limit"],
              accounts),
        Table("txn",
              "(txn_id BIGINT, account_id INTEGER, txn_date_key INTEGER, channel VARCHAR(16), "
              "direction VARCHAR(6), amount DECIMAL(14,2), fee_amount DECIMAL(14,2), is_flagged INTEGER)",
              ["txn_id", "account_id", "txn_date_key", "channel", "direction", "amount",
               "fee_amount", "is_flagged"],
              txns),
        Table("balance_snapshot",
              "(account_id INTEGER, snapshot_date_key INTEGER, product_family VARCHAR(8), "
              "balance DECIMAL(14,2))",
              ["account_id", "snapshot_date_key", "product_family", "balance"],
              snaps),
    ]


def sql_literal(v) -> str:
    """Render a Python value as a Trino/ANSI SQL literal."""
    if v is None:
        return "NULL"
    if isinstance(v, dt.date):
        return f"DATE '{v.isoformat()}'"
    if isinstance(v, int):
        return str(v)
    if isinstance(v, str):
        # money strings are numeric literals; everything else is quoted
        if v and (v[0].isdigit() or v[0] == "-") and v.replace("-", "", 1).replace(".", "", 1).isdigit() and "." in v:
            return v
        return "'" + v.replace("'", "''") + "'"
    raise TypeError(f"unsupported value {v!r}")


if __name__ == "__main__":
    import sys
    prof = sys.argv[1] if len(sys.argv) > 1 else "full"
    for t in generate(prof):
        print(f"{t.name:18s} {len(t.rows):>7,d} rows")
