#!/usr/bin/env bash
# Deploy OPA with the banking policy (policy/banking.rego).
source "$(dirname "$0")/lib.sh"

log "Loading policy/banking.rego into ConfigMap opa-banking-policy"
"${KNS[@]}" create configmap opa-banking-policy \
  --from-file="banking.rego=$POC_DIR/policy/banking.rego" --dry-run=client -o yaml |
  "${KNS[@]}" apply -f -
"${KNS[@]}" apply -f "$POC_DIR/deploy/opa.yaml"
# OPA reads file-backed policies at startup, so restart to pick up edits.
"${KNS[@]}" rollout restart deployment/opa
"${KNS[@]}" rollout status deployment/opa --timeout=3m
log "OPA ready (decision path semantic/banking/decision)"
