#!/usr/bin/env bash
# Create the kind cluster, deploy Trino, and install the Semantic Operator.
source "$(dirname "$0")/lib.sh"
require docker kind kubectl helm git make

log "Fetching kubeflow/semantic-operator @ ${SO_COMMIT:0:12}"
if [[ ! -d "$SO_DIR/.git" ]]; then
  git clone --filter=blob:none "$SO_REPO_URL" "$SO_DIR"
fi
git -C "$SO_DIR" fetch --quiet origin "$SO_COMMIT" 2>/dev/null || git -C "$SO_DIR" fetch --quiet origin
git -C "$SO_DIR" -c advice.detachedHead=false checkout --quiet "$SO_COMMIT"

log "Creating kind cluster $CLUSTER_NAME"
mkdir -p "$(dirname "$KUBECONFIG_PATH")"
if kind get clusters 2>/dev/null | grep -Fxq "$CLUSTER_NAME"; then
  echo "Reusing existing cluster"
  kind export kubeconfig --name "$CLUSTER_NAME" --kubeconfig "$KUBECONFIG_PATH"
else
  kind create cluster --name "$CLUSTER_NAME" --kubeconfig "$KUBECONFIG_PATH" --wait 120s
fi
chmod 0600 "$KUBECONFIG_PATH"

log "Deploying plaintext Trino (in-memory catalog) from the upstream quickstart"
"${KUBECTL[@]}" create namespace "$NAMESPACE" --dry-run=client -o yaml | "${KUBECTL[@]}" apply -f -
"${KNS[@]}" apply -f "$SO_DIR/test/e2e/trino/quickstart.yaml"
"${KNS[@]}" rollout status deployment/trino --timeout=6m

log "Building manager and server images ($PLATFORM) and loading them into kind"
make -C "$SO_DIR" docker-build IMAGE_BASE="$IMAGE_BASE" TAG="$IMAGE_TAG" PLATFORM="$PLATFORM"
kind load docker-image "$IMAGE_BASE/manager:$IMAGE_TAG" "$IMAGE_BASE/server:$IMAGE_TAG" --name "$CLUSTER_NAME"

log "Installing the Semantic Operator chart"
"${HELM[@]}" upgrade --install "$RELEASE" "$SO_DIR/charts/semantic-operator" \
  --namespace "$NAMESPACE" --create-namespace \
  --values "$POC_DIR/deploy/helm-values.yaml" \
  --set-string "image.manager.repository=$IMAGE_BASE/manager" \
  --set-string "image.server.repository=$IMAGE_BASE/server" \
  --set-string "image.tag=$IMAGE_TAG" \
  --wait --timeout 6m
"${KNS[@]}" rollout restart deployment/"$RELEASE"-manager deployment/"$RELEASE"-server
"${KNS[@]}" rollout status deployment/"$RELEASE"-manager --timeout=3m
"${KNS[@]}" rollout status deployment/"$RELEASE"-server --timeout=3m

log "Cluster ready"
"${KNS[@]}" get pods
echo
echo "kubectl access:  export KUBECONFIG=$KUBECONFIG_PATH"
