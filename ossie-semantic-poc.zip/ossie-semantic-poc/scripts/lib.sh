#!/usr/bin/env bash
# Shared settings and helpers for the POC scripts. Source it; do not run it.
# shellcheck disable=SC2034  # variables here are used by the scripts that source this file
set -euo pipefail

POC_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

# Upstream Semantic Operator checkout, pinned so the POC is reproducible.
SO_REPO_URL="${SO_REPO_URL:-https://github.com/kubeflow/semantic-operator.git}"
SO_COMMIT="${SO_COMMIT:-4fd7057ef3a67b3711a927e639e6a78550d6c945}"   # main @ 2026-10-23
SO_DIR="${SO_DIR:-$POC_DIR/semantic-operator}"

CLUSTER_NAME="${KIND_CLUSTER_NAME:-ossie-poc}"
NAMESPACE="${KIND_NAMESPACE:-semantic-system}"
RELEASE="${KIND_RELEASE_NAME:-semantic-operator}"
KUBECONFIG_PATH="${KIND_KUBECONFIG:-$POC_DIR/.kube/config}"
IMAGE_BASE="${KIND_IMAGE_BASE:-semantic-operator-kind}"
IMAGE_TAG="${KIND_IMAGE_TAG:-poc}"
PLATFORM="${PLATFORM:-linux/$( [[ "$(uname -m)" =~ ^(arm64|aarch64)$ ]] && echo arm64 || echo amd64 )}"

MODEL_RESOURCE=retail-banking
MODEL_NAME=retail_banking_model
SERVER_PORT="${SERVER_PORT:-8090}"
TRINO_PORT="${TRINO_PORT:-18080}"
OPA_PORT="${OPA_PORT:-18181}"
VENV="$POC_DIR/.venv"

KUBECTL=(kubectl --kubeconfig "$KUBECONFIG_PATH" --context "kind-$CLUSTER_NAME")
KNS=("${KUBECTL[@]}" --namespace "$NAMESPACE")
HELM=(helm --kubeconfig "$KUBECONFIG_PATH" --kube-context "kind-$CLUSTER_NAME")

c_green=$'\e[32m'; c_red=$'\e[31m'; c_yellow=$'\e[33m'; c_bold=$'\e[1m'; c_off=$'\e[0m'
log()  { printf '%s==>%s %s\n' "$c_bold" "$c_off" "$*"; }
ok()   { printf '  %sPASS%s %s\n' "$c_green" "$c_off" "$*"; }
bad()  { printf '  %sFAIL%s %s\n' "$c_red" "$c_off" "$*"; FAILURES=$((FAILURES + 1)); }
warn() { printf '  %sWARN%s %s\n' "$c_yellow" "$c_off" "$*"; }
FAILURES=0

# ---- port-forwards ---------------------------------------------------------
PF_PIDS=()
cleanup_pf() { for p in "${PF_PIDS[@]:-}"; do [[ -n "$p" ]] && kill "$p" 2>/dev/null || true; done; }
trap cleanup_pf EXIT

# port_forward <service> <local> <remote> <health-url>
port_forward() {
  local svc=$1 lport=$2 rport=$3 health=$4
  if curl -fs -o /dev/null --max-time 2 "$health"; then return 0; fi   # already forwarded
  "${KNS[@]}" port-forward "service/$svc" "$lport:$rport" --address 127.0.0.1 >/dev/null 2>&1 &
  PF_PIDS+=("$!")
  for _ in $(seq 60); do
    curl -fs -o /dev/null --max-time 2 "$health" && return 0
    sleep 1
  done
  echo "port-forward to $svc did not become healthy at $health" >&2
  return 1
}
pf_server() { port_forward "$RELEASE-server" "$SERVER_PORT" 8090 "http://127.0.0.1:$SERVER_PORT/healthz"; }
pf_trino()  { port_forward trino "$TRINO_PORT" 8080 "http://127.0.0.1:$TRINO_PORT/v1/info"; }
pf_opa()    { port_forward opa "$OPA_PORT" 8181 "http://127.0.0.1:$OPA_PORT/health"; }

# ---- semantic REST ---------------------------------------------------------
# sq <user> <role> <json-body>  -> sets HTTP_CODE and BODY
sq() {
  local tmp; tmp="$(mktemp)"
  HTTP_CODE="$(curl -s -o "$tmp" -w '%{http_code}' -X POST \
    "http://127.0.0.1:$SERVER_PORT/v1/models/$MODEL_NAME/query" \
    -H "X-Semantic-User: $1" -H "X-Semantic-Role: $2" -H 'Content-Type: application/json' -d "$3")"
  BODY="$(cat "$tmp")"; rm -f "$tmp"
}

# trino_sql <sql> -> TSV rows on stdout (runs the CLI inside the Trino pod)
trino_sql() {
  "${KNS[@]}" exec deploy/trino -- trino --user "${TRINO_USER:-bi-user}" --output-format "${TRINO_FORMAT:-TSV}" --execute "$1"
}

model_condition() {  # model_condition <Type> -> True/False/""
  "${KNS[@]}" get "semanticmodel/$MODEL_RESOURCE" \
    -o jsonpath="{.status.conditions[?(@.type==\"$1\")].status}" 2>/dev/null || true
}
model_version() {
  "${KNS[@]}" get "semanticmodel/$MODEL_RESOURCE" -o jsonpath='{.status.modelVersion}' 2>/dev/null || true
}

require() { for b in "$@"; do command -v "$b" >/dev/null || { echo "missing required tool: $b" >&2; exit 1; }; done; }

py() { "$VENV/bin/python" -I "$@"; }
