#!/usr/bin/env bash
# Validate the SemanticModel offline, apply it, and wait until it is published.
source "$(dirname "$0")/lib.sh"
MODEL_FILE="${MODEL_FILE:-$POC_DIR/model/retail-banking.yaml}"
CRD="$SO_DIR/charts/semantic-operator/crds/semantic.ossie.io_semanticmodels.yaml"

log "Offline pre-flight (Python port of the operator's structural checks + CRD schema)"
py "$POC_DIR/validate/validate_model.py" "$MODEL_FILE" --crd "$CRD"

if command -v go >/dev/null; then
  log "ossiectl validate (the authoritative check)"
  (cd "$SO_DIR" && go run ./cmd/ossiectl validate -f "$MODEL_FILE")
else
  warn "go not installed: skipping ossiectl validate (the operator validates again on apply)"
fi

log "Applying SemanticModel/$MODEL_RESOURCE"
"${KNS[@]}" apply -f "$MODEL_FILE"
for cond in Validated Compiled Published ViewsReady; do
  if ! "${KNS[@]}" wait --for=condition="$cond" "semanticmodel/$MODEL_RESOURCE" --timeout=4m; then
    "${KNS[@]}" get "semanticmodel/$MODEL_RESOURCE" -o yaml | sed -n '/^status:/,$p'
    exit 1
  fi
done
log "Published model version $(model_version)"
"${KNS[@]}" get "semanticmodel/$MODEL_RESOURCE" \
  -o custom-columns='NAME:.metadata.name,VERSION:.status.modelVersion,VALIDATED:.status.conditions[?(@.type=="Validated")].status,PUBLISHED:.status.conditions[?(@.type=="Published")].status,DRIFT:.status.conditions[?(@.type=="DriftDetected")].status,VIEWS:.status.conditions[?(@.type=="ViewsReady")].status'
