#!/usr/bin/env bash
# Delete the kind cluster. The upstream checkout and .venv are kept.
source "$(dirname "$0")/lib.sh"
log "Deleting kind cluster $CLUSTER_NAME"
kind delete cluster --name "$CLUSTER_NAME"
rm -f "$KUBECONFIG_PATH"
