#!/usr/bin/env bash
# Create the Python venv and load the synthetic banking data into Trino.
#   PROFILE=small ./scripts/03-data.sh   for a faster, smaller load
source "$(dirname "$0")/lib.sh"

if [[ ! -x "$VENV/bin/python" ]]; then
  log "Creating Python venv in .venv"
  python3 -m venv "$VENV"
fi
"$VENV/bin/pip" install --quiet --upgrade pip
"$VENV/bin/pip" install --quiet -r "$POC_DIR/requirements.txt"

pf_trino
log "Loading synthetic banking data (${PROFILE:-full} profile) into memory.bank_demo"
TRINO_PORT="$TRINO_PORT" py "$POC_DIR/data/load_trino.py" --profile "${PROFILE:-full}" ${FORCE:+--force}
