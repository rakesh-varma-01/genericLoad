#!/usr/bin/env bash
# Check laptop prerequisites before anything is created.
source "$(dirname "$0")/lib.sh"

log "Checking tools"
missing=0
for b in docker kind kubectl helm git make curl python3; do
  if command -v "$b" >/dev/null; then ok "$b: $(command -v "$b")"; else bad "$b not found"; missing=1; fi
done
if command -v go >/dev/null; then
  ok "go: $(go version | awk '{print $3}') (optional; used only for ossiectl validate)"
else
  warn "go not found: the images still build inside Docker, but ossiectl validate is skipped"
fi

log "Checking Docker"
if docker info >/dev/null 2>&1; then
  mem_gb=$(( $(docker info --format '{{.MemTotal}}') / 1024 / 1024 / 1024 ))
  cpus=$(docker info --format '{{.NCPU}}')
  if (( mem_gb >= 6 )); then ok "Docker has ${mem_gb} GiB memory, ${cpus} CPUs"
  else warn "Docker has ${mem_gb} GiB memory; give it at least 6 GiB (Trino needs ~2 GiB)"; fi
else
  bad "Docker daemon is not running"; missing=1
fi

log "Checking Python"
if python3 -c 'import sys; sys.exit(0 if sys.version_info >= (3, 10) else 1)'; then
  ok "python3 $(python3 -V | awk '{print $2}')"
else
  bad "python3 3.10+ required"; missing=1
fi

for port in "$SERVER_PORT" "$TRINO_PORT" "$OPA_PORT"; do
  if (exec 3<>/dev/tcp/127.0.0.1/"$port") 2>/dev/null; then warn "local port $port is already in use"; fi
done

(( missing == 0 )) && log "Prerequisites look good" || { echo "Install the missing tools and retry." >&2; exit 1; }
