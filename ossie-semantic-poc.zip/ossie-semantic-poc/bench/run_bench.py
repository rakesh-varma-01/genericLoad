"""Agent-accuracy benchmark: raw text-to-SQL versus the Ossie semantic layer over MCP.

For every question and paraphrase in questions.yaml the same LLM answers twice:

  raw       sees the warehouse DDL and a run_sql tool, writes Trino SQL itself
  semantic  sees only the MCP tools (list_metrics, list_dimensions,
            query_metric) served by the Semantic Server

The answer of each path is the result set of its LAST successful query. It is
compared with the ground-truth result set (run on the same Trino) using the
same structural rule as the upstream benchmark (internal/nlbench/compare.go):
rows keyed by labels, numbers within 0.5% relative tolerance, extra numeric
columns allowed.

Prerequisites (scripts/03-data.sh and scripts/04-model.sh have run):
    kubectl -n semantic-system port-forward svc/semantic-operator-server 8090:8090
    kubectl -n semantic-system port-forward svc/trino 18080:8080
    export ANTHROPIC_API_KEY=...

    python3 bench/run_bench.py                       # all questions, both paths
    python3 bench/run_bench.py --only q03,q04 --path semantic

Env: SEMANTIC_URL (http://127.0.0.1:8090)  TRINO_HOST/PORT (127.0.0.1/18080)
     BENCH_MODEL (claude-sonnet-5-5)  BENCH_TEMPERATURE (0; empty to omit)
     BENCH_PRINCIPAL (rita.risk)  BENCH_ROLE (risk_officer)

Data note: questions and schema are sent to the configured LLM API. The data
is synthetic; do not point this harness at real or employer data.
"""
from __future__ import annotations

import argparse
import asyncio
import datetime as dt
import decimal
import json
import math
import os
import sys
import time
from dataclasses import dataclass, field

import yaml

HERE = os.path.dirname(os.path.abspath(__file__))
REL_TOLERANCE = 0.005
MAX_TURNS = 8

CATALOG = os.getenv("TRINO_CATALOG", "memory")
SCHEMA = os.getenv("DEMO_SCHEMA", "bank_demo")
SEMANTIC_URL = os.getenv("SEMANTIC_URL", "http://127.0.0.1:8090").rstrip("/")
PRINCIPAL = os.getenv("BENCH_PRINCIPAL", "rita.risk")
ROLE = os.getenv("BENCH_ROLE", "risk_officer")
MODEL = os.getenv("BENCH_MODEL", "claude-sonnet-5-5")
TEMPERATURE = os.getenv("BENCH_TEMPERATURE", "0")

COMMON_RULES = (
    "Answer the user's business question with data. When you have the final "
    "result, stop calling tools and reply with one short sentence. Your LAST "
    "successful query is taken as your answer, so make sure it returns exactly "
    "the rows the question asks for (one row for a single number; one row per "
    "group for a breakdown) and no unrelated rows. Never ask the user a question."
)


# ------------------------------------------------------------- compare -----
def as_number(v):
    if isinstance(v, bool):
        return None
    if isinstance(v, (int, float, decimal.Decimal)):
        return float(v)
    if isinstance(v, str):
        try:
            return float(v.strip())
        except ValueError:
            return None
    return None


def canon_label(v) -> str:
    if isinstance(v, (dt.datetime, dt.date)):
        return v.isoformat()[:10]
    s = str(v).strip()
    # timestamps from JSON ("2025-03-01T00:00:00Z") and SQL ("2025-03-01 00:00:00")
    if len(s) >= 10 and s[4] == "-" and s[7] == "-" and s[:4].isdigit():
        return s[:10]
    return s


def normalize(rows):
    out = []
    for r in rows:
        labels, nums = [], []
        for c in r:
            if c is None:
                labels.append("NULL")
                continue
            n = as_number(c)
            if n is not None:
                nums.append(n)
            else:
                labels.append(canon_label(c))
        out.append((sorted(labels), sorted(nums)))
    out.sort(key=lambda x: ("\x00".join(x[0]), x[1]))
    return out


def close(a: float, b: float) -> bool:
    if a == b:
        return True
    den = max(abs(a), abs(b))
    return den == 0 or abs(a - b) / den <= REL_TOLERANCE


def rows_match(gt, got) -> bool:
    if gt[0] != got[0] or len(got[1]) < len(gt[1]):
        return False
    used = [False] * len(got[1])
    for want in gt[1]:
        for i, have in enumerate(got[1]):
            if not used[i] and close(want, have):
                used[i] = True
                break
        else:
            return False
    return True


def compare(gt_rows, res: "PathResult") -> str:
    if not res.query:
        return "failed" if res.attempted else "noquery"
    gt, got = normalize(gt_rows), normalize(res.rows)
    if len(gt) != len(got):
        return "wrong"
    return "correct" if all(rows_match(a, b) for a, b in zip(gt, got)) else "wrong"


# ----------------------------------------------------------------- LLM -----
class LLM:
    def __init__(self, model: str):
        import anthropic
        self.client = anthropic.Anthropic()
        self.model = model

    def turn(self, system: str, messages: list, tools: list):
        kwargs = dict(model=self.model, max_tokens=2048, system=system,
                      messages=messages, tools=tools)
        if TEMPERATURE != "":
            kwargs["temperature"] = float(TEMPERATURE)
        for attempt in range(5):
            try:
                return self.client.messages.create(**kwargs)
            except Exception as e:  # rate limits / overload: back off and retry
                if attempt == 4 or "rate" not in str(e).lower() and "overload" not in str(e).lower():
                    raise
                time.sleep(2 ** attempt * 3)


@dataclass
class PathResult:
    query: str = ""                     # last SQL (raw) or last request JSON (semantic)
    sql: str = ""                       # SQL that produced the answer
    rows: list = field(default_factory=list)
    error: str = ""
    tool_calls: int = 0
    attempted: bool = False             # at least one query was tried


async def agent_loop(llm: LLM, system: str, question: str, tools: list, call_tool) -> PathResult:
    res = PathResult()
    messages = [{"role": "user", "content": question}]
    for _ in range(MAX_TURNS):
        resp = await asyncio.to_thread(llm.turn, system, messages, tools)
        messages.append({"role": "assistant", "content": resp.content})
        uses = [b for b in resp.content if b.type == "tool_use"]
        if not uses:
            break
        results = []
        for u in uses:
            res.tool_calls += 1
            text, is_error = await call_tool(u.name, u.input, res)
            results.append({"type": "tool_result", "tool_use_id": u.id,
                            "content": text[:20000], "is_error": is_error})
        messages.append({"role": "user", "content": results})
    if not res.query and not res.error:
        res.error = "agent produced no successful query"
    return res


# ------------------------------------------------------------ raw path ----
def trino_conn(user: str):
    import trino
    return trino.dbapi.connect(host=os.getenv("TRINO_HOST", "127.0.0.1"),
                               port=int(os.getenv("TRINO_PORT", "18080")),
                               user=user, catalog=CATALOG, schema=SCHEMA, http_scheme="http")


def run_trino(sql: str, user: str = "bench-raw"):
    cur = trino_conn(user).cursor()
    cur.execute(sql)
    rows = cur.fetchall()
    cols = [d[0] for d in cur.description]
    return cols, rows


def schema_ddl() -> str:
    _, tables = run_trino(f"SHOW TABLES FROM {CATALOG}.{SCHEMA}")
    parts = []
    for (t,) in sorted(tables):
        _, ddl = run_trino(f"SHOW CREATE TABLE {CATALOG}.{SCHEMA}.{t}")
        parts.append(ddl[0][0])
    return "\n\n".join(parts)


RAW_TOOLS = [{
    "name": "run_sql",
    "description": "Run one read-only Trino SQL query and return up to 200 rows as JSON.",
    "input_schema": {"type": "object", "properties": {"sql": {"type": "string"}}, "required": ["sql"]},
}]


async def raw_path(llm: LLM, question: str, ddl: str) -> PathResult:
    system = (f"You are a data analyst at a retail bank. The warehouse runs Trino. "
              f"All tables live in {CATALOG}.{SCHEMA}. Schema:\n\n{ddl}\n\n{COMMON_RULES}")

    async def call(name, args, res: PathResult):
        sql = (args or {}).get("sql", "").strip().rstrip(";")
        if name != "run_sql" or not sql:
            return "error: call run_sql with a sql argument", True
        res.attempted = True
        try:
            cols, rows = await asyncio.to_thread(run_trino, sql)
        except Exception as e:  # SQL error: tell the model, keep last good answer
            res.error = res.error if res.query else f"sql error: {e}"
            return f"error: {e}", True
        res.query, res.sql, res.rows, res.error = sql, sql, rows, ""
        return json.dumps({"columns": cols, "rows": rows[:200]}, default=str), False

    return await agent_loop(llm, system, question, RAW_TOOLS, call)


# ------------------------------------------------------- semantic path ----
async def semantic_path(llm: LLM, question: str) -> PathResult:
    from mcp import ClientSession
    from mcp.client.streamable_http import streamablehttp_client

    headers = {"X-Semantic-User": PRINCIPAL, "X-Semantic-Role": ROLE}
    async with streamablehttp_client(f"{SEMANTIC_URL}/mcp", headers=headers) as (read, write, _):
        async with ClientSession(read, write) as session:
            await session.initialize()
            listed = await session.list_tools()
            tools = [{"name": t.name, "description": t.description or "",
                      "input_schema": t.inputSchema} for t in listed.tools]
            system = ("You are a data analyst at a retail bank. Use only the semantic-layer "
                      "tools: ground the question with list_metrics and list_dimensions, then "
                      "call query_metric. Never invent metrics or SQL. " + COMMON_RULES)

            async def call(name, args, res: PathResult):
                if name == "query_metric":
                    res.attempted = True
                out = await session.call_tool(name, args or {})
                text = "\n".join(c.text for c in out.content if getattr(c, "type", "") == "text")
                payload = out.structuredContent
                if payload is None:
                    try:
                        payload = json.loads(text)
                    except (ValueError, TypeError):
                        payload = None
                if out.isError:
                    if name == "query_metric":
                        res.error = res.error if res.query else f"query error: {text}"
                    return text or "error", True
                if name == "query_metric" and isinstance(payload, dict):
                    res.query = json.dumps(args, sort_keys=True)
                    res.sql = payload.get("sql", "")
                    res.rows = payload.get("rows") or []
                    res.error = ""
                return text or json.dumps(payload, default=str), False

            return await agent_loop(llm, system, question, tools, call)


# ----------------------------------------------------------------- main ----
async def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--only", help="comma-separated question ids")
    ap.add_argument("--path", choices=["raw", "semantic", "both"], default="both")
    ap.add_argument("--out", default=os.path.join(HERE, "RESULTS.md"))
    args = ap.parse_args()

    if not os.getenv("ANTHROPIC_API_KEY"):
        sys.exit("ANTHROPIC_API_KEY is not set")
    with open(os.path.join(HERE, "questions.yaml")) as fh:
        questions = yaml.safe_load(fh)["questions"]
    if args.only:
        keep = set(args.only.split(","))
        questions = [q for q in questions if q["id"] in keep]

    llm = LLM(MODEL)
    paths = ["raw", "semantic"] if args.path == "both" else [args.path]
    ddl = schema_ddl() if "raw" in paths else ""
    records = []
    for q in questions:
        gt_sql = q["ground_truth_sql"].replace("$DB.", f"{CATALOG}.{SCHEMA}.")
        _, gt_rows = run_trino(gt_sql, user="bench-ground-truth")
        for i, phrasing in enumerate([q["question"], *q.get("paraphrases", [])]):
            for p in paths:
                start = time.time()
                try:
                    res = await (raw_path(llm, phrasing, ddl) if p == "raw" else semantic_path(llm, phrasing))
                except Exception as e:
                    res = PathResult(error=f"harness error: {e}")
                verdict = compare(gt_rows, res)
                records.append({"id": q["id"], "phrasing": i, "path": p, "question": phrasing,
                                "trap": q.get("trap", "none"), "verdict": verdict,
                                "rows": res.rows[:10], "ground_truth": gt_rows[:10],
                                "sql": res.sql, "request": res.query, "error": res.error,
                                "tool_calls": res.tool_calls, "seconds": round(time.time() - start, 1)})
                print(f"{q['id']} #{i} {p:8s} {verdict:8s} ({res.tool_calls} tool calls)", flush=True)

    with open(os.path.splitext(args.out)[0] + ".json", "w") as fh:
        json.dump(records, fh, indent=2, default=str)
    write_report(records, paths, args.out)
    print(f"wrote {args.out}")
    return 0


def write_report(records, paths, out):
    lines = [f"# Benchmark results\n", f"Model `{MODEL}`, temperature `{TEMPERATURE or 'default'}`, "
             f"identity `{PRINCIPAL}` / `{ROLE}`, run {dt.datetime.now():%Y-%m-%d %H:%M}.\n",
             "| Path | Correct | Consistent across phrasings | Wrong but ran | Failed / no query |",
             "|---|---|---|---|---|"]
    ids = sorted({r["id"] for r in records})
    for p in paths:
        rs = [r for r in records if r["path"] == p]
        correct = sum(r["verdict"] == "correct" for r in rs)
        consistent = sum(all(r["verdict"] == "correct" for r in rs if r["id"] == q) for q in ids)
        wrong = sum(r["verdict"] == "wrong" for r in rs)
        failed = sum(r["verdict"] in ("failed", "noquery") for r in rs)
        lines.append(f"| {p} | {correct}/{len(rs)} ({100 * correct / max(len(rs), 1):.0f}%) | "
                     f"{consistent}/{len(ids)} | {wrong} | {failed} |")
    lines += ["", "## Per question", "", "| Question | Trap | " + " | ".join(paths) + " |",
              "|---|---|" + "---|" * len(paths)]
    for q in ids:
        rs = [r for r in records if r["id"] == q]
        cells = []
        for p in paths:
            vs = [r["verdict"] for r in sorted(rs, key=lambda r: r["phrasing"]) if r["path"] == p]
            cells.append(" ".join({"correct": "✅", "wrong": "❌", "failed": "⚠️", "noquery": "∅"}[v] for v in vs))
        lines.append(f"| {q}: {rs[0]['question']} | {rs[0]['trap']} | " + " | ".join(cells) + " |")
    lines += ["", "✅ correct · ❌ ran but returned the wrong numbers · ⚠️ errored · ∅ no query",
              "", "Full detail (SQL, requests, rows) is in the matching .json file."]
    with open(out, "w") as fh:
        fh.write("\n".join(lines) + "\n")


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
