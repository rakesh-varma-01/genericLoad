"""Educational CDE candidate model: synthetic data, NumPy TF-IDF and logistic regression.

No pretrained weights, network calls, pickle loading, or automatic CDE designation.
The model predicts review relevance for a field in a described business use.
"""
from __future__ import annotations

# %% imports
import csv
import hashlib
import html
import json
import math
import re
from collections import Counter
from pathlib import Path

import numpy as np

SEED = 42
FEATURE_COLUMNS = ("field_name", "description", "business_use", "data_type")
LABEL_COLUMN = "candidate_label"

# %% data
# A scenario family contains BOTH labels. Aliases/paraphrases stay in one split.
# All outcomes below are authored synthetic teaching labels, not Citi decisions.
SCENARIOS = [
    ("statementBalance", "number",
     "Amount owed at statement close determines the debit collected by autopay.",
     "Example balance appears in a product tutorial and never feeds an account calculation."),
    ("paymentDueDate", "date",
     "Payment deadline determines whether a customer is charged a late fee.",
     "Date shown in a training calendar is illustrative and never drives a customer deadline."),
    ("minimumPayment", "number",
     "Required installment is used to decide whether the account becomes delinquent.",
     "A sample installment labels a design preview and is unrelated to actual obligations."),
    ("purchaseAPR", "number",
     "Annual purchase rate is applied to calculate interest billed to the account.",
     "An example rate in a help article demonstrates a formula without setting any account rate."),
    ("lateFeeAmount", "number",
     "Assessed fee is posted to the ledger and changes the amount the customer owes.",
     "An example fee in a mock statement exists only to illustrate the screen layout."),
    ("statementCurrency", "string",
     "Currency code determines the units used to settle the customer's payment.",
     "Currency symbol is a decorative legend on a sample chart and has no settlement role."),
    ("postedTransactionAmount", "number",
     "Booked transaction amount contributes to the authoritative statement balance.",
     "Random transaction amount is generated solely for an isolated software load test."),
    ("paymentStatus", "string",
     "Execution status controls whether a failed customer debit is retried.",
     "Status text drives only an animation in a prototype disconnected from payment processing."),
    ("paymentEffectiveDate", "date",
     "Effective receipt date determines interest accrual and whether a payment is late.",
     "A historical example date is used in documentation and never enters account servicing."),
    ("creditLimit", "number",
     "Approved limit determines whether a card authorization may be accepted.",
     "A demonstration limit fills a test screen and cannot approve a real transaction."),
    ("disputeCreditAmount", "number",
     "Provisional credit amount adjusts the customer ledger during dispute servicing.",
     "A fictional credit amount illustrates a support article without adjusting any account."),
    ("delinquencyDays", "integer",
     "Overdue day count determines collection treatment for a customer account.",
     "A counter in a synthetic training exercise demonstrates a collection screen."),
    ("accountToken", "string",
     "Account routing token selects the customer ledger that receives a payment posting.",
     "Placeholder token groups records inside a disposable visualization with no account linkage."),
    ("statementEmail", "string",
     "Destination address is the sole delivery route for the required billing notice in this synthetic scenario.",
     "Optional newsletter contact is not used for billing notices or account decisions."),
    ("balanceAsOfDate", "date",
     "Snapshot date identifies the authoritative balance period used for customer billing.",
     "Date caption identifies a marketing illustration rather than an account balance period."),
    ("creditAdjustment", "number",
     "Approved adjustment is booked to the ledger and changes the amount due.",
     "Sample adjustment is used in a sandbox demonstration and never posted to the ledger."),
    ("interestAccrued", "number",
     "Accrued interest amount is incorporated into the next customer statement.",
     "Example interest amount is displayed in a classroom exercise without a customer account."),
    ("paymentAllocation", "string",
     "Allocation order determines which customer balances are reduced by a received payment.",
     "Illustrative allocation order explains a workflow in a mock interface only."),
    ("availableCredit", "number",
     "Available credit is consumed by authorization decisions for customer purchases.",
     "A simulated available-credit figure animates a product tour and cannot authorize purchases."),
    ("returnedPaymentCode", "string",
     "Return reason decides whether servicing reverses a previously credited payment.",
     "A sample return code populates a developer documentation page only."),
    ("billingCycleId", "string",
     "Cycle identifier selects the actual transactions included in a customer statement.",
     "A cycle label names a presentation slide and is not used to select transactions."),
    ("autopayInstruction", "string",
     "Payment instruction chooses the amount and timing of the customer's scheduled debit.",
     "Text explaining an autopay option appears in an unconnected prototype."),
    ("principalOutstanding", "number",
     "Principal balance is reconciled to the ledger for actual payoff calculations.",
     "A fictional principal value demonstrates chart formatting with no payoff use."),
    ("refundDestination", "string",
     "Destination token routes an approved customer refund to the correct account.",
     "A fake destination label is used for design testing and cannot route funds."),
]

POSITIVE_USES = [
    "Customer billing execution; an incorrect value can change a financial outcome.",
    "Account servicing uses the value in a live payment or obligation workflow.",
    "The production consumer uses this field when determining customer treatment.",
    "The source feeds an operational calculation that changes a customer account.",
    "The field participates in an authoritative customer financial process.",
]
NEGATIVE_USES = [
    "Presentation or training only; no customer account action consumes the value.",
    "This field is confined to an isolated illustration, outside financial processing.",
    "Optional informational display; the operational consumer reads a separate source.",
    "Documentation and interface demonstration with no effect on customer treatment.",
    "The field is a non-authoritative example and does not feed a live account.",
]
WRAPPERS = [
    "{text}", "Business definition: {text}", "Field meaning: {text}",
    "{text} The producer documents this use.", "Consumer interpretation: {text}",
    "Project context: {text}", "{text} This describes the intended use.",
    "Data element definition: {text}", "Usage description: {text}",
    "{text} The design review records this interpretation.",
]

def snake_case(name):
    return re.sub(r"(?<=[a-z0-9])(?=[A-Z])", "_", name).lower()

def make_synthetic_data(seed=SEED):
    rng = np.random.default_rng(seed)
    rows = []
    for index, (name, dtype, positive, negative) in enumerate(SCENARIOS):
        family = f"FAMILY-{index + 1:02d}"
        aliases = [name, snake_case(name), snake_case(name).upper(),
                   "fld_" + "".join(word[0] for word in snake_case(name).split("_"))]
        for label, definition in [(1, positive), (0, negative)]:
            for variant in range(10):
                rows.append({
                    "record_id": f"SYN-{index + 1:02d}-{label}-{variant:02d}",
                    "application_id": f"SYN-APP-{index + 1:02d}",
                    "leakage_group": family,
                    "field_name": aliases[variant % len(aliases)],
                    "description": WRAPPERS[variant].format(text=definition),
                    "business_use": (POSITIVE_USES if label else NEGATIVE_USES)[variant % 5],
                    "data_type": dtype,
                    "candidate_label": label,
                    "review_status": "synthetic_authored_label",
                    "label_rationale": "Synthetic teaching assumption; not an official CDE designation.",
                    "data_origin": "synthetic",
                })
    rng.shuffle(rows)
    uncertain = [
        {"record_id": "AMB-01", "field_name": "x17", "description": "",
         "business_use": "", "data_type": "number"},
        {"record_id": "AMB-02", "field_name": "customerEmail",
         "description": "Customer contact.", "business_use": "", "data_type": "string"},
        {"record_id": "AMB-03", "field_name": "amount",
         "description": "Amount from upstream.", "business_use": "To be confirmed.", "data_type": "number"},
        {"record_id": "AMB-04", "field_name": "qzx_flux",
         "description": "Quasar telemetry encoding.", "business_use": "Astrophysical sensor fusion.", "data_type": "string"},
    ]
    return rows, uncertain

def write_csv(rows, path):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)

def read_reviewed_csv(path):
    """Real-data mode: use confirmed, scoped labels; unknown is never a negative."""
    with Path(path).open(newline="", encoding="utf-8") as handle:
        rows = list(csv.DictReader(handle))
    required = set(FEATURE_COLUMNS) | {
        "record_id", "application_id", "leakage_group", LABEL_COLUMN,
        "review_status", "data_origin",
    }
    if not rows or not required.issubset(rows[0]):
        raise ValueError("CSV is empty or missing required columns: " + str(sorted(required)))
    for row in rows:
        if row["review_status"] != "steward_confirmed":
            raise ValueError("Real-data training accepts steward_confirmed rows only. Exclude unresolved labels.")
        if row[LABEL_COLUMN] not in ("0", "1"):
            raise ValueError("Label must be 0 or 1; blanks and unknown labels are not negatives.")
        row[LABEL_COLUMN] = int(row[LABEL_COLUMN])
        if not row["application_id"].strip() or not row["leakage_group"].strip():
            raise ValueError("Application and leakage-group IDs must be populated.")
    return rows

# %% preprocessing
def tokenize(text):
    text = re.sub(r"(?<=[a-z0-9])(?=[A-Z])", " ", str(text))
    words = re.findall(r"[a-z][a-z0-9]+", text.lower().replace("_", " "))
    return words + [words[i] + "::" + words[i + 1] for i in range(len(words) - 1)]

def build_text(row):
    # Explicit allowlist: no CDE IDs, labels, reviewer rationales or application IDs.
    return " ".join(f"{key.replace('_', ' ')} {row.get(key, '') or ''}" for key in FEATURE_COLUMNS)

def group_split(rows, seed=SEED):
    """Whole leakage groups are assigned once. No label-based resampling."""
    groups = sorted({row["leakage_group"] for row in rows})
    if len(groups) < 10:
        raise ValueError("Use at least 10 independent groups for this illustrative three-way split.")
    rng = np.random.default_rng(seed)
    rng.shuffle(groups)
    n_train, n_val = int(len(groups) * .6), int(len(groups) * .2)
    assignments = {g: ("train" if i < n_train else "validation"
                      if i < n_train + n_val else "test") for i, g in enumerate(groups)}
    split = {name: [r for r in rows if assignments[r["leakage_group"]] == name]
             for name in ("train", "validation", "test")}
    for name, items in split.items():
        if {r[LABEL_COLUMN] for r in items} != {0, 1}:
            raise ValueError(f"{name} lacks a class. Redesign group allocation before modeling; do not peek at test performance.")
    for a, b in [("train", "validation"), ("train", "test"), ("validation", "test")]:
        assert not ({r["leakage_group"] for r in split[a]} & {r["leakage_group"] for r in split[b]})
        if {r["application_id"] for r in split[a]} & {r["application_id"] for r in split[b]}:
            raise ValueError("An application spans splits. Merge connected application/alias families into a single leakage_group.")
        texts_a = {tuple(tokenize(build_text(r))) for r in split[a]}
        texts_b = {tuple(tokenize(build_text(r))) for r in split[b]}
        if texts_a & texts_b:
            raise ValueError("Duplicate normalized feature text crosses splits. Merge duplicate families.")
    return split, assignments

class TfidfFromScratch:
    """Training-only vocabulary/IDF; word and word-pair features; L2-normalized rows."""
    def __init__(self, max_features=1400, min_df=2):
        self.max_features, self.min_df = max_features, min_df

    def fit(self, texts):
        counts = Counter()
        for text in texts:
            counts.update(set(tokenize(text)))
        selected = sorted(((token, n) for token, n in counts.items() if n >= self.min_df),
                          key=lambda pair: (-pair[1], pair[0]))[:self.max_features]
        if not selected:
            raise ValueError("No vocabulary; supply more descriptive training text.")
        self.vocabulary = {token: i for i, (token, _) in enumerate(selected)}
        self.idf = np.array([np.log((1 + len(texts)) / (1 + n)) + 1 for _, n in selected])
        return self

    def transform(self, texts):
        matrix = np.zeros((len(texts), len(self.vocabulary)), dtype=np.float64)
        for row_index, text in enumerate(texts):
            for token, count in Counter(tokenize(text)).items():
                col = self.vocabulary.get(token)
                if col is not None:
                    matrix[row_index, col] = (1 + np.log(count)) * self.idf[col]
        norms = np.linalg.norm(matrix, axis=1, keepdims=True)
        return matrix / np.where(norms == 0, 1, norms)

    def coverage(self, text):
        # Unigrams only, avoiding feature-pair inflation.
        terms = {t for t in tokenize(text) if "::" not in t}
        return sum(t in self.vocabulary for t in terms) / max(1, len(terms))

# %% learner
def sigmoid(z):
    # Clipping avoids exp overflow. Log-loss below uses logaddexp for stability.
    return 1 / (1 + np.exp(-np.clip(z, -40, 40)))

class LogisticRegressionFromScratch:
    def __init__(self, l2=.001, learning_rate=1.0, epochs=600):
        self.l2, self.learning_rate, self.epochs = l2, learning_rate, epochs

    def fit(self, x, y):
        y = np.asarray(y, dtype=np.float64)
        if len(x) != len(y) or set(y.tolist()) != {0., 1.}:
            raise ValueError("Training requires aligned rows and both binary classes.")
        self.weights = np.zeros(x.shape[1])
        self.bias = 0.0
        self.history = []
        for epoch in range(self.epochs):
            logits = x @ self.weights + self.bias
            error = sigmoid(logits) - y
            # Average cross-entropy plus L2 penalty; intercept is not penalized.
            grad_w = x.T @ error / len(y) + self.l2 * self.weights
            grad_b = error.mean()
            if epoch % 20 == 0 or epoch == self.epochs - 1:
                loss = np.mean(np.logaddexp(0, logits) - y * logits)
                loss += .5 * self.l2 * np.dot(self.weights, self.weights)
                self.history.append({"epoch": epoch, "loss": float(loss)})
            self.weights -= self.learning_rate * grad_w
            self.bias -= self.learning_rate * grad_b
        return self

    def predict_score(self, x):
        return sigmoid(x @ self.weights + self.bias)

# %% metrics
def binary_metrics(y, prediction):
    y, p = np.asarray(y, dtype=int), np.asarray(prediction, dtype=int)
    tp, fp = int(((y == 1) & (p == 1)).sum()), int(((y == 0) & (p == 1)).sum())
    fn, tn = int(((y == 1) & (p == 0)).sum()), int(((y == 0) & (p == 0)).sum())
    precision, recall = tp / max(1, tp + fp), tp / max(1, tp + fn)
    f2 = 5 * precision * recall / max(1e-12, 4 * precision + recall)
    return {"precision": precision, "recall": recall, "f2": f2,
            "accuracy": (tp + tn) / max(1, len(y)),
            "tp": tp, "fp": fp, "fn": fn, "tn": tn, "review_rate": (tp + fp) / max(1, len(y))}

def choose_threshold(y, scores, target_recall=.90):
    """Threshold selection uses validation only, with an explicit recall objective."""
    choices = sorted(set([0., 1.] + [float(s) for s in scores]))
    grid = [{"threshold": t, **binary_metrics(y, scores >= t)} for t in choices]
    feasible = [r for r in grid if r["recall"] >= target_recall]
    # All-positive threshold is feasible but may have poor precision; report both.
    selected = max(feasible, key=lambda r: (r["precision"], r["f2"], r["threshold"]))
    return selected, grid

def keyword_baseline(rows):
    pattern = re.compile(r"balance|due|payment|credit|apr|interest|delinquen|fee|principal", re.I)
    return np.array([int(bool(pattern.search(r["field_name"]))) for r in rows])

def train_candidates(train, validation):
    texts_train, texts_val = [build_text(r) for r in train], [build_text(r) for r in validation]
    vectorizer = TfidfFromScratch().fit(texts_train)
    x_train, x_val = vectorizer.transform(texts_train), vectorizer.transform(texts_val)
    y_train = np.array([r[LABEL_COLUMN] for r in train])
    y_val = np.array([r[LABEL_COLUMN] for r in validation])
    trials = []
    for regularization in (.0001, .001, .01):
        model = LogisticRegressionFromScratch(l2=regularization).fit(x_train, y_train)
        selected, curve = choose_threshold(y_val, model.predict_score(x_val))
        trials.append({"model": model, "selection": selected, "curve": curve, "l2": regularization})
    best = max(trials, key=lambda t: (t["selection"]["precision"], t["selection"]["f2"], t["l2"]))
    return vectorizer, best, trials

# %% inference
def classify_records(rows, vectorizer, model, high_threshold, low_threshold=None):
    """Ranking/triage only. Low priority does not mean non-CDE or policy approval."""
    low_threshold = min(.25, high_threshold * .5) if low_threshold is None else low_threshold
    scores = model.predict_score(vectorizer.transform([build_text(r) for r in rows]))
    result = []
    for row, score in zip(rows, scores):
        # Exclude ubiquitous column-name markers from the coverage gate.
        evidence_text = " ".join(str(row.get(k, "") or "") for k in FEATURE_COLUMNS)
        coverage = vectorizer.coverage(evidence_text)
        missing = any(not str(row.get(k, "") or "").strip() for k in ("description", "business_use"))
        if missing or coverage < .25:
            recommendation = "MORE_CONTEXT_REQUIRED"
        elif score >= high_threshold:
            recommendation = "PRIORITIZE_CDE_REVIEW"
        elif score >= low_threshold:
            recommendation = "MANUAL_REVIEW"
        else:
            recommendation = "LOWER_REVIEW_PRIORITY"
        result.append({
            "record_id": row.get("record_id"), "field_name": row.get("field_name", ""),
            "candidate_score": float(score), "known_term_coverage": coverage,
            "recommendation": recommendation, "requires_steward_verification": True,
            "official_cde_status": "NOT_DETERMINED_BY_MODEL",
        })
    return result

def explain_prediction(row, vectorizer, model, top_n=6):
    """Linear feature contributions, not causal reasons or policy citations."""
    vector = vectorizer.transform([build_text(row)])[0]
    terms = {i: term for term, i in vectorizer.vocabulary.items()}
    contributions = [(terms[i], float(vector[i] * model.weights[i]))
                     for i in np.flatnonzero(vector)]
    return {
        "toward_candidate": sorted([x for x in contributions if x[1] > 0],
                                  key=lambda x: -x[1])[:top_n],
        "away_from_candidate": sorted([x for x in contributions if x[1] < 0],
                                     key=lambda x: x[1])[:top_n],
        "bias": float(model.bias),
        "logit": float(vector @ model.weights + model.bias),
    }

# %% persistence
def model_payload(vectorizer, model, threshold, metadata):
    return {
        "format": "northstar_tfidf_logistic_v1", "format_version": 1,
        "feature_columns": list(FEATURE_COLUMNS),
        "tokenizer": "camel_case_words_plus_bigrams_v1",
        "vocabulary": vectorizer.vocabulary, "idf": vectorizer.idf.tolist(),
        "weights": model.weights.tolist(), "bias": float(model.bias),
        "high_threshold": float(threshold), "low_threshold": min(.25, float(threshold) * .5),
        "metadata": metadata,
    }

def save_model(path, vectorizer, model, threshold, metadata):
    path = Path(path)
    payload = model_payload(vectorizer, model, threshold, metadata)
    encoded = json.dumps(payload, indent=2, allow_nan=False)
    path.write_text(encoded, encoding="utf-8")
    return hashlib.sha256(encoded.encode()).hexdigest()

def load_model(path):
    """Load data-only JSON. No serialized Python objects or executable code."""
    path = Path(path)
    if path.stat().st_size > 10_000_000:
        raise ValueError("Model exceeds this teaching implementation's 10 MB limit.")
    payload = json.loads(path.read_text(encoding="utf-8"))
    if (payload.get("format") != "northstar_tfidf_logistic_v1"
            or payload.get("format_version") != 1
            or payload.get("tokenizer") != "camel_case_words_plus_bigrams_v1"
            or payload.get("feature_columns") != list(FEATURE_COLUMNS)):
        raise ValueError("Unsupported model format or feature schema.")
    vocab = payload["vocabulary"]
    if not vocab or len(vocab) > 10000 or sorted(vocab.values()) != list(range(len(vocab))):
        raise ValueError("Vocabulary indices must be contiguous and unique.")
    if not all(isinstance(k, str) for k in vocab):
        raise ValueError("Invalid vocabulary.")
    vec = TfidfFromScratch()
    vec.vocabulary = vocab
    vec.idf = np.asarray(payload["idf"], dtype=np.float64)
    model = LogisticRegressionFromScratch()
    model.weights = np.asarray(payload["weights"], dtype=np.float64)
    model.bias = float(payload["bias"])
    if vec.idf.shape != (len(vocab),) or model.weights.shape != vec.idf.shape:
        raise ValueError("Feature/weight dimensions disagree.")
    if not np.isfinite(vec.idf).all() or not (vec.idf > 0).all() or not np.isfinite(model.weights).all() or not math.isfinite(model.bias):
        raise ValueError("Invalid numeric parameters.")
    if not 0 <= payload["low_threshold"] <= payload["high_threshold"] <= 1:
        raise ValueError("Invalid thresholds.")
    return vec, model, payload

def score_csv(model_path, input_path, output_path):
    vec, model, payload = load_model(model_path)
    with Path(input_path).open(newline="", encoding="utf-8") as handle:
        rows = list(csv.DictReader(handle))
    if not rows or "field_name" not in rows[0]:
        raise ValueError("Input CSV needs at least field_name; description and business_use are needed for meaningful triage.")
    results = classify_records(rows, vec, model, payload["high_threshold"], payload["low_threshold"])
    write_csv(results, output_path)
    return results
