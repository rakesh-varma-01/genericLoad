# Train and use a CDE candidate model

Start with **train_cde_candidate_from_scratch.ipynb**. It is an executed notebook with explanations, training code, results, a loss chart, errors, predictions, feature contributions and saved artifacts.

## What is actually trained?

A binary logistic-regression classifier learns weights from labeled field metadata. The tokenizer and TF-IDF feature builder are implemented directly, and NumPy performs gradient descent. This is real training from zero weights; there is no pretrained model or LLM call.

The task is **prioritizing CDE review for a field in its business use**. It does not classify a whole application officially, validate Citi policies, or approve a release.

The 480 labeled examples are synthetic and generated from 24 scenario families. They contain repeated language, making the exercise easier than real governance classification.

## Run the notebook

Use Python 3.10 or newer. Work inside an approved environment.

    python -m venv .venv

Activate the environment:

- Windows PowerShell: .venv\Scripts\Activate.ps1
- macOS/Linux shell: source .venv/bin/activate

Then, from this kit folder:

    python -m pip install -r requirements.txt
    python -m jupyter notebook

Open the notebook and select **Restart Kernel and Run All Cells**. It contains all model code and can run without importing cde_ml.py.

If your workplace already provides Jupyter and NumPy, use that environment. No GPU or API key is needed. Installation may require your approved package mirror.

Outputs are written to artifacts/synthetic-v1/. Re-running replaces generated files in that named experiment directory. Change RUN_NAME to preserve prior runs.

## Follow the learning sequence

| Notebook section | What you learn |
|---|---|
| Labels and synthetic data | Label a field/use, distinguish unknown from negative |
| Splitting | Keep related applications and aliases together |
| TF-IDF | Learn a numeric representation from training text only |
| Logistic regression | Learn weights using cross-entropy and gradient descent |
| Validation | Select regularization and a review threshold |
| Holdout evaluation | Compare keyword rules and the trained model |
| Prediction and explanation | Score new metadata and inspect feature contributions |
| Save/reload | Reuse learned parameters without retraining |
| Feedback and real data | Replace teaching labels with authorized steward-reviewed examples |
| Integration | Place recommendations beside inventory and policy checks |

## Results from the included run

The split contains **280 training rows / 80 validation rows / 120 test rows**, from **14 / 4 / 6 independent scenario families**.

| Method | Candidate precision | Candidate recall | False positives | Missed candidates at high-priority threshold |
|---|---:|---:|---:|---:|
| Field-name keyword baseline | 50.0% | 53.3% | 32 | 28 |
| Learned model | 100.0% | 88.3% | 0 | 7 |

These are **synthetic teaching results**, not estimates of Citi performance. Repeated writing templates and a balanced label distribution make the exercise favorable. The 120 rows are not 120 independent business contexts.

The validation recall objective was 90%; the test recall was below it. We retained that result instead of retuning on test data. The seven missed high-priority cases need review; a low model score must not produce an automatic “No CDE” outcome.

The best configuration selected L2=0.01 and a high-priority threshold of approximately 0.6964. Thresholds and probabilities are not calibrated for real data. A lower illustrative threshold separates manual review from lower review priority.

## Use the saved model without training again

The included model is:

    artifacts/synthetic-v1/cde_candidate_model.json

Prepare a CSV like data/new_project_fields.csv. Each row needs:

| Column | Example | Purpose |
|---|---|---|
| record_id | API-001 | Trace the recommendation to a source record |
| field_name | stmt_amt | Technical name |
| description | Amount owed at statement close | Business definition |
| business_use | Determines the debit collected by autopay | Field-specific consequence |
| data_type | number | Technical type |

Run:

    python score_fields.py --model artifacts/synthetic-v1/cde_candidate_model.json --input data/new_project_fields.csv --output predictions.csv

This loads the trained vocabulary, IDF values, weights and threshold. It scores records and writes a CSV. It does **not** retrain or update a catalog.

Outputs include candidate_score, known_term_coverage, recommendation, requires_steward_verification and official_cde_status.

| Recommendation | Use |
|---|---|
| PRIORITIZE_CDE_REVIEW | Review early |
| MANUAL_REVIEW | Ambiguous learned score |
| LOWER_REVIEW_PRIORITY | Low learned signal; still not proof of non-criticality |
| MORE_CONTEXT_REQUIRED | Missing or unfamiliar description/use |

Scores are ranking signals. “0.80” does not mean an 80% probability that Citi considers a field an official CDE.

## Use from Python

The same functions are available in cde_ml.py:

    from cde_ml import load_model, classify_records

    vectorizer, model, bundle = load_model(
        "artifacts/synthetic-v1/cde_candidate_model.json"
    )
    fields = [{
        "record_id": "API-001",
        "field_name": "stmt_amt",
        "description": "Amount owed at statement close.",
        "business_use": "Determines the customer's scheduled autopay debit.",
        "data_type": "number"
    }]
    recommendations = classify_records(
        fields, vectorizer, model,
        bundle["high_threshold"], bundle["low_threshold"]
    )
    print(recommendations)

For a service, load the model once at startup and reuse it for batches. No endpoint is deployed by this kit.

## When it belongs in Radar

Use it at project intake or during API/schema design, before development is finalized. It can also support advisory pull-request feedback and governance-backlog triage.

Recommended flow:

1. Extract field paths, descriptions, types and field-specific uses from project artifacts.
2. Match existing approved application CDE inventory separately.
3. Score new or ambiguous fields using this model.
4. Retrieve applicable versioned policy requirements.
5. Check ownership, lineage, source and quality evidence deterministically.
6. Send the evidence and model recommendation to the steward.
7. Record the official decision in the authorized workflow.

An existing verified CDE approval must not be downgraded because this model returns a low score. Policy applicability is not learned from this synthetic classifier.

The Governance Studio HTML is **not automatically connected** to this model. For a hackathon you can run predictions in the notebook and show the CSV next to the showcase. A later approved internal backend could return predictions to the web UI.

## Repurpose with your real metadata

Begin with data/reviewed_data_template.csv and retain these fields:

- record_id, application_id and leakage_group for traceability and split control;
- field_name, description, business_use and data_type as model inputs;
- candidate_label (0 or 1) and review_status=steward_confirmed;
- data_origin, rationale, reviewer, date and policy reference as audit metadata.

The loader rejects pending or unresolved labels. Existing untagged fields are **not** automatically negative. Negatives need a reviewed rationale for that business use.

Do not copy a blanket application purpose into every field. A cosmetic label and a payment amount can be in the same API with different consequences. Capture field-level usage where possible.

Before training:

1. Validate field-to-inventory mappings and effective approval scope.
2. Include difficult negatives: sensitive-only fields, simulations, derived copies and optional display data.
3. Separate uncertain cases for review.
4. Merge connected applications, copied schemas and alias families into leakage groups.
5. Reserve an independent real-data test set.
6. Fit the text representation only on training data.
7. Select model and threshold using validation data.
8. Evaluate once, report precision/recall and missed known CDEs, then seek pilot approval.

The notebook includes the three lines that switch to a reviewed CSV. Real-data training has not been run here.

Do not silently blend synthetic and real evaluation results. Real labels, vocabulary, prevalence, regions and business contexts can differ substantially. Consider time-based evaluation and review subgroup performance.

## Feedback, retraining and versioning

Use artifacts/synthetic-v1/steward_feedback_queue.csv to collect labels. The example queue leaves them blank.

Retrain a new version after accumulating reviewed cases, introducing a new business domain, changing the field/usage taxonomy, or observing monitored performance deterioration. Version the training data, model, tokenizer, threshold, metadata schema and label guidance together.

If development decisions were informed by the old test results, use a fresh holdout for a formal new-version evaluation. Do not repeatedly optimize against the same test examples.

For a first real pilot, assess retrieval quality and review workload in shadow mode. Consider calibrated scores only after sufficient independent data is available.

## Scope and technical limitations

- Dense NumPy features are intended for small educational datasets, not enterprise-scale training.
- TF-IDF can miss synonyms, negation and unfamiliar domains. Explanations are feature associations, not causal or policy reasoning.
- The coverage gate is basic and does not reliably detect every out-of-domain input.
- Historical approved inventory is a useful source of scoped labels, not automatically a complete ground-truth dataset.
- The model JSON contains learned vocabulary. After internal retraining, handle it according to the sensitivity of your metadata.
- JSON packaging avoids loading executable serialized Python objects. It still needs your normal artifact review and access controls.
- No real customer data, internal Citi policy, pretrained model or external service was used.

## Files

- train_cde_candidate_from_scratch.ipynb — self-contained executed tutorial.
- cde_ml.py — reusable model, training and inference functions.
- score_fields.py — command-line batch inference.
- requirements.txt — NumPy plus the Jupyter interface.
- data/ — training examples, input examples and a real-data template.
- artifacts/synthetic-v1/ — model, model card, evaluation, split manifest, predictions and feedback queue.
- tests/test_model.py — numerical, split, persistence and inference checks.

## Verification and references

All 20 notebook code cells were executed sequentially with Python 3.12.14 and NumPy 2.3.5. Tables and the loss chart are saved as notebook outputs. Saved-model prediction parity and command-line inference were checked, and 14 behavioral/numerical tests passed. This environment did not provide a Jupyter server, so the Jupyter UI itself was not exercised.

To run the included checks from this folder:

    python -m unittest discover -s tests -v

Useful primary references:

- [Data leakage and preprocessing pitfalls](https://scikit-learn.org/stable/common_pitfalls.html).
- [Grouped evaluation](https://scikit-learn.org/stable/modules/cross_validation.html).
- [TF-IDF](https://scikit-learn.org/stable/modules/generated/sklearn.feature_extraction.text.TfidfVectorizer.html).
- [Logistic regression](https://scikit-learn.org/stable/modules/linear_model.html#logistic-regression).
- [Model persistence](https://scikit-learn.org/stable/model_persistence.html).
