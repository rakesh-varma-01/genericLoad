"""Score field metadata with the saved JSON model; never updates a CDE registry."""
import argparse
from collections import Counter
from pathlib import Path

from cde_ml import score_csv


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--model", required=True, help="Path to cde_candidate_model.json")
    parser.add_argument("--input", required=True, help="CSV with field_name, description, business_use, data_type")
    parser.add_argument("--output", required=True, help="Destination predictions CSV")
    args = parser.parse_args()
    if Path(args.output).resolve() in {Path(args.input).resolve(), Path(args.model).resolve()}:
        parser.error("Output must differ from the input and model paths.")
    results = score_csv(args.model, args.input, args.output)
    print(f"Scored {len(results)} field/use records → {args.output}")
    print(dict(Counter(r["recommendation"] for r in results)))
    print("Review recommendations only. Official CDE status remains undetermined by this model.")


if __name__ == "__main__":
    main()
