import json
import sys
import tempfile
import unittest
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import cde_ml as m


class ModelTests(unittest.TestCase):
    def test_reproducible_data_and_both_context_labels(self):
        rows, unknown = m.make_synthetic_data()
        self.assertEqual(rows, m.make_synthetic_data()[0])
        self.assertEqual(len(rows), 480)
        self.assertEqual({r[m.LABEL_COLUMN] for r in rows if r["field_name"] == "statementBalance"}, {0, 1})
        self.assertTrue(all(m.LABEL_COLUMN not in r for r in unknown))

    def test_split_group_and_application_separation(self):
        rows, _ = m.make_synthetic_data()
        parts, _ = m.group_split(rows)
        self.assertEqual([len(parts[k]) for k in ["train", "validation", "test"]], [280, 80, 120])
        for a, b in [("train", "test"), ("train", "validation"), ("validation", "test")]:
            for column in ("application_id", "leakage_group"):
                self.assertFalse({r[column] for r in parts[a]} & {r[column] for r in parts[b]})

    def test_cross_split_application_is_rejected(self):
        rows, _ = m.make_synthetic_data()
        for row in rows:
            row["application_id"] = "same-app"
        with self.assertRaises(ValueError):
            m.group_split(rows)

    def test_feature_allowlist_excludes_label_and_approval(self):
        row = {"field_name": "amount", "description": "amount owed", "business_use": "billing",
               "data_type": "number", "candidate_label": "FORBIDDEN_LABEL",
               "label_rationale": "FORBIDDEN_RATIONALE", "application_id": "FORBIDDEN_APP",
               "cde_id": "FORBIDDEN_CDE"}
        self.assertNotIn("FORBIDDEN", m.build_text(row))

    def test_normalizes_camel_and_snake_case(self):
        self.assertEqual(m.tokenize("statementBalance"), m.tokenize("statement_balance"))

    def test_tfidf_formula_and_unit_length(self):
        vec = m.TfidfFromScratch(min_df=1).fit(["cat cat dog", "dog bird"])
        self.assertAlmostEqual(vec.idf[vec.vocabulary["dog"]], 1)
        self.assertAlmostEqual(vec.idf[vec.vocabulary["cat"]], np.log(3/2)+1)
        x = vec.transform(["cat cat dog", "newunseen"])
        self.assertAlmostEqual(np.linalg.norm(x[0]), 1)
        self.assertAlmostEqual(np.linalg.norm(x[1]), 0)
        self.assertNotIn("newunseen", vec.vocabulary)

    def test_first_gradient_step_matches_finite_difference(self):
        x = np.array([[.2, .5], [.7, .1], [.1, .9]])
        y = np.array([0., 1., 0.])
        eps, lr, l2 = 1e-6, .1, .01
        def loss(w, b):
            z = x @ w + b
            return np.mean(np.logaddexp(0, z) - y*z) + .5*l2*(w@w)
        numeric = []
        for index in range(2):
            w = np.zeros(2); w[index] = eps
            numeric.append((loss(w, 0)-loss(-w, 0))/(2*eps))
        bias_gradient = (loss(np.zeros(2), eps)-loss(np.zeros(2), -eps))/(2*eps)
        model = m.LogisticRegressionFromScratch(l2=l2, learning_rate=lr, epochs=1).fit(x, y)
        np.testing.assert_allclose(model.weights, -lr*np.array(numeric), atol=1e-9)
        self.assertAlmostEqual(model.bias, -lr*bias_gradient)

    def test_training_learns_a_separable_toy_problem(self):
        x = np.array([[1., 0.], [0., 1.], [1., 0.], [0., 1.]])
        model = m.LogisticRegressionFromScratch(l2=.001, epochs=100).fit(x, [1, 0, 1, 0])
        self.assertLess(model.history[-1]["loss"], model.history[0]["loss"])
        self.assertGreater(model.predict_score(x)[0], .8)
        self.assertLess(model.predict_score(x)[1], .2)

    def test_metric_counts_are_correct(self):
        metrics = m.binary_metrics([1, 1, 0, 0], [1, 0, 1, 0])
        self.assertEqual([metrics[k] for k in ("tp", "fp", "fn", "tn")], [1, 1, 1, 1])
        self.assertEqual(metrics["precision"], .5)
        self.assertEqual(metrics["recall"], .5)

    def test_validation_threshold_meets_requested_recall(self):
        selected, _ = m.choose_threshold(np.array([1, 1, 0, 0]), np.array([.9, .7, .8, .1]), .9)
        self.assertGreaterEqual(selected["recall"], .9)
        self.assertAlmostEqual(selected["threshold"], .7)

    def test_saved_model_roundtrip_and_missing_context(self):
        vec, model, payload = m.load_model(ROOT / "artifacts/synthetic-v1/cde_candidate_model.json")
        rows = [{"field_name": "statementBalance", "description": "", "business_use": "", "data_type": "number"}]
        result = m.classify_records(rows, vec, model, payload["high_threshold"])
        self.assertEqual(result[0]["recommendation"], "MORE_CONTEXT_REQUIRED")
        self.assertEqual(result[0]["official_cde_status"], "NOT_DETERMINED_BY_MODEL")
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "model.json"
            m.save_model(path, vec, model, payload["high_threshold"], {})
            v2, m2, _ = m.load_model(path)
            np.testing.assert_allclose(model.predict_score(vec.transform(["autopay balance"])),
                                       m2.predict_score(v2.transform(["autopay balance"])), atol=1e-12)

    def test_unfamiliar_vocabulary_requests_context(self):
        vec, model, payload = m.load_model(ROOT / "artifacts/synthetic-v1/cde_candidate_model.json")
        rows = [{"field_name": "qzx_flux", "description": "Quasar telemetry encoding",
                 "business_use": "Astrophysical sensor fusion", "data_type": "qzx"}]
        result = m.classify_records(rows, vec, model, payload["high_threshold"])
        self.assertEqual(result[0]["recommendation"], "MORE_CONTEXT_REQUIRED")

    def test_persistence_rejects_wrong_tokenizer_and_dimensions(self):
        original = json.loads((ROOT / "artifacts/synthetic-v1/cde_candidate_model.json").read_text())
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "bad.json"
            bad = {**original, "tokenizer": "different"}
            path.write_text(json.dumps(bad))
            with self.assertRaises(ValueError):
                m.load_model(path)
            bad = {**original, "weights": [1.]}
            path.write_text(json.dumps(bad))
            with self.assertRaises(ValueError):
                m.load_model(path)

    def test_pending_real_labels_cannot_be_training_negatives(self):
        with self.assertRaises(ValueError):
            m.read_reviewed_csv(ROOT / "data/reviewed_data_template.csv")


if __name__ == "__main__":
    unittest.main(verbosity=2)
