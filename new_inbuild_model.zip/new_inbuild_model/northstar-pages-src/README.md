# Northstar pages — sources

Sources for the three standalone pages in the parent folder:

- `northstar_cde_radar_assurance.html`
- `northstar_ml_candidate_model.html`
- `northstar_data_purpose_gate.html`

Each page is one self-contained HTML file that works offline. Edit the sources here, then rebuild:

```bash
node northstar-pages-src/build.cjs
```

| Path | What it is |
|---|---|
| `engine/core.js` | Shared engine: rules, inventory mapping, clause evaluator, contract, purpose gate, ML training/inference code, self-checks |
| `engine/parsers.js` | `extractFields()`: JSON/OpenAPI (via `extractFieldsBase` in core), a YAML subset parser, and SQL `CREATE TABLE` / `SELECT`; plus the YAML and SQL samples |
| `engine/checks.js` | Extra self-checks (Parsing, Pretrained), hooked into `runSelfChecks()` |
| `styles.css` | Shared styles, light and dark |
| `pages/common.js` | Shared shell: navigation, toasts, downloads, modal, presenter timer, self-check view, guided demo |
| `pages/<page>.body.html` + `pages/<page>.js` | Each page's markup and behaviour |
| `build.cjs` | Assembles the pages |

At build time, `build.cjs` embeds the offline-trained model from `../northstar-ml-candidate-model/artifacts/generated_model.json` as `PRETRAINED_MODEL`.

The Radar page runs only inference with that model. To ship a new model:

1. Retrain it in the repo.
2. Run `node northstar-pages-src/build.cjs` again.

Or import the new model's JSON on the Radar page's **Pre-trained model** tab.

`northstar_design_to_reuse.html` (the combined journey) was built earlier from a different source set and is not rebuilt by this script.
