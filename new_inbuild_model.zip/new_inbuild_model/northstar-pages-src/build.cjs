// Builds the three standalone Northstar MVP pages into the parent folder.
//   node northstar-pages-src/build.cjs            (run from anywhere)
// Inputs: engine/*.js, styles.css, pages/*, and the offline-trained model from
// ../northstar-ml-candidate-model/artifacts/generated_model.json (embedded as PRETRAINED_MODEL).
const fs = require('fs'), path = require('path');
const here = __dirname, outDir = path.resolve(here, '..');
const read = f => fs.readFileSync(path.join(here, f), 'utf8');
const modelPath = path.resolve(here, '..', 'northstar-ml-candidate-model', 'artifacts', 'generated_model.json');

const m = JSON.parse(fs.readFileSync(modelPath, 'utf8'));
if (m.format !== 'northstar-cde-candidate-model' || m.tokenizer !== 'v1') throw new Error('unexpected model file: ' + modelPath);
const pretrained = `/* Offline-trained model, embedded at build time from northstar-ml-candidate-model/artifacts/generated_model.json. */
const PRETRAINED_MODEL=${JSON.stringify({
  name: 'generated_model.json', version: '0.1.0', bias: m.bias, weights: m.weights, threshold: m.threshold,
  examples: m.training.examples, source: m.training.source, hyperparameters: m.hyperparameters,
  metrics: m.metrics, notes: m.notes, intended_use: m.intended_use, never_used_for: m.never_used_for })};
`;
const engine = ['engine/core.js', 'engine/parsers.js', 'engine/checks.js'].map(read).join('\n') + '\n' + pretrained;
const css = read('styles.css'), common = read('pages/common.js');

const PAGES = [
  { key: 'radar', file: 'northstar_cde_radar_assurance.html', short: 'CDE Radar + Assurance', title: 'CDE Radar Assurance', logo: 'R', sub: 'Find and prove critical data',
    desc: 'CDE Radar + Assurance: upload a JSON, OpenAPI, YAML or SQL spec and get a CDE determination from rules, the application inventory and a pre-trained model, then prove readiness clause by clause. Offline, synthetic MVP demo.' },
  { key: 'ml', file: 'northstar_ml_candidate_model.html', short: 'ML Candidate Model', title: 'ML Candidate Model', logo: 'ML', sub: 'Catch what the rules miss',
    desc: 'ML Candidate Model: an explainable model trained on steward-labelled fields that adds missed CDE candidates to the review list and learns from steward decisions. Offline, synthetic MVP demo.' },
  { key: 'gate', file: 'northstar_data_purpose_gate.html', short: 'Data Purpose Gate', title: 'Data Purpose Gate', logo: 'PG', sub: 'Govern the reuse of critical data',
    desc: "Data Purpose Gate: checks a data reuse request against the approved use profile, the fields' readiness and pending steward decisions; minimises, holds, blocks or routes. Offline, synthetic MVP demo." }];
const siblings = cur => PAGES.map(p => `<a href="${p.file}"${p.key === cur ? ' aria-current="page"' : ''}>${p.short}</a>`).join('') + '<a href="northstar_design_to_reuse.html">Combined journey</a>';

for (const p of PAGES) {
  const html = `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>${p.title}</title>
<meta name="description" content="${p.desc}">
<style>${css}</style>
</head>
<body>
<div class="app">
  <aside class="side" aria-label="Sections">
    <div class="brand"><div class="logo">${p.logo}</div><div><b>${p.short}</b><small>Northstar · ${p.sub}</small></div></div>
    <nav id="sideNav"></nav>
    <div class="side-foot">Part of <b>Northstar</b>: Find → Prove → Govern use. All applications, IDs, policies, profiles and metrics are <b>synthetic</b>. Runs offline.</div>
  </aside>
  <main class="main">
    <header class="top">
      <div class="crumb"><span>NORTHSTAR</span><span>/</span><strong id="crumb"></strong><span class="chip warn">Synthetic demo</span></div>
      <div class="top-actions"><nav class="siblings" aria-label="Northstar pages">${siblings(p.key)}</nav>
        <button class="btn ghost sm" id="themeBtn" aria-label="Toggle colour theme">◐</button>
        <button class="btn primary sm" onclick="startDemo()">▶ Guided demo</button></div>
    </header>
    <div class="mnav" id="mobileNav"></div>
    <div class="content">
${read('pages/' + p.key + '.body.html')}
    </div>
  </main>
</div>
<div class="modal" id="modal" role="dialog" aria-modal="true" aria-labelledby="modalTitle"><div class="modal-box"><div class="row between"><div><div class="eyebrow" id="modalEye"></div><h2 id="modalTitle" style="margin-top:6px"></h2></div><button class="btn sm" onclick="closeModal()" aria-label="Close">✕</button></div><div id="modalBody" class="mt"></div></div></div>
<div class="toast" id="toast" role="status" aria-live="polite"></div>
<div class="demo-bar hidden" id="demoBar" role="region" aria-label="Guided walkthrough"><div><span class="pill-num" id="demoNum"></span> <b id="demoTitle"></b><p id="demoText"></p></div><div class="row"><button class="btn sm" onclick="stepDemo(-1)">Back</button><button class="btn sm primary" onclick="stepDemo(1)">Next</button><button class="btn sm ghost" onclick="$('demoBar').classList.add('hidden')">Exit</button></div></div>
<script id="engine">
${engine}</script>
<script>
${common}
${read('pages/' + p.key + '.js')}</script>
</body>
</html>
`;
  fs.writeFileSync(path.join(outDir, p.file), html);
  console.log('wrote', p.file, (html.length / 1024).toFixed(0) + ' KB');
}
