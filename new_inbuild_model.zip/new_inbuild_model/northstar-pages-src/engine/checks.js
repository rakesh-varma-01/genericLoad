/* Self-checks for the parsers and the embedded pre-trained model; called from runSelfChecks(). */
function extraSelfChecks(t){
 const v25=scenario('extended').input,ctx=()=>clone(CONTEXT);
 const names=r=>r.fields.map(f=>f.field).join();
 t('Parsing','YAML OpenAPI parses to the same 9 fields as the JSON spec',()=>names(extractFields(SAMPLE_YAML))===names(extractFields(v25))&&extractFields(SAMPLE_YAML).fields.length===9);
 t('Parsing','YAML keeps descriptions, types and $ref resolution',()=>{const f=extractFields(SAMPLE_YAML).fields.find(x=>x.field==='paymentDueDate');return f.path==='Statement.paymentDueDate'&&f.type==='string'&&/delinquency/.test(f.description)});
 t('Parsing','YAML and JSON give the same determination',()=>{const P=PRETRAINED_MODEL,a=runPipeline(SAMPLE_YAML,ctx(),P,P.threshold),b=runPipeline(v25,ctx(),P,P.threshold);return a.verdict===b.verdict&&a.findings.map(f=>f.field+f.status+f.mlSuggested).join()===b.findings.map(f=>f.field+f.status+f.mlSuggested).join()});
 t('Parsing','SQL CREATE TABLE yields 8 columns with their -- comments',()=>{const r=extractFields(SAMPLE_SQL);return r.fields.length===8&&r.mode.startsWith('SQL')&&r.fields.find(f=>f.field==='credit_limit').description==='Approved credit line used in utilization and authorization'});
 t('Parsing','SQL COMMENT clause, COMMENT ON COLUMN and SELECT aliases',()=>{const r=extractFields("CREATE TABLE t (a_amt NUMERIC(10,2) COMMENT 'Amount owed, in USD', b INT);\nCOMMENT ON COLUMN t.b IS 'Days past due';\nSELECT x.fee_amount AS late_fee, y.cnt -- number of logins\nFROM x");const g=n=>r.fields.find(f=>f.field===n);return g('a_amt').description==='Amount owed, in USD'&&g('b').description==='Days past due'&&!!g('late_fee')&&g('cnt').description==='number of logins'});
 t('Parsing','Plain “field - description” text still works',()=>extractFields('paymentDueDate - payment deadline for delinquency').fields[0].field==='paymentDueDate');
 const P=PRETRAINED_MODEL;
 t('Pretrained','Embedded model is the offline generated_model (356 features)',()=>Object.keys(P.weights).length===356&&P.threshold>0.6&&P.threshold<0.7&&P.examples===857);
 t('Pretrained','On v2.5 it suggests exactly creditLimit and aprPercent',()=>runPipeline(v25,ctx(),P,P.threshold).findings.filter(f=>f.mlSuggested).map(f=>f.field).sort().join()==='aprPercent,creditLimit');
 t('Pretrained','On the SQL table it suggests credit_limit and apr_percent',()=>runPipeline(SAMPLE_SQL,ctx(),P,P.threshold).findings.filter(f=>f.mlSuggested).map(f=>f.field).sort().join()==='apr_percent,credit_limit');
 t('Pretrained','Verdict is identical with and without the model',()=>[v25,SAMPLE_YAML,SAMPLE_SQL].every(s=>runPipeline(s,ctx(),P,P.threshold).verdict===runPipeline(s,ctx(),null,P.threshold).verdict));
 t('Pretrained','Scores match the repo’s Python model (creditLimit 0.76, aprPercent 0.95)',()=>Math.abs(predict(P,'creditLimit','Approved credit line used in utilization and authorization').p-0.76)<0.01&&Math.abs(predict(P,'aprPercent','Annual percentage rate applied to purchases').p-0.95)<0.01);
}
