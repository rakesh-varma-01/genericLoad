/* All fixtures, policies, IDs and thresholds are synthetic. Shared with cde_idea.html; see build notes. */
const FIXTURE_DATE='2026-10-21';
const clone=o=>JSON.parse(JSON.stringify(o));
const norm=v=>String(v).replace(/[^a-z0-9]/gi,'').toLowerCase();
const esc=v=>String(v==null?'':v).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function isISODate(v){return typeof v==='string'&&/^\d{4}-\d{2}-\d{2}$/.test(v)&&Number.isFinite(Date.parse(v))&&new Date(v).toISOString().slice(0,10)===v}
function daysBetween(a,b){return (Date.parse(a)-Date.parse(b))/86400000}

const OPENAPI={openapi:'3.0.3',info:{title:'Northstar Card Billing',version:'2.4.0'},
 paths:{'/statements':{get:{responses:{'200':{description:'Synthetic statement',content:{'application/json':{schema:{$ref:'#/components/schemas/Statement'}}}}}}}},
 components:{schemas:{Statement:{type:'object',required:['statementBalance','paymentDueDate'],properties:{
  statementBalance:{type:'number',description:'USD amount owed at statement close; authoritative input to autopay.',example:1250.75},
  paymentDueDate:{type:'string',format:'date',description:'Payment deadline drives late fee and delinquency decisions.',example:'2026-11-12'},
  customerEmail:{type:'string',format:'email',description:'Optional servicing contact; use for reminder notices only.',example:'alex@example.test'},
  rewardsNickname:{type:'string',description:'Display-only label; no effect on billing or credit decisions.',example:'Weekend card'}}}}}};

const CONTEXT={application_id:'APP-CARDS-101',application_name:'Northstar Card Billing',business_use:'U.S. consumer card billing and autopay',assessment_date:FIXTURE_DATE,
 inventory:{source:'SYNTHETIC application CDE catalog export',snapshot_date:'2026-10-20',application_id:'APP-CARDS-101',complete_for_application:true,records:[
  {field:'statementBalance',cde_id:'DEMO-CDE-042',status:'approved',owner:'Cards Finance',approval_ref:'DEMO-ATT-42',review_due:'2026-12-31',expected_type:'number'},
  {field:'legacyMinimumPayment',cde_id:'DEMO-CDE-043',status:'approved',owner:'Cards Finance',approval_ref:'DEMO-ATT-43',review_due:'2026-06-30'}]},
 policy_pack:{id:'DEMO-DG',version:'0.2',source:'Synthetic control pack; NOT Citi policy',effective_from:'2026-01-01',review_due:'2026-12-31',rules:[
  {id:'DEMO-DG §1',name:'Accountable owner',attribute:'owner',test:'present',action:'Confirm the accountable owner with the domain steward.'},
  {id:'DEMO-DG §2',name:'Trusted source reference',attribute:'trusted_source',test:'present',action:'Document and verify the source designation.'},
  {id:'DEMO-DG §3',name:'Field lineage evidence',attribute:'lineage_ref',test:'present',action:'Link source, transformation and consumer field lineage.'},
  {id:'DEMO-DG §4',name:'Quality control evidence',attribute:'dq_ref',test:'present',action:'Define completeness, validity, timeliness and reconciliation tests.'},
  {id:'DEMO-DG §5',name:'Current test passed',attribute:'dq_pass',test:'equals_true',action:'Investigate the failed test and attach a successful rerun.'},
  {id:'DEMO-DG §6',name:'Evidence age ≤30 days',attribute:'tested_at',test:'age_days',limit:30,action:'Refresh the evidence and verify the test period.'}]},
 controls:{
  statementBalance:{owner:'Cards Finance',trusted_source:'DEMO-LEDGER-01',lineage_ref:null,dq_ref:'DEMO-DQ-42',dq_pass:false,tested_at:'2026-08-01'},
  paymentDueDate:{owner:null,trusted_source:'DEMO-LEDGER-01',lineage_ref:'DEMO-LIN-43',dq_ref:null,dq_pass:null,tested_at:null}},
 use_profiles:[
  {purpose:'billing_reminders',label:'Billing reminders',status:'approved',owner:'Cards Servicing',fields:['paymentDueDate','statementBalance','customerEmail'],max_retention_days:30,protection:'mask in logs and delete after sending'},
  {purpose:'servicing_analytics',label:'Servicing analytics',status:'approved',owner:'Cards Finance',fields:['statementBalance','paymentDueDate','creditLimit','aprPercent'],max_retention_days:90,protection:'aggregate before sharing'}],
 strategy:{source:'Synthetic proposed alignment criteria; replace with approved internal data strategy',domain_model_ref:'DEMO-CARDS-MODEL-2',reuses_existing_product:true,new_authoritative_copy:true}};

const SCENARIOS=[
 {id:'extended',group:'Core',label:'Card billing v2.5 · full story',expect:'YES',desc:'The end-to-end story: v2.5 adds creditLimit, aprPercent, hardshipProgramCode, cardArtId and lastLoginAt. Rules find the balance tag and the due-date candidate; the model adds creditLimit and aprPercent.'},
 {id:'tagged',group:'Core',label:'Existing CDE + control gaps',expect:'YES',desc:'The demonstration case: approved balance with failed controls, untagged due-date candidate, sensitive email, display-only nickname, and a legacy tag outside the submitted scope.'},
 {id:'candidate',group:'Core',label:'New candidate only',expect:'POTENTIAL',desc:'Same API with an empty inventory: nothing is tagged yet, so balance and due date surface as untagged candidates.'},
 {id:'benign',group:'Core',label:'No signal in scope',expect:'NO',desc:'Two explicitly display-only fields and a complete, current inventory declaration. NO applies to this scope only.'},
 {id:'ambiguous',group:'Core',label:'Ambiguous input',expect:'POTENTIAL',desc:'A bare JSON sample with no names or descriptions. Missing context can hide a CDE, so the answer is POTENTIAL, not NO.'},
 {id:'wrongApp',group:'Challenge',label:'Wrong-application inventory',expect:'POTENTIAL',desc:'The inventory export belongs to APP-CARDS-207. The balance tag must be verified, not inherited; controls become UNKNOWN.'},
 {id:'duplicate',group:'Challenge',label:'Duplicate tag',expect:'POTENTIAL',desc:'Two approved records (DEMO-CDE-042 and DEMO-CDE-117) claim statementBalance. Identity must be resolved before any control result counts.'},
 {id:'expired',group:'Challenge',label:'Expired approval',expect:'POTENTIAL',desc:'The balance approval review date (2026-09-30) has passed. The tag needs re-verification before it can be relied on.'},
 {id:'alteredType',group:'Challenge',label:'Altered type',expect:'POTENTIAL',desc:'The API now declares statementBalance as a string, while the inventory expects a number. Same name, possibly different meaning.'}];

const EXTENDED_FIELDS={
 creditLimit:{type:'number',description:'Approved credit line used in utilization and authorization'},
 aprPercent:{type:'number',description:'Annual percentage rate applied to purchases'},
 hardshipProgramCode:{type:'string',description:'Hardship program assigned to the account'},
 cardArtId:{type:'string',description:'Card design image identifier; display-only'},
 lastLoginAt:{type:'string',format:'date-time',description:'Time of the most recent app sign-in'}};
function scenario(id){
 const ctx=clone(CONTEXT);let api=clone(OPENAPI);
 if(id==='extended'){api.info.version='2.5.0';Object.assign(api.components.schemas.Statement.properties,clone(EXTENDED_FIELDS))}
 if(id==='candidate')ctx.inventory.records=[];
 if(id==='benign'){ctx.inventory.records=[];api={type:'object',properties:{themeColor:{type:'string',description:'Display only: visual theme selection'},displayLabel:{type:'string',description:'Decorative label for the interface'}}};}
 if(id==='ambiguous'){ctx.inventory.records=[];api={field_a:12.45,field_b:'x'};}
 if(id==='wrongApp')ctx.inventory.application_id='APP-CARDS-207';
 if(id==='duplicate')ctx.inventory.records.push({field:'statementBalance',cde_id:'DEMO-CDE-117',status:'approved',owner:'Cards Servicing',approval_ref:'DEMO-ATT-117',review_due:'2027-03-31',expected_type:'number'});
 if(id==='expired')ctx.inventory.records[0].review_due='2026-09-30';
 if(id==='alteredType')api.components.schemas.Statement.properties.statementBalance.type='string';
 return {input:JSON.stringify(api,null,2),context:ctx};
}

/* Discovery rules. `critical` marks a CDE candidate; non-critical rules flag sensitivity only. */
const FIELD_RULES=[
 {id:'balance',names:['statementbalance','closingbalance','currentbalance','balance','amountdue'],description:/amount owed|statement balance|autopay/i,critical:true,reason:'Monetary value may affect billing or payment execution. Confirm the exact business definition and material use.',units:'USD major units',tests:['required numeric value','currency equals USD','reconcile to source in minor units']},
 {id:'due',names:['paymentduedate','duedate'],description:/payment deadline|payment due|delinquency/i,critical:true,reason:'Payment deadline can affect late fees and delinquency decisions; validate the consumer use and effective calendar.',units:'calendar date',tests:['ISO calendar date','authoritative business calendar','no missing date in billing records']},
 {id:'minimum',names:['minimumpayment','minimumpaymentdue'],description:/minimum payment/i,critical:true,reason:'Payment obligation may directly affect customer treatment.',units:'USD major units',tests:['reconcile minimum-payment calculation']},
 {id:'credit',names:['creditscore','fico'],description:/credit decision|credit score/i,critical:true,reason:'A decision input may be material to credit outcomes; steward must validate context.',units:'model-dependent',tests:['approved score range and model version']},
 {id:'pan',names:['pan','primaryaccountnumber','cardnumber'],description:/full payment card|primary account number/i,critical:false,reason:'Sensitive payment identifier. CDE status cannot be inferred from sensitivity alone.',units:'identifier',tests:['tokenization or masking review']},
 {id:'email',names:['email','customeremail'],description:/email address|servicing contact/i,critical:false,reason:'Contact data needs purpose and sensitivity controls; it is not automatically a CDE.',units:'contact',tests:['permitted contact use review']},
 {id:'ssn',names:['ssn','socialsecuritynumber','taxid'],description:/social security|tax identifier/i,critical:false,reason:'Sensitive identity data needs access and usage controls; criticality still requires business context.',units:'identifier',tests:['sensitivity and access review']}];

function extractFieldsBase(raw){
 const fields=[],warnings=[];
 const add=(field,path,type,description,required)=>{if(!fields.some(f=>f.path===path))fields.push({field,path,type:type||'unknown',description:description||'',required:!!required})};
 const t=raw.trim();
 if(t.startsWith('{')||t.startsWith('[')){
  let root;try{root=JSON.parse(t)}catch(e){throw new Error('JSON could not be parsed: '+e.message)}
  const isSpec=!!(root&&typeof root==='object'&&(root.openapi||root.swagger||root.$schema));
  const visit=(v,path,refs,depth)=>{
   if(depth>32){warnings.push('Maximum nesting reached; coverage is incomplete.');return}
   if(!v||typeof v!=='object')return;
   if(Array.isArray(v)){v.slice(0,20).forEach((x,i)=>visit(x,path+'['+i+']',refs,depth+1));return}
   if(typeof v.$ref==='string'){
    const ref=v.$ref;
    if(!ref.startsWith('#/')){warnings.push('External reference not fetched: '+ref);return}
    if(refs.includes(ref)){warnings.push('Recursive reference skipped: '+ref);return}
    const target=ref.slice(2).split('/').reduce((o,k)=>o&&o[k.replace(/~1/g,'/').replace(/~0/g,'~')],root);
    if(!target){warnings.push('Unresolved reference: '+ref);return}
    // A referenced schema gets its own path root, so one schema used by several operations is listed once.
    visit(target,ref.split('/').pop(),refs.concat(ref),depth+1);return;
   }
   if(v.properties&&typeof v.properties==='object'){
    for(const [k,val] of Object.entries(v.properties)){
     if(!val||typeof val!=='object')continue;
     const p=path+'.'+k;
     add(k,p,val.type||(val.$ref?'object':''),val.description,Array.isArray(v.required)&&v.required.includes(k));
     visit(val,p,refs,depth+1);
    }
    return;
   }
   if(v.type==='array'&&v.items){visit(v.items,path+'[]',refs,depth+1);return}
   for(const kw of ['allOf','oneOf','anyOf'])if(Array.isArray(v[kw]))v[kw].forEach(part=>visit(part,path,refs,depth+1));
   if(typeof v.type==='string'||v.format)return;
   for(const [k,val] of Object.entries(v)){
    if(['info','example','examples','description','required','servers','tags','security','allOf','oneOf','anyOf'].includes(k))continue;
    if(isSpec&&depth===0&&['components','definitions','$defs'].includes(k))continue;
    if(val&&typeof val==='object')visit(val,isSpec?path:path+'.'+k,refs,depth+1);
    else if(!isSpec)add(k,path+'.'+k,typeof val,'',false);
   }
  };
  visit(root,'$',[],0);
  return {fields,warnings,mode:'JSON / OpenAPI with local $ref resolution'};
 }
 const lines=raw.split(/\r?\n/),isSQL=/\bselect\b/i.test(raw);
 const skip=['type','format','description','properties','required','info','title','version','openapi','paths','responses','schema','content','example'];
 lines.forEach((line,i)=>{
  const m=line.match(/^\s*(?:-\s*)?([A-Za-z_]\w*)\s*:/);
  if(m&&!skip.includes(m[1])){const d=(lines.slice(i,i+5).find(x=>/description\s*:/.test(x))||line).trim();add(m[1],'line '+(i+1),'unverified',d)}
  if(isSQL){for(const rule of FIELD_RULES)for(const alias of rule.names){const re=new RegExp('\\b'+alias.split('').map(c=>c+'_?').join('')+'\\b','i');const hit=line.match(re);if(hit)add(hit[0],'line '+(i+1)+' · '+hit[0],'unverified',line.trim())}}
  if(!m&&!isSQL){const x=line.match(/^\s*([A-Za-z_]\w*)\s*(?:-|=|\s)\s*(.+)$/);if(x)add(x[1],'line '+(i+1),'unverified',x[2])}
 });
 warnings.push('Limited text extraction; nested YAML, SQL aliases/expressions and full lineage need a production parser.');
 return {fields,warnings,mode:'Limited YAML / SQL / description scan'};
}

function validContext(c){
 if(!c||!c.application_id||!c.inventory||!Array.isArray(c.inventory.records)||!c.policy_pack||!Array.isArray(c.policy_pack.rules)||!c.controls||typeof c.controls!=='object'||!c.strategy)throw new Error('Context requires application_id, inventory.records, policy_pack.rules, controls and strategy. Use the template.');
 if([c.assessment_date,c.inventory.snapshot_date,c.policy_pack.effective_from,c.policy_pack.review_due].some(d=>!isISODate(d)))throw new Error('Context dates must be valid ISO dates (YYYY-MM-DD).');
 if(c.inventory.records.some(r=>!r||typeof r.field!=='string'))throw new Error('Each inventory record needs a field name.');
 if(c.policy_pack.rules.length>50||c.inventory.records.length>2000)throw new Error('Demo limit: 50 policy rules and 2,000 inventory records.');
 if(c.policy_pack.rules.some(r=>!r||!r.id||!r.attribute||!['present','equals_true','age_days'].includes(r.test)))throw new Error('Each policy rule needs an id, attribute and a supported test: present, equals_true or age_days.');
 if(c.policy_pack.rules.some(r=>r.test==='age_days'&&(!Number.isFinite(r.limit)||r.limit<0)))throw new Error('age_days rules need a non-negative numeric limit.');
}

function fieldAction(f,c){
 const ownerOf=()=>((c.controls[f.field]||{}).owner)||(f.record&&f.record.owner)||'Unassigned';
 if(f.status==='EXISTING APPROVED (snapshot)')return {who:ownerOf(),what:'Keep tag; resolve any control gaps. Next approval review '+f.record.review_due+'.'};
 if(f.status==='CONFLICTING INVENTORY RECORDS')return {who:'Domain steward',what:'Resolve duplicate records '+f.conflicts.join(' / ')+' before relying on either.'};
 if(f.status==='EXISTING TAG NEEDS VERIFICATION')return {who:'Domain steward',what:'Re-verify mapping: '+f.mappingIssues.join('; ')+'.'};
 if(f.status==='POSSIBLE INVENTORY MATCH')return {who:'Domain steward',what:'Confirm alias identity for '+f.possible.map(r=>r.cde_id).join(', ')+'.'};
 if(f.status==='UNTAGGED CANDIDATE')return {who:'Domain steward',what:'Assess nomination; control owner attaches evidence for the contract.'};
 if(f.status==='SENSITIVE / CONTEXT REVIEW')return {who:'Data owner',what:'Confirm permitted use and protection; CDE status needs business context.'};
 return {who:'—',what:'No action for this use; reassess when fields or business use change.'};
}

function analyze(raw,c,opts){
 validContext(c);
 const ex=extractFields(raw);
 if(!ex.fields.length)throw new Error('No fields found. Use JSON/OpenAPI, or one field description per line.');
 if(ex.fields.length>1000)throw new Error('Demo supports at most 1,000 discovered field paths.');
 const scope=c.inventory.application_id===c.application_id;
 const snapAge=daysBetween(c.assessment_date,c.inventory.snapshot_date),fresh=snapAge>=0&&snapAge<=30;
 const packCurrent=c.policy_pack.effective_from<=c.assessment_date&&c.policy_pack.review_due>=c.assessment_date;
 const findings=ex.fields.map(f=>{
  const displayOnly=/display.only|decorative|no effect on/i.test(f.description);
  const rule=FIELD_RULES.find(r=>r.names.includes(norm(f.field)))||(!displayOnly?FIELD_RULES.find(r=>r.description.test(f.description)):undefined);
  const uniqueName=ex.fields.filter(x=>x.field===f.field).length===1;
  const exact=c.inventory.records.filter(r=>r.path?r.path===f.path:(r.field===f.field&&uniqueName));
  const possible=exact.length?[]:c.inventory.records.filter(r=>norm(r.field)===norm(f.field)||(Array.isArray(r.aliases)&&r.aliases.some(a=>norm(a)===norm(f.field))));
  const record=exact.length===1?exact[0]:null;
  const typeMatch=!record||!record.expected_type||record.expected_type===f.type;
  const mappingIssues=[];
  if(record){
   if(!scope)mappingIssues.push('inventory belongs to '+c.inventory.application_id+', not '+c.application_id);
   if(!fresh)mappingIssues.push('inventory snapshot outside the 30-day window');
   if(!typeMatch)mappingIssues.push('submitted type '+f.type+' ≠ expected '+record.expected_type);
   if(record.status!=='approved')mappingIssues.push('record status is '+record.status);
   if(!record.cde_id||!record.approval_ref)mappingIssues.push('approval reference missing');
   if(!isISODate(record.review_due)||record.review_due<c.assessment_date)mappingIssues.push('approval review date '+record.review_due+' has passed');
  }
  const approved=!!record&&!mappingIssues.length;
  const status=approved?'EXISTING APPROVED (snapshot)':exact.length>1?'CONFLICTING INVENTORY RECORDS':record?'EXISTING TAG NEEDS VERIFICATION':possible.length?'POSSIBLE INVENTORY MATCH':rule&&rule.critical?'UNTAGGED CANDIDATE':rule?'SENSITIVE / CONTEXT REVIEW':'NO CDE SIGNAL';
  const strength=approved?95:(exact.length||possible.length)?65:rule&&rule.critical?(f.description?82:62):rule?45:25;
  const out={...f,rule,record,possible,conflicts:exact.length>1?exact.map(r=>r.cde_id):[],mappingIssues,status,approved,typeMatch,uniqueName,strength,
   needsCDE:approved||exact.length>0||possible.length>0||!!(rule&&rule.critical)};
  out.action=fieldAction(out,c);
  return out;
 });
 const unmatched=c.inventory.records.filter(r=>!findings.some(f=>f.record===r||(f.conflicts.length&&f.conflicts.includes(r.cde_id))));
 const controls=[];
 for(const f of findings.filter(x=>x.needsCDE||(opts&&opts.extra&&opts.extra.has(x.field)))){
  const evidence=c.controls[f.field]||{};
  for(const r of c.policy_pack.rules){
   const value=evidence[r.attribute];let result='UNKNOWN',why='Evidence missing';
   if(f.conflicts.length)why='Conflicting inventory records; resolve identity first';
   else if(!f.uniqueName)why='Field name appears at several paths; path-specific evidence required';
   else if(!f.typeMatch)why='Submitted type differs from inventory expected_type';
   else if(!packCurrent)why='Policy pack outside its declared effective/review dates';
   else if(!scope)why='Application and inventory scopes differ';
   else if(value!==null&&value!==undefined&&value!==''){
    if(r.test==='present'){result='PASS';why='Declared reference present; source not authenticated'}
    if(r.test==='equals_true'){result=value===true?'PASS':'FAIL';why='Declared result = '+String(value)}
    if(r.test==='age_days'){const age=isISODate(value)?daysBetween(c.assessment_date,value):NaN;result=Number.isFinite(age)&&age>=0&&age<=r.limit?'PASS':'FAIL';why='Evidence age '+(Number.isFinite(age)?Math.round(age)+' days (limit '+r.limit+')':'invalid date')}
   }
   controls.push({field:f.field,path:f.path,clause:r.id,requirement:r.name||r.attribute,status:result,evidence:r.attribute+' = '+JSON.stringify(value===undefined?null:value),why,action:r.action||'Owner to resolve and attach evidence.'});
  }
 }
 const yes=findings.some(f=>f.approved),potential=findings.some(f=>f.needsCDE||f.rule);
 const clearlyBenign=findings.every(f=>/display.only|decorative|visual theme/i.test(f.description));
 const noOK=!potential&&clearlyBenign&&scope&&fresh&&c.inventory.complete_for_application===true&&!ex.warnings.length;
 const verdict=yes?'YES':noOK?'NO':'POTENTIAL';
 const reason=yes?'An existing approved CDE matches the supplied application snapshot. Imported approval is not independently authenticated.':noOK?'No candidate in the supplied, explicitly display-only scope. Reassess when fields or business use change.':'Candidate, sensitive, ambiguous or incomplete evidence requires steward assessment.';
 const s=c.strategy;
 const strategy=[
  {criterion:'Canonical domain semantics',status:s.domain_model_ref?'EVIDENCE PRESENT':'UNKNOWN',evidence:s.domain_model_ref||'Domain mapping missing',action:'Verify the mapping against the approved domain model.'},
  {criterion:'Reuse an existing data product',status:s.reuses_existing_product===true?'ALIGNED':s.reuses_existing_product===false?'REVIEW':'UNKNOWN',evidence:'Declared reuse = '+String(s.reuses_existing_product),action:'Document why a new product is needed if reuse is unsuitable.'},
  {criterion:'Avoid a competing authoritative copy',status:s.new_authoritative_copy===true?'REVIEW':s.new_authoritative_copy===false?'ALIGNED':'UNKNOWN',evidence:'Declared new copy = '+String(s.new_authoritative_copy),action:'Confirm authoritative source designation with architecture.'}];
 const warnings=ex.warnings.concat(!scope?['Inventory belongs to a different application ('+c.inventory.application_id+').']:[],!fresh?['Inventory snapshot is outside the 30-day validity window.']:[],!packCurrent?['Policy pack version needs effective-date review.']:[]);
 return {context:c,findings,unmatched,controls,strategy,verdict,reason,strength:yes?95:noOK?70:Math.max(...findings.map(f=>f.strength)),warnings,mode:ex.mode,scope,fresh,packCurrent};
}

function remediatedContext(a){
 const c=clone(a.context);
 a.findings.filter(f=>f.needsCDE||f.mlSuggested).forEach(f=>{c.controls[f.field]={owner:(c.controls[f.field]||{}).owner||'Cards Finance (demo)',trusted_source:'DEMO-LEDGER-01',lineage_ref:'DEMO-LIN-'+f.field,dq_ref:'DEMO-DQ-'+f.field,dq_pass:true,tested_at:c.assessment_date}});
 c.strategy.new_authoritative_copy=false;
 return c;
}

function buildContract(a,review){
 const c=a.context;
 return {version:'draft-0.2',application_id:c.application_id,status:'proposed_not_approved',assessment_date:c.assessment_date,
  official_classification_source:'supplied inventory snapshot only; no automatic approval',
  policy_pack:{id:c.policy_pack.id,version:c.policy_pack.version,source:c.policy_pack.source},project_determination:a.verdict,
  fields:a.findings.map(f=>({name:f.field,path:f.path,type:f.type,required:f.required,cde_status:f.status,existing_cde_id:f.record?f.record.cde_id:null,
   units:f.rule?f.rule.units:'to_confirm',proposed_checks:f.rule?f.rule.tests:['confirm business meaning'],owner:(c.controls[f.field]||{}).owner||'unassigned',permitted_use:c.business_use||'to_confirm'})),
  use_profiles:(c.use_profiles||[]).map(p=>({purpose:p.purpose,label:p.label,owner:p.owner,fields:p.fields,max_retention_days:p.max_retention_days})),release_conditions:['Steward verifies candidate and imported classifications','Producer and consumer approve semantics and SLOs','Resolve FAIL/UNKNOWN controls or attach an authorized, time-bound exception'],
  control_findings:a.controls.filter(r=>r.status!=='PASS'),review_log:review||[],real_systems_updated:false};
}

/* Evaluation illustration: 12 synthetic fields with steward labels. */
const EVAL_SET=[
 ['statementBalance','USD amount owed at statement close; input to autopay','cde'],
 ['paymentDueDate','Payment deadline that drives late fees and delinquency','cde'],
 ['minimumPaymentDue','Minimum payment required this cycle','cde'],
 ['closingBalance','Balance at billing-cycle close','cde'],
 ['fico','Bureau score used in credit line decisions','cde'],
 ['creditLimit','Approved credit line used in utilization and authorization','cde'],
 ['aprPercent','Annual percentage rate applied to purchases','cde'],
 ['customerEmail','Servicing contact for reminder notices','not_cde'],
 ['rewardsNickname','Display-only label; no effect on billing or credit','not_cde'],
 ['themeColor','Display only: visual theme selection','not_cde'],
 ['cardArtId','Card design image identifier; display-only','not_cde'],
 ['lastLoginAt','Time of the most recent app sign-in','not_cde']];
function evaluateEngine(){
 const props={};EVAL_SET.forEach(([n,d])=>props[n]={type:'string',description:d});
 const ctx=clone(CONTEXT);ctx.inventory.records=[];
 const a=analyze(JSON.stringify({type:'object',properties:props}),ctx);
 const rows=EVAL_SET.map(([n,d,label])=>{const f=a.findings.find(x=>x.field===n);const pred=f.needsCDE?'cde':'not_cde';
  return {field:n,description:d,label,predicted:pred,engine_status:f.status,outcome:label==='cde'?(pred==='cde'?'TP':'FN'):(pred==='cde'?'FP':'TN')}});
 const k=o=>rows.filter(r=>r.outcome===o).length,tp=k('TP'),fp=k('FP'),fn=k('FN');
 return {rows,tp,fp,fn,tn:k('TN'),precision:tp+fp?tp/(tp+fp):null,recall:tp+fn?tp/(tp+fn):null};
}

/* Candidate model: logistic regression on field-name words, description words and four domain cue features.
   Trained on synthetic steward-style labels; it may only ADD fields to the review list, never decide. */
const ML_CDE=`statementBalanceAmt|Balance owed on the statement used to calculate payments
currentBalance|Outstanding balance on the card account at end of day
newBalance|New balance printed on the monthly statement
previousBalance|Prior cycle balance carried into the statement calculation
outstandingPrincipal|Principal amount owed used for interest calculation
totalAmountDue|Total amount the customer must pay by the due date
minPayDue|Minimum amount due to keep the account current
minimumPaymentAmount|Required minimum payment calculated each billing cycle
pastDueAmount|Amount past due that drives delinquency treatment
daysPastDue|Number of days the payment is late; drives delinquency bucket
delinquencyBucket|Delinquency stage used for collections and reporting
dueDate|Date by which payment must be received to avoid a late fee
nextPaymentDueDate|Upcoming payment deadline used for late fee assessment
cycleCloseDate|Billing cycle close date used to produce the statement
statementCloseDate|Date the statement closes; determines interest and fees
gracePeriodEndDate|Last day of the grace period before interest accrues
lateFeeAmount|Late fee charged when the minimum payment is missed
annualFeeAmount|Annual fee charged to the card account
feeCharged|Fee amount assessed on the account during the cycle
interestCharged|Interest amount charged on revolving balances
purchaseInterestRate|Interest rate applied to purchase balances
cashAdvanceApr|Annual percentage rate applied to cash advances
penaltyApr|Penalty annual percentage rate after missed payments
promoRatePercent|Promotional annual percentage rate on balance transfers
balanceTransferRate|Rate applied to transferred balances
dailyPeriodicRate|Periodic rate used to compute daily interest
creditLineAmount|Total credit line assigned to the account; used in authorization
availableCredit|Remaining credit available for purchase authorization
cashAdvanceLimit|Maximum cash advance amount authorized on the account
temporaryLimitIncrease|Temporary increase to the approved credit line
overLimitAmount|Amount by which the balance exceeds the approved credit line
creditUtilizationRatio|Balance divided by credit line used in risk decisions
riskScore|Internal risk score used in credit line decisions
bureauScore|Credit bureau score used in underwriting decisions
behaviorScore|Behavior score that drives credit line management decisions
probabilityOfDefault|Model estimate used in loss reserving and credit decisions
chargeOffAmount|Amount charged off and reported in loss reporting
chargeOffDate|Date the balance was charged off for regulatory reporting
recoveryAmount|Amount recovered after charge-off used in loss reporting
autopayAmount|Amount drafted by autopay from the customer bank account
paymentAmount|Amount of the customer payment posted to the account
paymentPostedDate|Date a payment posted; determines on-time status
paymentStatus|Status of the payment used in delinquency decisions
accountStatus|Account status code that controls authorization and reporting
regulatoryReportCode|Code used in regulatory reporting of the account
reserveAmount|Loss reserve amount reported in financial statements
glAccountBalance|General ledger balance reconciled to financial reporting
transactionAmount|Posted transaction amount in USD that updates the balance
postedAmount|Amount posted to the ledger for the transaction
disputeAmount|Disputed amount withheld from the balance under regulation
rewardsLiability|Rewards points liability reported in financial statements
interestAccrued|Accrued interest amount booked to the ledger
minimumDueDate|Deadline for the minimum payment; drives late fees
creditDecisionCode|Outcome code of the credit decision for the application
underwritingIncome|Stated income used in underwriting and credit decisions
collateralValue|Collateral value used in credit exposure reporting
exposureAtDefault|Exposure amount used in capital reporting
settlementAmount|Amount settled with the network and reconciled to the ledger
feeWaiverAmount|Amount of fees waived that adjusts the balance
creditLimitChangeDate|Date the approved credit line changed`;
const ML_NOT=`displayName|Name shown in the app header; display only
nickname|Customer-chosen label shown in the app; cosmetic
cardNickname|Display-only nickname for the card; no effect on billing
themePreference|Visual theme preference for the interface
fontSize|Preferred font size for the mobile app
languagePreference|Preferred display language for screens
avatarUrl|Profile picture link shown in the app
cardImageId|Card artwork image identifier; display only
backgroundImage|Decorative background image for the dashboard
tileOrder|Order of tiles on the home screen
lastLoginTime|Time of the last sign-in to the app
sessionId|Identifier of the current app session
deviceType|Type of device used to sign in
appVersion|Version of the mobile app installed
pushToken|Token for sending push notifications to the device
browserAgent|Browser user agent captured for troubleshooting
pageViewCount|Number of pages viewed in the session
clickstreamId|Identifier for web analytics events
lastScreenViewed|Last screen the user opened in the app
tutorialCompleted|Whether the onboarding tutorial was finished
marketingOptIn|Whether the customer agreed to receive marketing messages
campaignCode|Code of the marketing campaign that referred the visit
promoBannerId|Identifier of the promotional banner shown
surveyResponse|Free-text answer to a satisfaction survey
npsScore|Net promoter score from a customer survey
contactEmail|Email used for servicing messages and reminders
emailAddress|Customer email address for notices
mobilePhone|Phone number for text reminders
homePhone|Home phone number for servicing calls
mailingAddressLine|Street address for paper mail
preferredContactTime|Preferred time for servicing calls
reminderChannel|Channel used to send reminder notices
notificationEnabled|Whether alerts are switched on in the app
alertThreshold|Customer-set threshold that triggers a spending alert notification
paperlessFlag|Whether the customer chose electronic delivery
statementFormat|Layout preference for the statement PDF
helpArticleId|Identifier of a help center article viewed
chatTranscriptId|Identifier of a support chat transcript
agentNotes|Free-text notes left by a service agent
callReasonCode|Reason selected for a servicing call
favoriteMerchant|Merchant the customer marked as favorite
merchantLogoUrl|Logo image shown next to transactions
categoryIcon|Icon shown for a spending category
spendingCategoryLabel|Label of the budgeting category chosen by the customer
budgetGoalName|Name of a personal budgeting goal
widgetLayout|Layout of widgets on the dashboard
darkModeEnabled|Whether dark mode is enabled in the app
lastPasswordChange|Time the password was last changed
mfaMethod|Preferred sign-in verification method
loginAttempts|Number of sign-in attempts in the session
cardDesignCode|Code of the card design chosen by the customer
referralCode|Code shared to refer a friend
socialHandle|Social media handle provided by the customer
birthdayGreetingSent|Whether a birthday greeting message was sent
appRating|Rating the customer gave the mobile app
featureFlag|Feature toggle for an experimental screen
sortPreference|Preferred sort order for the transaction list
searchQuery|Text the customer searched for in the app
cardArtVersion|Version of the card art asset; display only
welcomeMessage|Welcome text shown on first login
cardColorChoice|Color choice for the card face; no effect on credit decisions
statementHeaderLabel|Label printed in the statement header; no effect on billing
rewardsTierName|Display name of the rewards tier; does not affect credit or payments`;
const ML_STOP=new Set('the an of to for on in by and or is that when with from each was be after before into at as this its it are has have no not any per which whether'.split(' '));
const ML_CUES=[['cue:money',/\b(amount|balance|balances|usd|fee|fees|interest|rate|apr|ledger|payment|principal)\b/],['cue:decision',/(decision|delinquen|authoriz|underwrit|regulat|reporting|reconcil|charge.?off|capital|credit line)/],['cue:display',/(display|decorative|cosmetic|icon|image|logo|theme|layout|artwork)/],["cue:no-effect",/(no effect on|does not affect|not used (in|for))/],['cue:engagement',/(notification|reminder|alert|survey|marketing|session|sign-in|login)/]];
function mlRows(){const p=(s,label)=>s.split('\n').map(l=>{const [name,description]=l.split('|');return {name,description,label}});return p(ML_CDE,'cde').concat(p(ML_NOT,'not_cde'))}
function mlSplit(){
 // Interleave classes, then hold out every fifth example; the split is fixed so every run is reproducible.
 const rows=mlRows(),pos=rows.filter(r=>r.label==='cde'),neg=rows.filter(r=>r.label!=='cde'),mixed=[];
 for(let i=0;i<Math.max(pos.length,neg.length);i++){if(pos[i])mixed.push(pos[i]);if(neg[i])mixed.push(neg[i])}
 return {train:mixed.filter((_,i)=>i%5!==4),test:mixed.filter((_,i)=>i%5===4)};
}
function mlTokens(text){return String(text||'').replace(/([a-z0-9])([A-Z])/g,'$1 $2').toLowerCase().split(/[^a-z0-9]+/).filter(w=>w.length>1&&!ML_STOP.has(w)).map(w=>w.length>3&&w.endsWith('s')&&!w.endsWith('ss')?w.slice(0,-1):w)}
function mlFeatures(name,description){
 const f=new Set(),text=(String(name).replace(/([a-z0-9])([A-Z])/g,'$1 $2')+' '+(description||'')).toLowerCase();
 mlTokens(name).forEach(t=>{f.add('name:'+t);f.add('word:'+t)});
 mlTokens(description).forEach(t=>f.add('word:'+t));
 ML_CUES.forEach(([k,re])=>{if(re.test(text))f.add(k)});
 return [...f];
}
const sigmoid=z=>1/(1+Math.exp(-z));
function trainModel(examples,opts){
 const o=Object.assign({epochs:300,lr:0.5,l2:0.002},opts||{});
 const X=examples.map(e=>({f:mlFeatures(e.name,e.description),y:e.label==='cde'?1:0,w:e.weight||1}));
 const W=X.reduce((s,x)=>s+x.w,0),w={};let b=0;const losses=[];
 X.forEach(x=>x.f.forEach(k=>{w[k]=0}));
 for(let ep=0;ep<o.epochs;ep++){
  const g={};let gb=0,loss=0;
  for(const x of X){let z=b;for(const k of x.f)z+=w[k];const p=sigmoid(z),err=(p-x.y)*x.w;gb+=err;for(const k of x.f)g[k]=(g[k]||0)+err;loss+=-x.w*(x.y*Math.log(p+1e-12)+(1-x.y)*Math.log(1-p+1e-12))}
  for(const k in w)w[k]-=o.lr*((g[k]||0)/W+o.l2*w[k]);
  b-=o.lr*gb/W;losses.push(loss/W);
 }
 return {weights:w,bias:b,losses,examples:examples.length,vocabulary:Object.keys(w).length,options:o};
}
function predict(model,name,description){
 const f=mlFeatures(name,description),contributions=f.filter(k=>model.weights[k]).map(k=>({feature:k,weight:model.weights[k]})).sort((a,b)=>Math.abs(b.weight)-Math.abs(a.weight));
 const z=model.bias+contributions.reduce((s,c)=>s+c.weight,0);
 return {p:sigmoid(z),z,contributions,unseen:f.filter(k=>!(k in model.weights))};
}
function binaryMetrics(rows,key){
 const tp=rows.filter(r=>r.label==='cde'&&r[key]).length,fp=rows.filter(r=>r.label!=='cde'&&r[key]).length,fn=rows.filter(r=>r.label==='cde'&&!r[key]).length,tn=rows.length-tp-fp-fn;
 return {tp,fp,fn,tn,precision:tp+fp?tp/(tp+fp):null,recall:tp+fn?tp/(tp+fn):null,accuracy:(tp+tn)/rows.length,f1:tp?2*tp/(2*tp+fp+fn):0};
}
function mlHoldout(model,t){const rows=mlSplit().test.map(r=>({...r,model:predict(model,r.name,r.description).p>=t}));return binaryMetrics(rows,'model')}

const ML_TEACH={name:'hardshipPlanFlag',description:'Customer enrolled in a hardship repayment plan',label:'cde'};
const ML_PROBES=[[ML_TEACH.name,ML_TEACH.description],['hardshipProgramCode','Hardship program assigned to the account'],['hardshipEnrollmentDate','Date the customer joined a hardship program']];
function mlCompare(model,t){
 // Rules + model: the model may only add a field the rules did not flag.
 const rows=evaluateEngine().rows.map(r=>{const p=predict(model,r.field,r.description).p;return {...r,p,rules:r.predicted==='cde',model:p>=t,hybrid:r.predicted==='cde'||p>=t}});
 return {rows,rules:binaryMetrics(rows,'rules'),model:binaryMetrics(rows,'model'),hybrid:binaryMetrics(rows,'hybrid')};
}
function mlLearningCurve(t){const train=mlSplit().train;return [10,20,40,60,80,train.length].map(k=>{const h=mlHoldout(trainModel(train.slice(0,k)),t);return {k,f1:h.f1,accuracy:h.accuracy}})}

/* ── Northstar combined: Find → Prove → Govern use. One evidence thread, three decisions. ── */
const PURPOSES=[
 {id:'billing_reminders',label:'Billing reminders'},
 {id:'servicing_analytics',label:'Servicing analytics (aggregated)'},
 {id:'marketing',label:'Marketing segmentation'},
 {id:'model_training',label:'AI model training'}];

function runPipeline(raw,ctx,model,t){
 // Rules decide the verdict. The model may only add fields to the review list, which also earns them a readiness check.
 const base=analyze(raw,ctx);
 const score=f=>model?predict(model,f.field,f.description):null;
 const extra=new Set(base.findings.filter(f=>{const s=score(f);return !f.needsCDE&&!f.rule&&s&&s.contributions.length&&s.p>=t}).map(f=>f.field));
 const a=analyze(raw,ctx,{extra});
 a.findings.forEach(f=>{const s=score(f);f.ml=s?{p:s.p,why:s.contributions.slice(0,3).map(c=>(c.weight>0?'+':'')+c.weight.toFixed(2)+' '+c.feature),known:s.contributions.length>0}:null;f.mlSuggested=extra.has(f.field);f.onReviewList=f.needsCDE||!!f.rule||f.mlSuggested});
 a.modelThreshold=t;a.modelUsed=!!model;
 return a;
}

function purposeGate(a,review,req){
 const c=a.context,profile=(c.use_profiles||[]).find(p=>p.purpose===req.purpose&&p.status==='approved');
 const decided={};(review||[]).forEach(r=>{decided[r.field]=r.decision});
 const final=d=>d==='nominate'||d==='verify_existing'||d==='not_cde';
 const rows=(req.fields||[]).map(name=>{
  const f=a.findings.find(x=>x.field===name);
  if(!f)return {field:name,status:'UNKNOWN',reason:'Not in the assessed scope. Run Find on the spec that contains it.',cde:false,gaps:0,keep:false};
  const d=decided[name],gaps=a.controls.filter(r=>r.field===name&&r.status!=='PASS').length;
  const flagged=f.needsCDE||f.mlSuggested;
  const isCDE=f.approved||d==='nominate'||d==='verify_existing'||(f.needsCDE&&d!=='not_cde');
  const pending=flagged&&!f.approved&&!final(d);
  const sensitive=!!(f.rule&&!f.rule.critical);
  let status='OK',reason='Within the approved use profile.';
  if(!profile){status='REVIEW';reason='No approved use profile for this purpose.'}
  else if(!profile.fields.includes(name)){status='REMOVE';reason='Not needed for '+profile.label.toLowerCase()+'. Minimise.'}
  else if(pending){status='HOLD';reason='Steward decision pending ('+(f.mlSuggested?'model-suggested candidate':f.status.toLowerCase())+').'}
  else if(isCDE&&gaps){status='BLOCKED';reason=gaps+' control gap(s). Not ready for reuse until Prove clears them.'}
  else if(sensitive)reason='Sensitive, permitted for this profile only: '+(profile.protection||'apply masking')+'.';
  else if(isCDE)reason='CDE with current evidence; within the profile.';
  return {field:name,status,reason,cde:isCDE,gaps,sensitive,keep:status!=='REMOVE'};
 });
 const issues=[];
 if(!req.fields||!req.fields.length)issues.push('Select at least one field.');
 if(!profile)issues.push('No approved use profile matches “'+((PURPOSES.find(p=>p.id===req.purpose)||{}).label||req.purpose)+'”. Route to the data owner and the policy authority.');
 const days=Number(req.retention_days);
 if(profile&&(!Number.isFinite(days)||days<1||days>profile.max_retention_days))issues.push('Retention of '+req.retention_days+' days is outside the profile’s 1–'+profile.max_retention_days+' days.');
 if(req.purpose==='model_training')issues.push('Model training also needs model-risk and privacy review. Quality scores and CDE tags never establish permission.');
 const has=s=>rows.some(r=>r.status===s);
 const verdict=!rows.length?'INCOMPLETE':!profile?'REVIEW REQUIRED':has('BLOCKED')?'BLOCKED: READINESS':has('HOLD')?'ON HOLD: STEWARD DECISION':has('UNKNOWN')?'REVIEW REQUIRED':(has('REMOVE')||issues.length)?'CONDITIONAL: MINIMISE':'COMPATIBLE WITH PROFILE';
 const route={'BLOCKED: READINESS':'Control owner resolves the readiness gaps in Prove, then the request is re-evaluated.',
  'ON HOLD: STEWARD DECISION':'Steward records a decision in Prove, then the request is re-evaluated.',
  'CONDITIONAL: MINIMISE':'Accept the minimised request, or document why more is needed.',
  'COMPATIBLE WITH PROFILE':'Data owner confirms identity, entitlements and consent, then provisions through the normal access process.',
  'REVIEW REQUIRED':'Route to the data owner and policy authority'+(req.purpose==='model_training'?', plus model-risk and privacy review':'')+'.',
  'INCOMPLETE':'Select fields to request.'}[verdict];
 const minimised=profile?{...req,fields:rows.filter(r=>r.keep).map(r=>r.field),retention_days:Math.min(profile.max_retention_days,Math.max(1,Number.isFinite(days)?days:1))}:null;
 return {request:req,profile:profile?{purpose:profile.purpose,label:profile.label,owner:profile.owner,fields:profile.fields,max_retention_days:profile.max_retention_days}:null,rows,issues,verdict,route,minimised,access_granted:false,legal_compliance_determined:false,synthetic:true};
}

const STORY_REQUEST={requester:'Servicing analytics team',purpose:'billing_reminders',fields:['statementBalance','paymentDueDate','customerEmail','creditLimit'],retention_days:90};
const TRAINING_REQUEST={requester:'Collections AI team',purpose:'model_training',fields:['statementBalance','paymentDueDate','creditLimit','aprPercent'],retention_days:365};
const STORY_REVIEW=[{field:'statementBalance',decision:'verify_existing'},{field:'paymentDueDate',decision:'nominate'},{field:'creditLimit',decision:'nominate'},{field:'aprPercent',decision:'nominate'},{field:'customerEmail',decision:'not_cde'}];

function runJourney(model,t){
 const s=scenario('extended');
 const a1=runPipeline(s.input,s.context,model,t),g1=purposeGate(a1,[],STORY_REQUEST);
 const a2=runPipeline(s.input,remediatedContext(a1),model,t);
 const review=STORY_REVIEW.map(r=>({...r,path:(a2.findings.find(f=>f.field===r.field)||{}).path,rationale:'Demo: steward decisions from the end-to-end story',official_status_changed:false}));
 const g2=purposeGate(a2,review,STORY_REQUEST),g3=purposeGate(a2,review,g2.minimised),g4=purposeGate(a2,review,TRAINING_REQUEST);
 return {input:s.input,a1,g1,a2,review,g2,g3,g4,contract:buildContract(a2,review)};
}

/* Value: every number is the user's assumption; nothing here is measured. */
const VALUE_INPUTS=[
 {id:'apps',group:'Find',label:'Applications through design review per year',unit:'apps',def:40,step:1,pilot:'Count from the review intake log.'},
 {id:'fields',group:'Find',label:'Fields per application',unit:'fields',def:60,step:1,pilot:'Count fields in the pilot application’s specs.'},
 {id:'minToday',group:'Find',label:'Minutes per field to triage today',unit:'min',def:3,step:0.5,pilot:'Time stewards preparing a review packet by hand.'},
 {id:'minWith',group:'Find',label:'Minutes per field with Northstar',unit:'min',def:1.5,step:0.5,pilot:'Time the same stewards with the review list.'},
 {id:'lateCdes',group:'Prove',label:'CDEs found late (at release or later) per application',unit:'CDEs',def:1,step:0.1,pilot:'Count late CDE findings in past reviews.'},
 {id:'catchShare',group:'Prove',label:'Share Northstar would catch at design',unit:'%',def:50,step:5,pilot:'Candidate recall on past late findings.'},
 {id:'hoursLate',group:'Prove',label:'Hours to remediate a CDE found late',unit:'h',def:16,step:1,pilot:'Effort on past late-finding tickets.'},
 {id:'hoursEarly',group:'Prove',label:'Hours to handle it at design',unit:'h',def:4,step:1,pilot:'Effort for candidates handled in the pilot.'},
 {id:'reuseReq',group:'Govern use',label:'Data reuse requests per year',unit:'requests',def:60,step:1,pilot:'Count access/reuse tickets for the domain.'},
 {id:'reuseToday',group:'Govern use',label:'Hours to assess a reuse request today',unit:'h',def:6,step:0.5,pilot:'Time from ticket to documented decision.'},
 {id:'reuseWith',group:'Govern use',label:'Hours with the purpose packet',unit:'h',def:2.5,step:0.5,pilot:'Same, with the gate’s packet attached.'},
 {id:'rate',group:'Cost',label:'Loaded cost per hour',unit:'cur',def:100,step:5,pilot:'Finance’s standard loaded rate.'}];
const HOURS_PER_FTE=1600;
function valueDefaults(){const a={};VALUE_INPUTS.forEach(i=>a[i.id]=i.def);return a}
function valueEstimate(a){
 const n=k=>{const v=Number(a[k]);return Number.isFinite(v)&&v>0?v:0};
 const fields=n('apps')*n('fields'),triage=Math.max(0,fields*(n('minToday')-n('minWith'))/60);
 const caught=n('apps')*n('lateCdes')*Math.min(100,n('catchShare'))/100,rework=caught*Math.max(0,n('hoursLate')-n('hoursEarly'));
 const reuse=n('reuseReq')*Math.max(0,n('reuseToday')-n('reuseWith'));
 const hours=triage+rework+reuse;
 return {fields,triage,caught,rework,reuse,hours,cost:hours*n('rate'),fte:hours/HOURS_PER_FTE,estimate:true,measured:false};
}
function valueSensitivity(a,swing){
 const base=valueEstimate(a).hours;
 return VALUE_INPUTS.filter(i=>i.id!=='rate').map(i=>{const lo=valueEstimate({...a,[i.id]:a[i.id]*(1-swing)}).hours,hi=valueEstimate({...a,[i.id]:a[i.id]*(1+swing)}).hours;return {id:i.id,label:i.label,low:Math.min(lo,hi),high:Math.max(lo,hi),base,range:Math.abs(hi-lo)}}).sort((x,y)=>y.range-x.range);
}

function runSelfChecks(){
 const results=[];
 const t=(area,name,fn)=>{let ok=false,err='';try{ok=fn()===true}catch(e){err=e.message}results.push({area,name,ok,err})};
 const run=id=>{const s=scenario(id);return analyze(s.input,s.context)};
 const fs=(a,n)=>a.findings.find(f=>f.field===n);
 const ctl=(a,f,attr)=>a.controls.find(r=>r.field===f&&r.evidence.startsWith(attr+' ')).status;
 const A=run('tagged');
 t('Find','Demo case verdict is YES',()=>A.verdict==='YES');
 t('Find','statementBalance is an existing approved CDE',()=>fs(A,'statementBalance').status==='EXISTING APPROVED (snapshot)');
 t('Find','paymentDueDate is an untagged candidate',()=>fs(A,'paymentDueDate').status==='UNTAGGED CANDIDATE');
 t('Find','customerEmail is sensitive, not a CDE candidate',()=>fs(A,'customerEmail').status==='SENSITIVE / CONTEXT REVIEW'&&!fs(A,'customerEmail').needsCDE);
 t('Find','rewardsNickname has no CDE signal',()=>fs(A,'rewardsNickname').status==='NO CDE SIGNAL');
 t('Find','legacyMinimumPayment is reported outside scope',()=>A.unmatched.length===1&&A.unmatched[0].field==='legacyMinimumPayment');
 t('Find','Display-only scope with complete inventory → NO',()=>run('benign').verdict==='NO');
 t('Find','Ambiguous bare JSON → POTENTIAL, never NO',()=>run('ambiguous').verdict==='POTENTIAL');
 t('Find','Wrong-application inventory is not inherited',()=>fs(run('wrongApp'),'statementBalance').status==='EXISTING TAG NEEDS VERIFICATION');
 t('Find','Duplicate tag → conflicting records',()=>fs(run('duplicate'),'statementBalance').status==='CONFLICTING INVENTORY RECORDS');
 t('Find','Expired approval needs verification',()=>!fs(run('expired'),'statementBalance').approved);
 t('Find','Altered type needs verification',()=>!fs(run('alteredType'),'statementBalance').typeMatch);
 t('Input','Malformed JSON is rejected',()=>{try{analyze('{bad',clone(CONTEXT));return false}catch(e){return /could not be parsed/.test(e.message)}});
 t('Input','Context without a policy pack is rejected',()=>{const c=clone(CONTEXT);delete c.policy_pack;try{analyze(scenario('tagged').input,c);return false}catch(e){return true}});
 t('Input','Input with no fields is rejected',()=>{try{analyze('{}',clone(CONTEXT));return false}catch(e){return /No fields/.test(e.message)}});
 t('Prove','Balance lineage missing → UNKNOWN',()=>ctl(A,'statementBalance','lineage_ref')==='UNKNOWN');
 t('Prove','Balance failed test → FAIL',()=>ctl(A,'statementBalance','dq_pass')==='FAIL');
 t('Prove','Balance evidence 81 days old → FAIL',()=>ctl(A,'statementBalance','tested_at')==='FAIL');
 const R=analyze(scenario('tagged').input,remediatedContext(A));
 t('Prove','Remediation clears every FAIL and UNKNOWN',()=>R.controls.every(r=>r.status==='PASS'));
 t('Prove','Remediation never approves the due-date candidate',()=>fs(R,'paymentDueDate').status==='UNTAGGED CANDIDATE');
 t('Prove','Contract never claims a system update',()=>buildContract(R).real_systems_updated===false&&buildContract(R).status==='proposed_not_approved');
 const split=mlSplit(),M=trainModel(split.train),M2=trainModel(split.train),cmp=mlCompare(M,.5);
 t('ML','Training is deterministic',()=>JSON.stringify(M.weights)===JSON.stringify(M2.weights));
 t('ML','Training loss falls by more than 80%',()=>M.losses[M.losses.length-1]<M.losses[0]*.2);
 t('ML','No evaluation field appears in training data',()=>!mlRows().some(r=>EVAL_SET.some(e=>e[0]===r.name)));
 t('ML','Rules + model catch creditLimit and aprPercent on the 12 fields',()=>['creditLimit','aprPercent'].every(n=>cmp.rows.find(r=>r.field===n).hybrid));
 t('ML','Rules + model add no false candidates on the 12 fields',()=>cmp.hybrid.fp===0&&cmp.hybrid.recall===1);
 t('ML','Score explanation sums exactly to the logit',()=>{const p=predict(M,'creditLimit','Approved credit line');return Math.abs(p.z-(M.bias+p.contributions.reduce((s,c)=>s+c.weight,0)))<1e-9});
 t('ML','One steward label lifts unseen related fields over 0.5',()=>{const m=trainModel(split.train.concat([{...ML_TEACH,weight:3}]));return ML_PROBES.slice(1).every(([n,d])=>predict(M,n,d).p<.5&&predict(m,n,d).p>=.5)});
 const s=scenario('extended'),P=runPipeline(s.input,s.context,M,.5),P0=runPipeline(s.input,s.context,null,.5);
 t('Combined','Model suggests exactly creditLimit and aprPercent in v2.5',()=>P.findings.filter(f=>f.mlSuggested).map(f=>f.field).sort().join()==='aprPercent,creditLimit');
 t('Combined','Verdict is identical with and without the model',()=>P.verdict===P0.verdict&&P.verdict===analyze(s.input,s.context).verdict);
 t('Combined','Model-suggested fields get a readiness check (6 UNKNOWN each)',()=>['creditLimit','aprPercent'].every(n=>P.controls.filter(r=>r.field===n&&r.status==='UNKNOWN').length===6));
 t('Combined','Model never re-flags a field the rules already found',()=>P.findings.every(f=>!(f.mlSuggested&&(f.needsCDE||f.rule))));
 t('Combined','Without a model nothing is model-suggested',()=>!P0.findings.some(f=>f.mlSuggested));
 const J=runJourney(M,.5);
 t('Govern use','Story request before Prove → BLOCKED: READINESS',()=>J.g1.verdict==='BLOCKED: READINESS');
 t('Govern use','Before Prove: balance blocked, due date on hold, creditLimit removed',()=>{const st=n=>J.g1.rows.find(r=>r.field===n).status;return st('statementBalance')==='BLOCKED'&&st('paymentDueDate')==='HOLD'&&st('creditLimit')==='REMOVE'&&st('customerEmail')==='OK'});
 t('Govern use','After remediation + steward review → CONDITIONAL: MINIMISE',()=>J.g2.verdict==='CONDITIONAL: MINIMISE');
 t('Govern use','Minimised request → COMPATIBLE WITH PROFILE',()=>J.g3.verdict==='COMPATIBLE WITH PROFILE'&&J.g3.request.retention_days===30&&!J.g3.request.fields.includes('creditLimit'));
 t('Govern use','Model training stays REVIEW REQUIRED even after Prove',()=>J.g4.verdict==='REVIEW REQUIRED'&&J.g4.issues.some(i=>/model-risk/.test(i)));
 t('Govern use','“Request more context” keeps a candidate on hold',()=>purposeGate(J.a2,[{field:'paymentDueDate',decision:'needs_context'}],{...STORY_REQUEST,fields:['paymentDueDate'],retention_days:30}).verdict==='ON HOLD: STEWARD DECISION');
 t('Govern use','A field outside the assessed scope is UNKNOWN',()=>purposeGate(J.a2,J.review,{...STORY_REQUEST,fields:['accountToken'],retention_days:30}).rows[0].status==='UNKNOWN');
 t('Govern use','No use profiles in context → REVIEW REQUIRED',()=>{const c=clone(J.a2.context);c.use_profiles=[];const a=runPipeline(s.input,c,M,.5);return purposeGate(a,J.review,STORY_REQUEST).verdict==='REVIEW REQUIRED'});
 t('Govern use','The gate never grants access or decides legality',()=>[J.g1,J.g2,J.g3,J.g4].every(g=>g.access_granted===false&&g.legal_compliance_determined===false));
 t('Govern use','Contract carries use profiles to the gate',()=>Array.isArray(J.contract.use_profiles)&&J.contract.use_profiles.length===2);
 const V=valueEstimate(valueDefaults());
 t('Value','Example assumptions: 60 + 240 + 210 = 510 h',()=>V.triage===60&&V.rework===240&&V.reuse===210&&V.hours===510&&V.cost===51000);
 t('Value','No improvement anywhere → zero value',()=>valueEstimate({...valueDefaults(),minWith:3,catchShare:0,reuseWith:6}).hours===0);
 t('Value','Invalid or negative inputs count as zero',()=>valueEstimate({...valueDefaults(),apps:-5,reuseReq:'x'}).hours===0);
 t('Value','Always labelled an estimate, never measured',()=>V.estimate===true&&V.measured===false);
 if(typeof extraSelfChecks==='function')extraSelfChecks(t);
 return results;
}
if(typeof module!=='undefined')module.exports={analyze,scenario,runPipeline,purposeGate,runJourney,trainModel,mlSplit,predict,mlCompare,valueEstimate,valueDefaults,runSelfChecks,STORY_REQUEST,TRAINING_REQUEST};
