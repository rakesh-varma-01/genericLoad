/* ── Input parsers: JSON/OpenAPI (base), YAML (structural subset), SQL (CREATE TABLE / SELECT). ── */
function extractFields(raw){
 const t=String(raw).trim();
 if(t.startsWith('{')||t.startsWith('['))return extractFieldsBase(raw);
 // YAML first: a spec in YAML may mention "select" in a description.
 if(/^\s*[\w"'$\/.-]+\s*:/m.test(t)){
  try{const obj=parseYamlSubset(t);
   if(obj&&typeof obj==='object'&&(obj.openapi||obj.swagger||obj.$schema||/"properties"/.test(JSON.stringify(obj)))){const r=extractFieldsBase(JSON.stringify(obj));r.mode='YAML → '+r.mode;return r}
  }catch(e){/* not structured YAML; fall through */}
 }
 if(/\b(create\s+(or\s+replace\s+)?(temp\w*\s+)?table|select)\b/i.test(t)){
  const f=sqlFields(t);
  if(f.length)return {fields:f,warnings:['SQL parsed: CREATE TABLE columns (with COMMENT or -- comments) and SELECT aliases. Expressions, joins and views are not traced.'],mode:'SQL (CREATE TABLE / SELECT)'};
 }
 return extractFieldsBase(raw);
}

function parseYamlSubset(raw){
 // Block maps, block lists, scalars, quoted strings, inline [a, b], and | / > block scalars. Enough for OpenAPI / JSON Schema.
 const items=[];
 raw.replace(/\t/g,'  ').split(/\r?\n/).forEach(l=>{if(/^\s*(#.*)?$/.test(l)||/^\s*(---|\.\.\.)\s*$/.test(l))return;items.push({indent:l.match(/^ */)[0].length,text:l.trim()})});
 let i=0;
 const unq=s=>{s=s.trim();if(/^".*"$/.test(s)){try{return JSON.parse(s)}catch(e){return s.slice(1,-1)}}if(/^'.*'$/.test(s))return s.slice(1,-1).replace(/''/g,"'");return s};
 const scalar=s=>{
  s=s.trim();if(!/^["']/.test(s))s=s.replace(/\s+#.*$/,'');
  if(s===''||s==='~'||s==='null')return null;
  if(/^(true|false)$/i.test(s))return s.toLowerCase()==='true';
  if(/^-?\d+(\.\d+)?$/.test(s))return Number(s);
  if(/^\[.*\]$/.test(s))return s.slice(1,-1).split(',').map(x=>x.trim()).filter(Boolean).map(scalar);
  return unq(s);
 };
 const isItem=t=>t==='-'||t.startsWith('- ');
 const keyRe=/^("[^"]*"|'[^']*'|[^:"'][^:]*?)\s*:(?:\s+(.*))?$/;
 function block(indent){return isItem(items[i].text)?list(indent):map(indent)}
 function map(indent){
  const obj={};
  while(i<items.length&&items[i].indent===indent&&!isItem(items[i].text)){
   const m=items[i].text.match(keyRe);if(!m)throw new Error('YAML line not understood: '+items[i].text);
   const key=unq(m[1]),rest=m[2];i++;
   if(rest===undefined||rest===''){
    if(i<items.length&&items[i].indent>indent)obj[key]=block(items[i].indent);
    else if(i<items.length&&items[i].indent===indent&&isItem(items[i].text))obj[key]=list(indent);
    else obj[key]=null;
   }else if(/^[|>][-+]?$/.test(rest)){
    const parts=[];while(i<items.length&&items[i].indent>indent){parts.push(items[i].text);i++}
    obj[key]=parts.join(rest[0]==='|'?'\n':' ');
   }else obj[key]=scalar(rest);
  }
  return obj;
 }
 function list(indent){
  const arr=[];
  while(i<items.length&&items[i].indent===indent&&isItem(items[i].text)){
   const rest=items[i].text.replace(/^-\s?/,'');
   if(rest===''){i++;arr.push(i<items.length&&items[i].indent>indent?block(items[i].indent):null)}
   else if(keyRe.test(rest)&&!/^["'[]/.test(rest)){items[i]={indent:indent+2,text:rest};arr.push(map(indent+2))}
   else{i++;arr.push(scalar(rest))}
  }
  return arr;
 }
 if(!items.length)return null;
 const out=block(items[0].indent);
 if(i<items.length)throw new Error('YAML structure not understood near: '+items[i].text);
 return out;
}

function sqlFields(raw){
 const fields=[],seen=new Set(),clean=n=>n.replace(/^["`\[]|["`\]]$/g,'');
 const add=(name,path,type,desc)=>{if(!seen.has(path)){seen.add(path);fields.push({field:name,path,type:type||'unknown',description:desc||'',required:false})}};
 const splitTop=s=>{const out=[];let depth=0,q=null,cur='';for(const ch of s){if(q){cur+=ch;if(ch===q)q=null;continue}if(ch==="'"||ch==='"'){q=ch;cur+=ch;continue}if(ch==='(')depth++;if(ch===')')depth--;if(ch===','&&depth===0){out.push(cur);cur=''}else cur+=ch}if(cur.trim())out.push(cur);return out};
 const firstIdent=s=>{const m=s.trim().match(/^("[^"]+"|`[^`]+`|\[[^\]]+\]|\w+)/);return m?clean(m[1]):null};
 const comments={};
 for(const m of raw.matchAll(/comment\s+on\s+column\s+([\w."`\[\]]+)\s+is\s+'((?:[^']|'')*)'/gi))comments[clean(m[1].split('.').pop()).toLowerCase()]=m[2].replace(/''/g,"'");
 for(const m of raw.matchAll(/create\s+(?:or\s+replace\s+)?(?:temp\w*\s+)?table\s+(?:if\s+not\s+exists\s+)?([\w."`\[\]]+)\s*\(/gi)){
  const table=clean(m[1].split('.').pop());
  let j=m.index+m[0].length,depth=1;const start=j;
  while(j<raw.length&&depth){if(raw[j]==='(')depth++;else if(raw[j]===')')depth--;j++}
  const body=raw.slice(start,j-1),lineNotes={};
  // A trailing "-- note" describes the column defined on that line (commas inside notes must not split columns).
  body.split(/\r?\n/).forEach(line=>{const c=line.match(/--\s*(.*)$/);const id=firstIdent(line.replace(/--.*$/,''));if(c&&id)lineNotes[id.toLowerCase()]=c[1].trim()});
  for(const part of splitTop(body.replace(/--.*$/gm,''))){
   const def=part.trim();if(!def||/^(primary|constraint|foreign|unique|key|index|check)\b/i.test(def))continue;
   const tm=def.match(/^("[^"]+"|`[^`]+`|\[[^\]]+\]|\w+)\s+(\w+(?:\s*\([^)]*\))?)/);if(!tm)continue;
   const col=clean(tm[1]),cm=def.match(/comment\s+'((?:[^']|'')*)'/i);
   add(col,table+'.'+col,tm[2].toLowerCase().replace(/\s+/g,''),(cm&&cm[1].replace(/''/g,"'"))||lineNotes[col.toLowerCase()]||comments[col.toLowerCase()]||'');
  }
 }
 for(const m of raw.matchAll(/\bselect\b([\s\S]*?)\bfrom\b/gi)){
  const lineNotes={};
  m[1].split(/\r?\n/).forEach(line=>{const c=line.match(/--\s*(.*)$/);if(!c)return;const e=line.replace(/--.*$/,'').replace(/,\s*$/,'').trim();const am=e.match(/\bas\s+("[^"]+"|`[^`]+`|\w+)\s*$/i)||e.match(/("[^"]+"|`[^`]+`|\w+)\s*$/);if(am)lineNotes[clean(am[1]).toLowerCase()]=c[1].trim()});
  for(const part of splitTop(m[1].replace(/--.*$/gm,''))){
   const e=part.trim();if(!e||e==='*'||/\.\*$/.test(e))continue;
   const am=e.match(/\bas\s+("[^"]+"|`[^`]+`|\w+)\s*$/i)||e.match(/(?:^|[\s.])("[^"]+"|`[^`]+`|\w+)\s*$/);if(!am)continue;
   const col=clean(am[1]);if(/^\d+$/.test(col))continue;
   add(col,'select.'+col,'unverified',lineNotes[col.toLowerCase()]||comments[col.toLowerCase()]||'');
  }
 }
 return fields;
}

const SAMPLE_YAML=`openapi: 3.0.3
info:
  title: Northstar Card Billing
  version: 2.5.0
paths:
  /statements:
    get:
      responses:
        '200':
          description: Synthetic statement
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/Statement'
components:
  schemas:
    Statement:
      type: object
      required: [statementBalance, paymentDueDate]
      properties:
        statementBalance:
          type: number
          description: USD amount owed at statement close; authoritative input to autopay.
        paymentDueDate:
          type: string
          format: date
          description: Payment deadline drives late fee and delinquency decisions.
        customerEmail:
          type: string
          format: email
          description: Optional servicing contact; use for reminder notices only.
        rewardsNickname:
          type: string
          description: Display-only label; no effect on billing or credit decisions.
        creditLimit:
          type: number
          description: Approved credit line used in utilization and authorization
        aprPercent:
          type: number
          description: Annual percentage rate applied to purchases
        hardshipProgramCode:
          type: string
          description: Hardship program assigned to the account
        cardArtId:
          type: string
          description: Card design image identifier; display-only
        lastLoginAt:
          type: string
          format: date-time
          description: Time of the most recent app sign-in
`;
const SAMPLE_SQL=`-- Card statement table proposed for the billing service (synthetic)
CREATE TABLE card_statement (
  account_token      VARCHAR(32)   NOT NULL,  -- Tokenised account reference
  statement_balance  NUMERIC(12,2) NOT NULL,  -- USD amount owed at statement close; input to autopay
  payment_due_date   DATE          NOT NULL,  -- Payment deadline that drives late fees and delinquency
  credit_limit       NUMERIC(12,2),           -- Approved credit line used in utilization and authorization
  apr_percent        NUMERIC(5,2),            -- Annual percentage rate applied to purchases
  customer_email     VARCHAR(254),            -- Servicing contact for reminder notices
  card_art_id        VARCHAR(40),             -- Card design image identifier; display-only
  last_login_at      TIMESTAMP,               -- Time of the most recent app sign-in
  PRIMARY KEY (account_token)
);
`;
