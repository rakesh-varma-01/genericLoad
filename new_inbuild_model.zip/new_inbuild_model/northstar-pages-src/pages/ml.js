/* ML Candidate Model page. */
buildNav([
 ['Story',[['overview','00','Overview'],['how','?','How it works'],['data','≡','Training data']]],
 ['Live demo',[['train','1','Train & compare'],['explain','2','Explain a score'],['learn','3','Learn from stewards'],['apply','4','Apply to a spec']]],
 ['MVP',[['mvp','◇','Scope & delivery'],['deps','§','Data, files & model card'],['present','★','Presenting'],['checks','⚙','Self-checks']]]]);
CHECK_AREAS=['ML','Combined'];
let mlModel=null,mlBase=null,mlFeedback=[],mlCurve=null;
const tNow=()=>+$('threshold').value;
function lineChart(vals,o){
 const W=300,H=110,P=18,span=(o.max-o.min)||1;
 const x=i=>P+(W-2*P)*(vals.length<2?0:i/(vals.length-1)),y=v=>H-P-(H-2*P)*((v-o.min)/span);
 const d=vals.map((v,i)=>(i?'L':'M')+x(i).toFixed(1)+' '+y(v).toFixed(1)).join(' ');
 const dots=o.dots?vals.map((v,i)=>'<circle cx="'+x(i).toFixed(1)+'" cy="'+y(v).toFixed(1)+'" r="3" style="fill:var(--accent)"/>').join(''):'';
 const ticks=(o.xticks||[]).map(([i,l])=>'<text x="'+x(i).toFixed(1)+'" y="'+(H-3)+'" text-anchor="middle" style="fill:var(--muted);font:9px var(--mono)">'+esc(l)+'</text>').join('');
 return '<svg viewBox="0 0 '+W+' '+H+'" role="img" aria-label="'+esc(o.label)+'"><line x1="'+P+'" y1="'+(H-P)+'" x2="'+(W-P)+'" y2="'+(H-P)+'" style="stroke:var(--line-2)"/><text x="'+P+'" y="11" style="fill:var(--muted);font:9px var(--mono)">'+esc(o.top)+'</text><path d="'+d+'" fill="none" style="stroke:var(--accent);stroke-width:2"/>'+dots+ticks+'</svg>';
}
function mlTrain(quiet){
 const train=mlSplit().train;
 if(!mlBase)mlBase=trainModel(train);
 if(!mlCurve)mlCurve=mlLearningCurve(.5);
 mlModel=mlFeedback.length?trainModel(train.concat(mlFeedback.map(f=>({...f,weight:3})))):mlBase;
 renderAllML();if(!quiet)toast('Trained on '+mlModel.examples+' examples'+(mlFeedback.length?' incl. '+mlFeedback.length+' steward label(s)':'')+'.');
}
function renderAllML(){renderTrain();renderCompare();renderProbe();renderTop();renderLearn();renderData();if($('applyOut').dataset.ran)applyModel(true)}

/* ═════ Training data tab ═════ */
// Generic words whose weight reflects how the synthetic descriptions are worded, not what makes data critical.
const GENERIC={used:'Describes how a field is used, not what it is; many CDE descriptions happen to say “used in…”.',account:'Nearly every card field relates to an account; it cannot separate critical from non-critical.',card:'Every field in this estate is about a card.',customer:'Customer-facing does not mean non-critical (a customer’s balance is a CDE).',id:'Identifiers can be critical, e.g. an account identifier used in reporting.',identifier:'Identifiers can be critical, e.g. an account identifier used in reporting.',app:'A channel word, not a criticality signal.',shown:'Display wording; a hint at most.',date:'Dates can be critical (due date) or not (last login); the use decides.',code:'Codes can be regulatory or cosmetic.',time:'Timestamps can be critical or not.',last:'Ordinal word with no criticality meaning.',status:'Status fields can drive decisions or not.',amount:'Most amounts are critical, but a strong single-word rule is brittle.'};
let DATA_ROWS=null,FEATURE_COUNTS=null;
function dataRows(){
 if(!DATA_ROWS){const sp=mlSplit();DATA_ROWS=sp.train.map(r=>({...r,split:'train'})).concat(sp.test.map(r=>({...r,split:'holdout'})));
  FEATURE_COUNTS={};sp.train.forEach(r=>mlFeatures(r.name,r.description).forEach(f=>{const c=FEATURE_COUNTS[f]||(FEATURE_COUNTS[f]={cde:0,not:0});c[r.label==='cde'?'cde':'not']++}))}
 return DATA_ROWS.concat(mlFeedback.map(f=>({name:f.name,description:f.description,label:f.label,split:'feedback',source:f.source})));
}
function renderData(){
 if(!mlModel)return;
 const all=dataRows(),t=tNow(),base=all.filter(r=>r.split!=='feedback');
 $('dataMetrics').innerHTML=[[base.length,'labelled rows'],[base.filter(r=>r.label==='cde').length+' / '+base.filter(r=>r.label!=='cde').length,'cde / not_cde'],[base.filter(r=>r.split==='train').length+' / '+base.filter(r=>r.split==='holdout').length,'training / held out'],[mlFeedback.length,'steward labels (×3)']].map(([n,l])=>'<div class="metric"><strong>'+n+'</strong><small>'+l+'</small></div>').join('');
 const q=$('dSearch').value.trim().toLowerCase(),lab=$('dLabel').value,spl=$('dSplit').value,sc=$('dScore').value;
 const rows=all.map(r=>({...r,p:predict(mlModel,r.name,r.description).p})).filter(r=>(!q||(r.name+' '+r.description).toLowerCase().includes(q))&&(!lab||r.label===lab)&&(!spl||r.split===spl)&&(!sc||(sc==='wrong'?(r.p>=t)!==(r.label==='cde'):sc==='near'?Math.abs(r.p-t)<=.15:/no effect|does not affect/i.test(r.description))));
 $('dCount').textContent=rows.length+' of '+all.length+' rows · scores from the current model at threshold '+t.toFixed(2);
 const splitChip={train:'<span class="chip neutral">training</span>',holdout:'<span class="chip info">held out</span>',feedback:'<span class="chip accent">steward ×3</span>'};
 $('dRows').innerHTML=rows.length?rows.map((r,i)=>{const wrong=(r.p>=t)!==(r.label==='cde');return '<tr><td class="mono">'+(i+1)+'</td><td><b class="mono">'+esc(r.name)+'</b></td><td><small>'+esc(r.description||'—')+'</small></td><td>'+(r.label==='cde'?'<span class="chip accent">cde</span>':'<span class="chip neutral">not_cde</span>')+'</td><td>'+splitChip[r.split]+'</td><td class="mono"><span class="pbar"><i style="width:'+(r.p*100).toFixed(0)+'%"></i></span>'+r.p.toFixed(2)+(wrong?' '+chip('DISAGREES'):'')+'</td></tr>'}).join(''):'<tr><td colspan="6" class="muted">No rows match.</td></tr>';
 renderWeights();renderTrace();
}
function renderWeights(){
 const W=Object.entries(mlModel.weights),cnt=f=>(FEATURE_COUNTS&&FEATURE_COUNTS[f])||{cde:0,not:0};
 $('wMeta').textContent=W.length+' features · bias '+mlModel.bias.toFixed(2)+' (a field with no known words scores '+(1/(1+Math.exp(-mlModel.bias))).toFixed(2)+')';
 const susp=W.filter(([f,w])=>{const [k,word]=f.split(':');return k!=='cue'&&GENERIC[word]&&Math.abs(w)>=.3}).sort((a,b)=>Math.abs(b[1])-Math.abs(a[1]));
 $('suspRows').innerHTML=susp.length?susp.map(([f,w])=>'<tr><td><code>'+esc(f)+'</code></td><td class="mono '+(w>0?'warn-t':'pass-t')+'"><b>'+(w>0?'+':'')+w.toFixed(2)+'</b></td><td class="mono">'+cnt(f).cde+'</td><td class="mono">'+cnt(f).not+'</td><td><small>'+esc(GENERIC[f.split(':')[1]])+'</small></td></tr>').join(''):'<tr><td colspan="5" class="muted">None above |0.30|.</td></tr>';
 const q=$('wSearch').value.trim().toLowerCase(),kind=$('wKind').value,sort=$('wSort').value;
 const list=W.filter(([f])=>(!q||f.toLowerCase().includes(q))&&(!kind||f.startsWith(kind+':'))).sort((a,b)=>sort==='pos'?b[1]-a[1]:sort==='neg'?a[1]-b[1]:Math.abs(b[1])-Math.abs(a[1]));
 $('wCount').textContent=list.length+' feature(s)'+(list.length>150?' · showing the first 150':'');
 $('wRows').innerHTML=list.slice(0,150).map(([f,w])=>{const [k,word]=f.split(':');return '<tr><td><code>'+esc(f)+'</code>'+(k!=='cue'&&GENERIC[word]&&Math.abs(w)>=.3?' '+chip('SUSPICIOUS'):'')+'</td><td><small>'+({cue:'domain cue',name:'name word',word:'any word'})[k]+'</small></td><td class="mono '+(w>0?'warn-t':'pass-t')+'">'+(w>0?'+':'')+w.toFixed(2)+'</td><td class="mono">'+cnt(f).cde+'</td><td class="mono">'+cnt(f).not+'</td></tr>'}).join('');
}
function renderTrace(){
 const s=scenario('extended'),a=runPipeline(s.input,s.context,mlModel,tNow());
 if(!$('traceField').options.length)$('traceField').innerHTML=a.findings.map(f=>'<option'+(f.field==='creditLimit'?' selected':'')+'>'+esc(f.field)+'</option>').join('');
 const f=a.findings.find(x=>x.field===$('traceField').value)||a.findings[0],a0=runPipeline(s.input,s.context,null,tNow());
 const ctl=a.controls.filter(r=>r.field===f.field),k=st=>ctl.filter(r=>r.status===st).length;
 const prof=(s.context.use_profiles||[]).find(p=>p.fields.includes(f.field));
 const g=purposeGate(a,[],{purpose:prof?prof.purpose:'marketing',fields:[f.field],retention_days:30}).rows[0];
 const step=(on,t,d)=>'<div class="tl'+(on?' on':'')+'"><b>'+t+'</b><small>'+d+'</small></div>';
 $('trace').innerHTML=
  step(true,'1 · Rules + inventory',f.needsCDE||f.rule?esc(f.status.toLowerCase())+' — '+esc(f.rule?f.rule.reason:'inventory match'):'No rules signal. The project verdict is <b>'+esc(a.verdict)+'</b> with the model and <b>'+esc(a0.verdict)+'</b> without it.')+
  step(f.mlSuggested,'2 · Model',f.needsCDE||f.rule?'Not needed: the rules already put this field on the review list (score '+(f.ml?f.ml.p.toFixed(2):'—')+').':!f.ml||!f.ml.known?'No known words; the model adds nothing. Missing context is still a reason for a human look.':'Score <b>'+f.ml.p.toFixed(2)+'</b> vs threshold '+tNow().toFixed(2)+' → '+(f.mlSuggested?'<b>added to the review list</b>':'not added')+'. Reasons: '+esc(f.ml.why.join(' · ')))+
  step(f.onReviewList,'3 · Prove',ctl.length?ctl.length+' clause checks: '+k('PASS')+' pass, '+k('FAIL')+' fail, '+k('UNKNOWN')+' unknown.':f.onReviewList?'Sensitivity review, not a CDE clause check.':'Not on the review list, so not checked.')+
  step(f.onReviewList,'4 · Steward',f.onReviewList?'Decision pending. Nominate → CDE label for the model; no nomination → not_cde label; request context → no label.':'Nothing to decide.')+
  step(g.status!=='OK','5 · Purpose Gate','A '+esc(prof?prof.label.toLowerCase():'marketing')+' request for this field today: '+chip(g.status)+' '+esc(g.reason));
}
['dSearch','dLabel','dSplit','dScore'].forEach(id=>$(id).addEventListener('input',renderData));
['wSearch','wKind','wSort'].forEach(id=>$(id).addEventListener('input',renderWeights));
$('traceField').addEventListener('change',renderTrace);
function downloadData(){
 const rows=dataRows(),q=s=>'"'+String(s).replace(/"/g,'""')+'"';
 download('ml-training-data.csv',['name,description,label,split,model_score'].concat(rows.map(r=>[q(r.name),q(r.description),r.label,r.split,mlModel?predict(mlModel,r.name,r.description).p.toFixed(3):''].join(','))).join('\n'),'text/csv');
}
function renderTrain(){
 const {train,test}=mlSplit();$('dataMeta').textContent=train.length+' training · '+test.length+' holdout · '+mlFeedback.length+' steward label(s)';
 if(!mlModel){$('mlStatus').textContent='Not trained';return}
 $('mlStatus').textContent=(mlModel.imported?'Imported · '+mlModel.imported:'Trained')+' · '+Object.keys(mlModel.weights).length+' features';$('mlStatus').className='chip pass';
 const L=mlModel.losses||[];
 $('mlLoss').innerHTML=L.length>1?lineChart(L,{min:0,max:Math.max(...L),label:'Training loss by epoch',top:'log-loss '+L[0].toFixed(2)+' → '+L[L.length-1].toFixed(3),xticks:[[0,'0'],[L.length-1,String(L.length)]]}):'No loss history in the imported file';
 $('mlCurve').innerHTML=lineChart(mlCurve.map(c=>c.f1),{min:0,max:1,dots:true,label:'Holdout F1 by training size',top:'F1 · training examples →',xticks:mlCurve.map((c,i)=>[i,String(c.k)])});
 const h=mlHoldout(mlModel,tNow());
 $('holdoutMetrics').innerHTML=[[pct(h.accuracy),'accuracy'],[pct(h.precision),'precision'],[pct(h.recall),'recall'],[h.f1.toFixed(2),'F1']].map(([n,l])=>'<div class="metric"><strong>'+n+'</strong><small>'+l+'</small></div>').join('');
 $('confusion').innerHTML='<div class="tbl-wrap"><table style="min-width:0"><thead><tr><th></th><th>Predicted CDE</th><th>Predicted not</th></tr></thead><tbody><tr><td><b>Labelled CDE</b></td><td>'+h.tp+'</td><td>'+h.fn+'</td></tr><tr><td><b>Labelled not</b></td><td>'+h.fp+'</td><td>'+h.tn+'</td></tr></tbody></table></div>';
}
function renderCompare(){
 $('tVal').textContent=tNow().toFixed(2);if(!mlModel)return;
 const c=mlCompare(mlModel,tNow()),added=c.rows.filter(r=>r.hybrid&&!r.rules);
 $('compareMetrics').innerHTML=[[pct(c.rules.recall),'recall · rules only'],[pct(c.hybrid.recall),'recall · rules + model'],[pct(c.hybrid.precision),'precision · rules + model'],[added.length,'fields added by the model']].map(([n,l])=>'<div class="metric"><strong>'+n+'</strong><small>'+l+'</small></div>').join('');
 $('compareRows').innerHTML=c.rows.map(r=>'<tr><td class="mono"><b>'+esc(r.field)+'</b>'+(r.hybrid&&!r.rules?' <span class="chip indigo">added by model</span>':'')+'<br><small class="muted" style="font-family:var(--sans)">'+esc(r.description)+'</small></td><td>'+(r.label==='cde'?'<span class="chip accent">CDE</span>':'<span class="chip neutral">not CDE</span>')+'</td><td>'+(r.rules?'candidate':'<span class="muted">—</span>')+'</td><td class="mono"><span class="pbar"><i style="width:'+(r.p*100).toFixed(0)+'%"></i></span>'+r.p.toFixed(2)+'</td><td>'+(r.hybrid?'candidate':'<span class="muted">—</span>')+'</td></tr>').join('');
 $('ovRules').textContent=pct(c.rules.recall);$('ovHybrid').textContent=pct(c.hybrid.recall);$('ovFp').textContent=c.hybrid.fp;
}
$('threshold').addEventListener('input',renderAllML);
const featureLabel=k=>{const [kind,w]=k.split(':');return kind==='cue'?'cue · '+w:kind==='name'?'name word “'+w+'”':'word “'+w+'”'};
function renderProbe(){
 if(!mlModel){$('probeOut').innerHTML='<div class="empty">Train the model first.</div>';return}
 const pr=predict(mlModel,$('probeName').value,$('probeDesc').value),t=tNow(),top=pr.contributions.slice(0,8);
 $('probeOut').innerHTML='<div class="row between"><h2>Score</h2>'+(pr.contributions.length?pr.p>=t?chip('SUGGEST REVIEW'):'<span class="chip neutral">Below threshold</span>':'<span class="chip neutral">No known words</span>')+'</div><div class="verdict mt" style="color:var(--accent)">'+pr.p.toFixed(2)+'</div><div class="bar mt"><i style="width:'+(pr.p*100).toFixed(0)+'%"></i></div><div class="field-label">Top contributions (log-odds)</div>'+
  (top.length?top.map(c=>'<div class="contrib"><span>'+esc(featureLabel(c.feature))+'</span><b class="'+(c.weight>0?'warn-t':'pass-t')+'">'+(c.weight>0?'+':'')+c.weight.toFixed(2)+'</b></div>').join(''):'<p class="small">No known words, so the score is just the bias. Missing context is a reason for review, not for comfort.</p>')+
  '<div class="contrib"><span>bias</span><b>'+(mlModel.bias>0?'+':'')+mlModel.bias.toFixed(2)+'</b></div><p class="small mt">Score = σ(bias + Σ weights) = σ('+pr.z.toFixed(2)+').</p>';
}
['probeName','probeDesc'].forEach(id=>$(id).addEventListener('input',renderProbe));
$('presets').innerHTML=[['creditLimit','Approved credit line used in utilization and authorization'],['aprPercent','Annual percentage rate applied to purchases'],['rewardsNickname','Display-only label; no effect on billing or credit decisions.'],['hardshipProgramCode','Hardship program assigned to the account'],['lastLoginAt','Time of the most recent app sign-in'],['field_a','']].map(([n,d])=>'<button class="btn sm" data-probe="'+esc(n)+'" data-desc="'+esc(d)+'">'+esc(n)+'</button>').join('');
$('presets').addEventListener('click',e=>{const b=e.target.closest('[data-probe]');if(!b)return;$('probeName').value=b.dataset.probe;$('probeDesc').value=b.dataset.desc;renderProbe()});
function renderTop(){
 if(!mlModel)return;const w=Object.entries(mlModel.weights).sort((a,b)=>b[1]-a[1]);
 const row=([k,v])=>'<div class="contrib"><span>'+esc(featureLabel(k))+'</span><b class="'+(v>0?'warn-t':'pass-t')+'">'+(v>0?'+':'')+v.toFixed(2)+'</b></div>';
 $('topPos').innerHTML=w.slice(0,10).map(row).join('');$('topNeg').innerHTML=w.slice(-10).reverse().map(row).join('');
}
function renderLearn(){
 $('feedbackRows').innerHTML=mlFeedback.length?mlFeedback.map(f=>'<tr><td>'+(f.label==='cde'?'<span class="chip accent">CDE</span>':'<span class="chip neutral">not CDE</span>')+'</td><td class="mono">'+esc(f.name)+'</td><td>'+esc(f.source)+'</td></tr>').join(''):'<tr><td colspan="3" class="muted">No steward labels yet.</td></tr>';
 if(!mlModel||!mlBase){$('learnRows').innerHTML='<tr><td colspan="3" class="muted">Train first.</td></tr>';return}
 const t=tNow();
 $('learnRows').innerHTML=ML_PROBES.map(([n,d],i)=>{const b=predict(mlBase,n,d).p,a=predict(mlModel,n,d).p,up=a>=t&&b<t;return '<tr><td class="mono"><b>'+esc(n)+'</b> '+(i===0?'<span class="chip accent">taught</span>':'<span class="chip neutral">unseen</span>')+'<br><small class="muted" style="font-family:var(--sans)">'+esc(d)+'</small></td><td class="mono">'+b.toFixed(2)+'</td><td class="mono'+(up?' pass-t':'')+'"><b>'+a.toFixed(2)+'</b>'+(up?' ↑ crosses '+t.toFixed(2):'')+'</td></tr>'}).join('');
 $('learnNote').textContent=mlFeedback.length?(mlModel===mlBase?'Labels recorded — press Retrain.':'Weights are shared across words, so one decision about hardship plans moves related fields the model has never seen.'):'No steward feedback yet: before and after are the same model.';
}
function mlTeach(){mlFeedback=mlFeedback.filter(x=>x.name!==ML_TEACH.name);mlFeedback.push({...ML_TEACH,source:'Steward (demo)'});renderLearn();toast('Label recorded. Retrain to learn from it.')}
function mlClear(){mlFeedback=[];mlModel=mlBase;renderAllML()}
$('labelFile').onchange=async e=>{
 const file=e.target.files[0];e.target.value='';if(!file)return;
 try{const j=JSON.parse(await file.text());const list=Array.isArray(j)?j:j.ml_training_labels;
  if(!Array.isArray(list))throw new Error('No ml_training_labels array found.');
  const ok=list.filter(l=>l&&typeof l.name==='string'&&(l.label==='cde'||l.label==='not_cde')).slice(0,500);
  ok.forEach(l=>{mlFeedback=mlFeedback.filter(x=>x.name!==l.name);mlFeedback.push({name:l.name,description:String(l.description||''),label:l.label,source:'Radar export'})});
  renderLearn();toast(ok.length+' label(s) imported. Retrain to learn from them.');
 }catch(err){toast('Import failed: '+err.message)}
};
function mlExport(){if(!mlModel){toast('Train first.');return}download('cde-candidate-model.json',JSON.stringify({format:'northstar-cde-candidate-model',format_version:1,tokenizer:'v1',model:'logistic regression (bag of words + domain cues)',bias:mlModel.bias,weights:mlModel.weights,losses:mlModel.losses,threshold:tNow(),training:{examples:mlModel.examples,source:mlModel.imported?'imported: '+mlModel.imported:'built-in synthetic set'},steward_feedback:mlFeedback,intended_use:'Suggest additional CDE candidates for steward review only',never_used_for:['verdicts','policy results','reuse decisions','catalog designation'],synthetic:true},null,2))}
$('mlImportFile').onchange=async e=>{
 const file=e.target.files[0];e.target.value='';if(!file)return;
 try{
  if(file.size>2000000)throw new Error('Model file is larger than 2 MB.');
  const m=JSON.parse(await file.text());
  if(m.format!=='northstar-cde-candidate-model')throw new Error('Not a Northstar CDE candidate model.');
  if(m.tokenizer!=='v1')throw new Error('Model uses tokenizer '+m.tokenizer+'; this page supports v1.');
  if(!Number.isFinite(m.bias)||!m.weights||typeof m.weights!=='object'||Object.values(m.weights).some(w=>!Number.isFinite(w)))throw new Error('Model bias or weights are not numeric.');
  if(!mlCurve)mlCurve=mlLearningCurve(.5);
  mlModel=mlBase={weights:m.weights,bias:m.bias,losses:Array.isArray(m.losses)?m.losses:[],examples:(m.training&&m.training.examples)||0,imported:file.name};mlFeedback=[];
  if(Number.isFinite(m.threshold))$('threshold').value=Math.min(.9,Math.max(.3,Math.round(m.threshold/.05)*.05));
  renderAllML();toast('Imported '+file.name+' · threshold '+tNow().toFixed(2));
 }catch(err){toast('Import failed: '+err.message)}
};

/* Apply to a spec: rules alone vs rules + model on the same spec. */
function loadSpec(id){$('specInput').value=scenario(id).input;delete $('applyOut').dataset.ran;$('applyOut').innerHTML=''}
function applyModel(quiet){
 if(!mlModel){toast('Train the model first.');return}
 let a,a0;try{const ctx=scenario('tagged').context;a=runPipeline($('specInput').value,ctx,mlModel,tNow());a0=runPipeline($('specInput').value,ctx,null,tNow())}catch(e){$('applyOut').innerHTML='<div class="notice fail">'+esc(e.message)+'</div>';return}
 $('applyOut').dataset.ran='1';
 const added=a.findings.filter(f=>f.mlSuggested);
 $('applyOut').innerHTML='<div class="grid g4">'+[[a0.verdict,'verdict · rules only'],[a.verdict,'verdict · rules + model'],[a0.findings.filter(f=>f.onReviewList).length,'review list · rules only'],[a.findings.filter(f=>f.onReviewList).length,'review list · rules + model']].map(([n,l])=>'<div class="metric"><strong>'+esc(n)+'</strong><small>'+l+'</small></div>').join('')+'</div>'+
  '<div class="notice '+(a.verdict===a0.verdict?'pass':'fail')+' mt"><b>'+(a.verdict===a0.verdict?'Verdict unchanged by the model.':'Verdict changed — this must never happen.')+'</b> The model added '+(added.length?added.map(f=>'<code>'+esc(f.field)+'</code>').join(', '):'no fields')+' to the review list; each now gets Radar’s readiness check ('+a.controls.filter(r=>added.some(f=>f.field===r.field)).length+' clause results).</div>'+
  '<div class="tbl-wrap mt"><table><thead><tr><th>Field</th><th>Rules</th><th>Model score · top reasons</th><th>Effect</th></tr></thead><tbody>'+a.findings.map(f=>{
   const eff=f.needsCDE?'Already on the list (rules)':f.rule?'On the list (sensitivity rule)':f.mlSuggested?'<b>Added by the model</b>':!f.ml||!f.ml.known?'No known words':'Below threshold';
   return '<tr><td><b class="mono">'+esc(f.field)+'</b><br><small class="muted">'+esc(f.description||'')+'</small></td><td>'+(f.needsCDE||f.rule?chip(f.status):'<span class="muted">No signal</span>')+'</td><td>'+(f.ml&&f.ml.known?'<span class="pbar"><i style="width:'+(f.ml.p*100).toFixed(0)+'%"></i></span><b class="mono">'+f.ml.p.toFixed(2)+'</b><br><small class="muted mono">'+esc(f.ml.why.join(' · '))+'</small>':'<span class="muted">—</span>')+'</td><td>'+eff+'</td></tr>'}).join('')+'</tbody></table></div>'+
  '<div class="row mt"><button class="btn sm" onclick="download(\'model-suggestions.json\',JSON.stringify(window.lastSuggestions,null,2))">↓ Model suggestions</button><a class="btn sm" href="northstar_cde_radar_assurance.html">Continue in Radar →</a></div>';
 window.lastSuggestions={model_threshold:tNow(),verdict:a.verdict,verdict_without_model:a0.verdict,suggested:added.map(f=>({field:f.field,path:f.path,score:+f.ml.p.toFixed(3),reasons:f.ml.why})),decision_owner:'data steward'};
 if(!quiet)toast(added.length+' field(s) added to the review list; verdict unchanged.');
}

PITCH=[[0,15,'The gap','“Rules only find what they were written for. On our 12 test fields they missed the credit limit and the APR.”'],
 [15,35,'Train and explain','Train in the browser; rules + model catch both with no false candidates. Open a score: “credit line” and “authorization” pushed it up.'],
 [35,50,'It learns','One steward labels a hardship field; retrain; two related fields the model has never seen now cross the threshold.'],
 [50,60,'Guardrail','Apply it to the v2.5 spec: two fields added to the review list, verdict unchanged. It suggests; stewards decide.']];
renderPitch();
renderQA([
 ['Why a linear model instead of an LLM?','It is deterministic, cheap to run on every field, and every score decomposes into word weights a validator can read. An approved LLM may explain a suggestion in prose; it never produces the score.'],
 ['Isn’t the 100% recall on 12 fields meaningless?','It is an illustration on invented examples. The notebook evaluates on whole concepts held out of training (about 0.98 recall, 0.82 precision there), and the pilot measures it on real steward labels.'],
 ['What stops the model from approving data?','Structurally: it can only add fields to the review list. Verdicts, policy results and reuse decisions do not read its score — and a self-check proves the verdict is identical with and without it.'],
 ['How does it handle abbreviations like “amt” or “bal”?','Weakly — it is word-based. The notebook compares a character n-gram model that handles them better but is harder to explain; that is a deliberate trade-off.'],
 ['What does model governance look like?','A model card ships with the JSON. Before production: real labels across applications, an out-of-application test set, drift monitoring and independent validation.']]);

DEMO=[
 {view:'overview',title:'The gap',text:'Rules find only what they name. The model widens discovery — and only suggests.',act:()=>{}},
 {view:'train',title:'Train and compare',text:'Rules alone catch 71% of CDEs on 12 test fields; rules + model catch 100% with no false candidates.',act:()=>{mlTrain(true);setTimeout(()=>$('compareAnchor').scrollIntoView({behavior:'smooth'}),150)}},
 {view:'explain',title:'Explain a score',text:'creditLimit: the decision cue, “credit” and “authorization” push it up. Every score breaks down like this.',act:()=>{$('probeName').value='creditLimit';$('probeDesc').value='Approved credit line used in utilization and authorization';renderProbe()}},
 {view:'learn',title:'Learn from a steward',text:'One steward label for hardshipPlanFlag, retrain: two unseen hardship fields cross the threshold.',act:()=>{mlTeach();mlTrain(true)}},
 {view:'apply',title:'Apply to the v2.5 spec',text:'The model adds creditLimit and aprPercent to the review list. The project verdict does not change.',act:()=>{mlClear();loadSpec('extended');applyModel()}}];
mlTrain(true);loadSpec('extended');renderChecks();
showView((location.hash||'#overview').slice(1),true);
