/* Data Purpose Gate page. Upstream Radar states are computed by the shared engine. */
buildNav([
 ['Story',[['overview','00','Overview'],['flow','→','Use case']]],
 ['Live demo',[['decide','1','Decide a request'],['profiles','2','Use profiles'],['evaluate','3','Evaluation']]],
 ['MVP',[['mvp','◇','Scope & architecture'],['deps','§','Inputs & outputs'],['present','★','Presenting'],['checks','⚙','Self-checks']]]]);
CHECK_AREAS=['Govern use'];
const DECISION_LABEL={nominate:'Nominate for approval',verify_existing:'Verify existing mapping',not_cde:'No CDE nomination',needs_context:'Request more context'};
// Upstream: Statement API v2.5 through Radar with the built-in candidate model, before and after remediation.
const UP=(()=>{const M=trainModel(mlSplit().train),s=scenario('extended'),before=runPipeline(s.input,s.context,M,.5),after=runPipeline(s.input,remediatedContext(before),M,.5);return {before,after}})();
const STORY_DECISIONS=STORY_REVIEW.map(r=>({...r,rationale:'Demo steward decisions',official_status_changed:false}));
let profiles=clone(CONTEXT.use_profiles),gate=null,reqFields=STORY_REQUEST.fields.slice();
const upstream=(state,rev)=>({a:{...UP[state],context:{...UP[state].context,use_profiles:profiles}},review:rev==='story'?STORY_DECISIONS:[]});
const cur=()=>upstream($('stateSel').value,$('reviewSel').value);

function renderUpstream(){
 const {a,review}=cur(),d=f=>(review.find(r=>r.field===f)||{}).decision;
 $('upRows').innerHTML=a.findings.map(f=>{const gaps=a.controls.filter(r=>r.field===f.field&&r.status!=='PASS').length,checked=a.controls.some(r=>r.field===f.field);
  return '<tr><td><b class="mono">'+esc(f.field)+'</b></td><td>'+(f.mlSuggested?chip('MODEL-SUGGESTED CANDIDATE'):f.needsCDE||f.rule?chip(f.status):'<span class="muted">No signal</span>')+'</td><td>'+(checked?(gaps?chip(gaps+' UNKNOWN/FAIL'):chip('ALL PASS')):'<span class="muted">not checked</span>')+'</td><td>'+(d(f.field)?chip(DECISION_LABEL[d(f.field)].toUpperCase()):(f.needsCDE||f.mlSuggested)&&!f.approved?'<span class="warn-t">pending</span>':'<span class="muted">—</span>')+'</td></tr>'}).join('');
}
$('reqPurpose').innerHTML=PURPOSES.map(p=>'<option value="'+p.id+'">'+esc(p.label)+'</option>').join('');
function renderForm(){
 const {a}=cur();
 $('reqFields').innerHTML=a.findings.map(f=>'<label class="check"><input type="checkbox" data-req="'+esc(f.field)+'"'+(reqFields.includes(f.field)?' checked':'')+'> <span><b class="mono">'+esc(f.field)+'</b> <small class="muted">'+esc(f.mlSuggested?'model-suggested':f.status.toLowerCase())+'</small></span></label>').join('');
 evaluateUse();
}
function currentRequest(){return {requester:$('reqWho').value,purpose:$('reqPurpose').value,fields:[...document.querySelectorAll('[data-req]:checked')].map(x=>x.dataset.req),retention_days:Number($('reqDays').value)}}
function evaluateUse(){
 const {a,review}=cur(),req=currentRequest();reqFields=req.fields;gate=purposeGate(a,review,req);
 const p=profiles.find(x=>x.purpose===req.purpose&&x.status==='approved');
 $('profileBox').className='notice mt '+(p?'info':'warn');
 $('profileBox').innerHTML=p?'<b>Approved profile: '+esc(p.label)+'</b> · owner '+esc(p.owner)+' · up to '+p.max_retention_days+' days<br>Fields: '+p.fields.map(f=>'<code>'+esc(f)+'</code>').join(', ')+'<br><small>Sensitive fields: '+esc(p.protection||'—')+'</small>':'<b>No approved profile for this purpose.</b> The request is routed for review.';
 $('useChip').textContent=gate.verdict;$('useChip').className='chip verdict-chip '+(/BLOCKED/.test(gate.verdict)?'fail':/COMPATIBLE/.test(gate.verdict)?'pass':'warn');
 $('useRoute').innerHTML='<b>Next:</b> '+esc(gate.route);
 $('useIssues').innerHTML=gate.issues.length?'<div class="notice warn mt">'+gate.issues.map(esc).join('<br>')+'</div>':'';
 $('useRows').innerHTML=gate.rows.length?gate.rows.map(r=>'<tr><td><b class="mono">'+esc(r.field)+'</b>'+(r.cde?' <span class="chip accent">CDE</span>':'')+'</td><td>'+chip(r.status)+'</td><td><small>'+esc(r.reason)+'</small></td></tr>').join(''):'<tr><td colspan="3" class="muted">No fields selected.</td></tr>';
 $('minBtn').disabled=!(gate.minimised&&gate.verdict==='CONDITIONAL: MINIMISE');
}
['reqWho','reqPurpose','reqDays'].forEach(id=>$(id).addEventListener('input',evaluateUse));
$('reqFields').addEventListener('change',evaluateUse);
['stateSel','reviewSel'].forEach(id=>$(id).addEventListener('change',()=>{renderUpstream();evaluateUse()}));
function setRequest(r){$('reqWho').value=r.requester;$('reqPurpose').value=r.purpose;$('reqDays').value=r.retention_days;reqFields=r.fields.slice();renderForm()}
function presetRequest(which){setRequest(which==='training'?TRAINING_REQUEST:STORY_REQUEST)}
function applyMinimised(){if(!gate||!gate.minimised)return;setRequest(gate.minimised);toast('Minimised: '+gate.minimised.fields.length+' fields, '+gate.minimised.retention_days+' days.')}
function setUpstream(state,rev){$('stateSel').value=state;$('reviewSel').value=rev;renderUpstream();renderForm()}
function downloadUse(){if(!gate)return;download('purpose-review-packet.json',JSON.stringify({...gate,upstream:{evidence:$('stateSel').value,steward_decisions:cur().review},profile_set:profiles},null,2))}

/* Profiles editor */
function resetProfiles(){profiles=clone(CONTEXT.use_profiles);$('profilesInput').value=JSON.stringify(profiles,null,2);$('profileState').textContent='valid';$('profileState').className='chip pass';refreshAll()}
$('profilesInput').addEventListener('input',()=>{
 try{const p=JSON.parse($('profilesInput').value);
  if(!Array.isArray(p)||p.some(x=>!x||typeof x.purpose!=='string'||!Array.isArray(x.fields)||!Number.isFinite(x.max_retention_days)))throw new Error('Each profile needs purpose, fields[] and max_retention_days.');
  profiles=p;$('profileState').textContent='valid';$('profileState').className='chip pass';refreshAll();
 }catch(e){$('profileState').textContent='invalid: '+e.message.slice(0,60);$('profileState').className='chip fail'}
});
function refreshAll(){renderUpstream();renderForm();renderCases()}

/* Labelled request set: expected outcomes as an owner would label them (synthetic). */
const CASES=[
 ['Billing reminders, 4 fields, 90 days','before','none',STORY_REQUEST,'BLOCKED: READINESS'],
 ['Billing reminders, 4 fields, 90 days','after','none',STORY_REQUEST,'ON HOLD: STEWARD DECISION'],
 ['Billing reminders, 4 fields, 90 days','after','story',STORY_REQUEST,'CONDITIONAL: MINIMISE'],
 ['Billing reminders, minimised, 30 days','after','story',{...STORY_REQUEST,fields:['statementBalance','paymentDueDate','customerEmail'],retention_days:30},'COMPATIBLE WITH PROFILE'],
 ['AI model training','after','story',TRAINING_REQUEST,'REVIEW REQUIRED'],
 ['Marketing segmentation','after','story',{requester:'Marketing',purpose:'marketing',fields:['customerEmail','statementBalance'],retention_days:30},'REVIEW REQUIRED'],
 ['Servicing analytics incl. model-suggested fields','after','none',{requester:'Servicing',purpose:'servicing_analytics',fields:['statementBalance','creditLimit','aprPercent'],retention_days:60},'ON HOLD: STEWARD DECISION'],
 ['Servicing analytics incl. model-suggested fields','after','story',{requester:'Servicing',purpose:'servicing_analytics',fields:['statementBalance','creditLimit','aprPercent'],retention_days:60},'COMPATIBLE WITH PROFILE'],
 ['Billing reminders, email only, 30 days','before','none',{...STORY_REQUEST,fields:['customerEmail'],retention_days:30},'COMPATIBLE WITH PROFILE'],
 ['Servicing analytics asking for email','after','story',{requester:'Servicing',purpose:'servicing_analytics',fields:['statementBalance','customerEmail'],retention_days:60},'CONDITIONAL: MINIMISE']];
function renderCases(){
 const res=CASES.map(([name,st,rv,req,exp])=>{const u=upstream(st,rv),g=purposeGate(u.a,u.review,req);return {name,st,rv,exp,got:g.verdict,ok:g.verdict===exp}});
 const wrongCompat=res.filter(r=>r.got==='COMPATIBLE WITH PROFILE'&&r.exp!=='COMPATIBLE WITH PROFILE').length;
 $('caseMetrics').innerHTML=[[res.filter(r=>r.ok).length+'/'+res.length,'agree with owner outcome'],[wrongCompat,'incorrect “compatible”'],[res.filter(r=>/BLOCKED|HOLD/.test(r.got)).length,'stopped for evidence or steward'],[res.filter(r=>/REVIEW/.test(r.got)).length,'routed to owners']].map(([n,l])=>'<div class="metric"><strong>'+n+'</strong><small>'+l+'</small></div>').join('');
 $('caseRows').innerHTML=res.map((r,i)=>'<tr><td class="mono">'+(i+1)+'</td><td>'+esc(r.name)+'</td><td><small>'+(r.st==='before'?'evidence gaps':'evidence passes')+' · '+(r.rv==='story'?'decisions recorded':'no decisions')+'</small></td><td>'+chip(r.exp)+'</td><td>'+chip(r.got)+'</td><td>'+(r.ok?chip('MATCH'):chip('DIFFERS'))+'</td></tr>').join('');
}

$('flowSteps').innerHTML=[
 ['find','Radar + ML','Statement API v2.5 has been assessed','Balance is an approved CDE with gaps; due date is a candidate; the model suggested creditLimit and aprPercent; email is sensitive.'],
 ['use','Servicing analytics lead','Requests 4 fields for billing reminders, 90 days','BLOCKED: READINESS — the balance has failing evidence; the due date awaits a steward; creditLimit is outside the profile; 90 days exceeds 30.'],
 ['prove','Control owner + steward (in Radar)','Fix the evidence and record decisions','All clauses pass; the due date, credit limit and APR are nominated; email is not a CDE.'],
 ['use','Data Purpose Gate','Re-evaluates the same request','CONDITIONAL: MINIMISE — drop creditLimit, cut retention to 30 days.'],
 ['use','Servicing analytics lead','Accepts the minimised request','COMPATIBLE WITH PROFILE — the data owner runs identity, entitlement and consent checks, then provisions.'],
 ['use','Collections AI team','Requests similar fields to train a model','REVIEW REQUIRED — no approved profile for model training; routed to the owner, policy authority, model-risk and privacy.']].map(([st,who,t,o],i)=>'<div class="jstep static"><div class="n">'+(i+1)+'</div><div><div class="row"><span class="stage '+st+'">'+({find:'Find',prove:'Prove',use:'Govern use'})[st]+'</span><span class="who">'+esc(who)+'</span></div><b>'+esc(t)+'</b><div class="out">'+esc(o)+'</div></div></div>').join('');

PITCH=[[0,15,'The problem','“Data approved for billing gets requested for marketing and model training. A high quality score is not permission.”'],
 [15,35,'Blocked, then conditional','The billing-reminders request is blocked: the balance’s evidence is failing and a candidate awaits a steward. Once Radar clears both, it’s only conditional — drop a field, cut retention.'],
 [35,50,'Compatible, and routed','Apply the minimised request: compatible with the profile, handed to the owner. The model-training request is always routed for review.'],
 [50,60,'Measured','On ten owner-labelled requests: full agreement and zero incorrect “compatible” decisions.']];
renderPitch();
renderQA([
 ['Is this an access-control or legal decision?','No. It checks compatibility with a documented use profile and current evidence, then routes. Identity, entitlements, consent and legality stay with the data owner and policy authority.'],
 ['Where do use profiles come from?','In the pilot, from the data-use register for one domain, agreed with the data owner. Here they are two synthetic profiles you can edit.'],
 ['Why block reuse when the field’s history is good?','The gate checks current evidence for exactly the fields requested. A failed or missing control on a CDE means it is not ready for a new consumer.'],
 ['What about de-identified data for model training?','De-identification alone never establishes a new purpose. Without an approved profile, training is always routed for owner, model-risk and privacy review.'],
 ['What is the most important metric?','Incorrect “compatible” decisions on an owner-labelled request set — the only error that could let data be misused. It is zero on the demo set; the pilot measures it on real requests.']]);

DEMO=[
 {view:'overview',title:'Purpose before reuse',text:'Approved profile, minimum fields, current evidence — or the data does not move.',act:()=>{}},
 {view:'decide',title:'Blocked',text:'Billing reminders with Radar’s evidence still failing: blocked on readiness, held for the steward, creditLimit outside the profile.',act:()=>{setUpstream('before','none');presetRequest('story')}},
 {view:'decide',title:'Radar clears the evidence',text:'Remediation passes, but the steward has not decided: the request is on hold.',act:()=>setUpstream('after','none')},
 {view:'decide',title:'Conditional → compatible',text:'Steward decisions recorded: now conditional. Apply the minimised request: compatible.',act:()=>{setUpstream('after','story');setTimeout(applyMinimised,700)}},
 {view:'decide',title:'Model training',text:'Same fields for AI model training: review required — routed to the owner, policy, model-risk and privacy.',act:()=>presetRequest('training')},
 {view:'evaluate',title:'Measured',text:'Ten owner-labelled requests: full agreement, zero incorrect “compatible”.',act:()=>{}}];
$('profilesInput').value=JSON.stringify(profiles,null,2);
setUpstream('before','none');renderCases();renderChecks();
showView((location.hash||'#overview').slice(1),true);
