/* Shared shell behaviour for the three Northstar MVP pages. */
const $=id=>document.getElementById(id);
const VIEW_NAMES={};
let onViewShown=()=>{};
function buildNav(views){
 views.forEach(([,items])=>items.forEach(([id,,label])=>VIEW_NAMES[id]=label));
 $('sideNav').innerHTML=views.map(([g,items])=>'<div class="nav-group">'+g+'</div>'+items.map(([id,n,label])=>'<button class="nav-btn" data-go="'+id+'"><span class="n">'+n+'</span>'+esc(label)+'</button>').join('')).join('');
 $('mobileNav').innerHTML=views.flatMap(([,items])=>items).map(([id,,label])=>'<button class="btn sm" data-go="'+id+'">'+esc(label)+'</button>').join('');
}
function showView(id,keepScroll){
 if(!VIEW_NAMES[id])id=Object.keys(VIEW_NAMES)[0];
 document.querySelectorAll('.view').forEach(v=>v.classList.toggle('active',v.id===id));
 document.querySelectorAll('.nav-btn').forEach(b=>b.classList.toggle('active',b.dataset.go===id));
 $('crumb').textContent=VIEW_NAMES[id];
 try{history.replaceState(null,'','#'+id)}catch(e){}
 if(!keepScroll)window.scrollTo({top:0,behavior:'smooth'});
 onViewShown(id);
}
document.addEventListener('click',e=>{const g=e.target.closest('[data-go]');if(g){e.preventDefault();showView(g.dataset.go)}});
function toast(msg){const t=$('toast');t.textContent=msg;t.classList.add('show');clearTimeout(toast.h);toast.h=setTimeout(()=>t.classList.remove('show'),2800)}
function download(name,content,type='application/json'){const url=URL.createObjectURL(new Blob([content],{type}));const a=document.createElement('a');a.href=url;a.download=name;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1000);toast('Download requested: '+name)}
function chip(status,extra){
 const s=String(status);let cls='neutral';
 if(/FAIL|CONFLICT|BLOCKED/.test(s))cls='fail';
 else if(/PASS|ALIGNED|APPROVED|COMPATIBLE|^OK$|^YES$|NOMINATE|VERIFY|^TP$|^TN$|MATCH/.test(s))cls='pass';
 else if(/SENSITIVE|EVIDENCE PRESENT|MODEL/.test(s))cls='info';
 else if(/UNKNOWN|REVIEW|CANDIDATE|VERIFICATION|POSSIBLE|POTENTIAL|HOLD|CONDITIONAL|REMOVE|CONTEXT|^FN$|^FP$|DIFFERS/.test(s))cls='warn';
 return '<span class="chip '+cls+(extra?' '+extra:'')+'">'+esc(s)+'</span>';
}
const pct=x=>x===null||x===undefined?'—':Math.round(x*100)+'%';
(function(){let saved=null;try{saved=localStorage.getItem('nsd-theme')}catch(e){}if(saved)document.documentElement.dataset.theme=saved;
 $('themeBtn').onclick=()=>{const cur=document.documentElement.dataset.theme||(matchMedia('(prefers-color-scheme: dark)').matches?'dark':'light');const next=cur==='dark'?'light':'dark';document.documentElement.dataset.theme=next;try{localStorage.setItem('nsd-theme',next)}catch(e){}}})();
let modalOpener=null;
function openModal(eye,title,html){modalOpener=document.activeElement;$('modalEye').textContent=eye;$('modalTitle').textContent=title;$('modalBody').innerHTML=html;$('modal').classList.add('open');$('modal').querySelector('button').focus()}
function closeModal(){$('modal').classList.remove('open');if(modalOpener&&modalOpener.focus)modalOpener.focus()}
$('modal').addEventListener('click',e=>{if(e.target.id==='modal')closeModal()});
document.addEventListener('keydown',e=>{
 if(e.key==='Escape')closeModal();
 if(e.key!=='Tab'||!$('modal').classList.contains('open'))return;
 const nodes=[...$('modal').querySelectorAll('button,a,textarea,select,input')].filter(x=>!x.disabled);if(!nodes.length)return;
 const first=nodes[0],last=nodes[nodes.length-1];
 if(e.shiftKey&&document.activeElement===first){e.preventDefault();last.focus()}else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first.focus()}
});
/* Presenter script for this part, with a timer. */
let PITCH=[],tSec=0,tHandle=null;
const mmss=s=>Math.floor(s/60)+':'+String(s%60).padStart(2,'0');
function renderPitch(){const end=PITCH.length?PITCH[PITCH.length-1][1]:0;$('pitchLine').innerHTML=PITCH.map(([a,b,t,d])=>'<div class="tl '+(tSec>=a&&tSec<b?'on':'')+'"><b>'+mmss(a)+'–'+mmss(b)+' · '+esc(t)+'</b><small>'+esc(d)+'</small></div>').join('');$('timer').textContent=mmss(tSec);$('timer').className='mono'+(tSec>end?' fail-t':'')}
function toggleTimer(){if(tHandle){clearInterval(tHandle);tHandle=null;$('timerBtn').textContent='Resume';return}tHandle=setInterval(()=>{tSec++;renderPitch()},1000);$('timerBtn').textContent='Pause'}
function resetTimer(){clearInterval(tHandle);tHandle=null;tSec=0;$('timerBtn').textContent='Start';renderPitch()}
function renderQA(items){$('qa').innerHTML=items.map(([q,a])=>'<details><summary>'+esc(q)+'</summary><p>'+esc(a)+'</p></details>').join('')}
/* Self-checks: the engine is shared by all pages; each page shows the areas it owns. */
let CHECK_AREAS=[];
function renderChecks(){
 const r=runSelfChecks().filter(x=>CHECK_AREAS.includes(x.area)),ok=r.filter(x=>x.ok).length;
 $('checkRows').innerHTML=r.map((x,i)=>'<tr><td class="mono">'+(i+1)+'</td><td>'+esc(x.area)+'</td><td>'+esc(x.name)+(x.err?'<br><small class="fail-t">'+esc(x.err)+'</small>':'')+'</td><td>'+chip(x.ok?'PASS':'FAIL')+'</td></tr>').join('');
 $('checkSummary').textContent=ok+' / '+r.length+' passing';
 document.querySelectorAll('[data-checks]').forEach(el=>el.textContent=ok+'/'+r.length);
}
/* Guided demo: each page supplies DEMO = [{view,title,text,act}]. */
let DEMO=[],demoAt=0;
function startDemo(){demoAt=0;renderDemoStep()}
function renderDemoStep(){const s=DEMO[demoAt];showView(s.view);$('demoNum').textContent=(demoAt+1)+' / '+DEMO.length;$('demoTitle').textContent=s.title;$('demoText').textContent=s.text;$('demoBar').classList.remove('hidden');s.act()}
function stepDemo(d){if(demoAt+d>=DEMO.length){$('demoBar').classList.add('hidden');toast('Walkthrough complete.');return}demoAt=Math.max(0,demoAt+d);renderDemoStep()}
