/* CDE Radar + Assurance: upload a spec → rules + inventory + pre-trained model → CDE determination → Prove. */
buildNav([
 ['Story',[['overview','00','Overview'],['flow','→','Use case']]],
 ['Live demo',[['find','1','Find CDEs'],['prove','2','Prove readiness']]],
 ['MVP',[['model','ML','Pre-trained model'],['mvp','◇','Scope & architecture'],['deps','§','Inputs & outputs'],['evaluate','✓','Evaluation'],['present','★','Presenting'],['checks','⚙','Self-checks']]]]);
CHECK_AREAS=['Find','Input','Prove','Parsing','Pretrained'];
let current=null,analysis=null,review=[],contract=null,running=false;
let activeModel=PRETRAINED_MODEL;            // the page only ever runs inference with this
const T=()=>activeModel.threshold;
const DECISION_LABEL={nominate:'Nominate for approval',verify_existing:'Verify existing mapping',not_cde:'No CDE nomination',needs_context:'Request more context'};
const decisionOf=f=>(review.find(r=>r.field===f)||{}).decision;
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const plural=(n,w)=>n+' '+w+(n===1?'':'s');

/* ── Input ── */
const SAMPLES=[['json','OpenAPI JSON · v2.5',()=>scenario('extended').input],['yaml','OpenAPI YAML · v2.5',()=>SAMPLE_YAML],['sql','SQL table',()=>SAMPLE_SQL],['demo','Demo case · v2.4',()=>scenario('tagged').input]];
$('sampleBtns').innerHTML=SAMPLES.map(([k,l])=>'<button class="btn sm" data-sample="'+k+'">'+esc(l)+'</button>').join('');
$('sampleBtns').addEventListener('click',e=>{const b=e.target.closest('[data-sample]');if(b)loadSample(b.dataset.sample)});
function loadSample(key){const s=SAMPLES.find(x=>x[0]===key);current=null;$('specInput').value=s[2]();resetContext(true);renderScenarios();invalidate();toast(s[1]+' loaded. Click Find CDEs.')}
function resetContext(quiet){$('contextInput').value=JSON.stringify(CONTEXT,null,2);if(!quiet)invalidate()}
function detectFormat(raw){
 const t=raw.trim();if(!t)return '—';
 if(/^[\[{]/.test(t)){try{const o=JSON.parse(t);return o&&(o.openapi||o.swagger)?'OpenAPI · JSON':o&&(o.$schema||o.properties)?'JSON Schema':'JSON'}catch(e){return 'JSON (not valid yet)'}}
 if(/^\s*(openapi|swagger)\s*:/m.test(t))return 'OpenAPI · YAML';
 if(/\bcreate\s+(or\s+replace\s+)?(temp\w*\s+)?table\b|\bselect\b[\s\S]*\bfrom\b/i.test(t))return 'SQL';
 if(/^\s*[\w"'$\/.-]+\s*:/m.test(t))return 'YAML';
 return 'Text';
}
function renderScenarios(){
 $('scenarioGrid').innerHTML=SCENARIOS.map(s=>'<button class="scn '+(s.group==='Challenge'?'challenge ':'')+(s.id===current?'on':'')+'" data-scn="'+s.id+'"><span class="g">'+s.group+' · expect '+s.expect+'</span><b>'+esc(s.label)+'</b></button>').join('');
 const s=SCENARIOS.find(x=>x.id===current);$('scenarioNote').innerHTML=s?'<b>'+esc(s.label)+'.</b> '+esc(s.desc):'Pick a scenario to load its spec and context.';
}
$('scenarioGrid').addEventListener('click',e=>{const b=e.target.closest('[data-scn]');if(b){loadScenario(b.dataset.scn);runFind()}});
function loadScenario(id){current=id;const s=scenario(id);$('specInput').value=s.input;$('contextInput').value=JSON.stringify(s.context,null,2);renderScenarios();invalidate()}
function invalidate(){
 analysis=null;review=[];contract=null;
 $('charCount').textContent=$('specInput').value.length.toLocaleString()+' chars';$('formatChip').textContent=detectFormat($('specInput').value);
 $('findStatus').textContent='Ready';$('findStatus').className='chip neutral';$('findError').innerHTML='';renderPipeline(-1);renderFind();renderProve();
}
$('specInput').addEventListener('input',invalidate);$('contextInput').addEventListener('input',invalidate);
async function readUpload(file,target){if(!file)return;if(file.size>500000){toast('Demo accepts files up to 500 KB.');return}try{$(target).value=await file.text();if(target==='specInput')current=null;renderScenarios();invalidate();toast(file.name+' loaded locally. Click Find CDEs.')}catch(e){toast('File could not be read.')}}
$('specFile').onchange=e=>{readUpload(e.target.files[0],'specInput');e.target.value=''};$('contextFile').onchange=e=>{readUpload(e.target.files[0],'contextInput');e.target.value=''};

/* ── Background run ── */
const STAGES=['Parse the spec','Discovery rules','Application inventory','Pre-trained ML model','Readiness checks'];
let stageNotes=[];
function renderPipeline(upTo,runningIdx){
 $('pipeline').innerHTML=STAGES.map((s,i)=>{const done=i<=upTo,run=i===runningIdx;return '<div class="tl'+(done?' on':'')+'"><b>'+(done?'✓ ':run?'… ':'')+esc(s)+'</b><small>'+(done?esc(stageNotes[i]||''):run?'running':'waiting')+'</small></div>'}).join('');
}
function stageSummary(a){
 const k=fn=>a.findings.filter(fn).length,cnt=s=>a.controls.filter(r=>r.status===s).length;
 return [plural(a.findings.length,'field')+' · '+a.mode,
  plural(k(f=>f.rule&&f.rule.critical),'candidate signal')+' · '+k(f=>f.rule&&!f.rule.critical)+' sensitive',
  k(f=>f.approved)+' approved · '+k(f=>(f.record&&!f.approved)||f.conflicts.length||f.possible.length)+' to verify · '+a.unmatched.length+' outside scope',
  plural(a.findings.filter(f=>f.ml&&f.ml.known).length,'field')+' scored · '+k(f=>f.mlSuggested)+' added · threshold '+T().toFixed(2),
  plural(a.controls.length,'clause check')+' · '+cnt('FAIL')+' fail · '+cnt('UNKNOWN')+' unknown'];
}
async function runFind(opts){
 opts=opts||{};if(running)return false;
 try{
  const raw=$('specInput').value.trim();if(!raw)throw new Error('Paste or upload a spec first, or pick a sample.');if(raw.length>500000)throw new Error('Input exceeds the 500 KB demo limit.');
  let ctx;try{ctx=JSON.parse($('contextInput').value)}catch(e){throw new Error('Application context is not valid JSON: '+e.message)}
  const t0=performance.now();
  const a=runPipeline(raw,ctx,activeModel,T());
  a.computeMs=performance.now()-t0;a.format=detectFormat(raw);
  stageNotes=stageSummary(a);$('findError').innerHTML='';
  if(!opts.instant){
   running=true;$('findBtn').disabled=true;$('findStatus').textContent='Analyzing…';$('findStatus').className='chip info';
   // The work is already done (a few ms); the reveal shows each stage of the run for the audience.
   for(let i=0;i<STAGES.length;i++){renderPipeline(i-1,i);await sleep(260);}
  }
  analysis=a;review=[];renderPipeline(STAGES.length-1);
  $('findStatus').textContent='Done in '+a.computeMs.toFixed(0)+' ms';$('findStatus').className='chip pass';
  renderFind();renderProve();
  if(!opts.instant&&!opts.noScroll)setTimeout(()=>$('determinationAnchor').scrollIntoView({behavior:'smooth'}),100);
  return true;
 }catch(e){
  analysis=null;renderFind();renderProve();renderPipeline(-1);
  $('findStatus').textContent='Input needs attention';$('findStatus').className='chip fail';$('findError').innerHTML='<div class="notice fail mt">'+esc(e.message)+'</div>';return false;
 }finally{running=false;$('findBtn').disabled=false}
}

/* ── Determination ── */
function determination(f){
 if(f.approved)return {label:'Approved CDE',cls:'pass',source:'Inventory · '+f.record.cde_id};
 if(f.conflicts.length)return {label:'Conflicting tags',cls:'fail',source:'Inventory'};
 if(f.record)return {label:'Tag needs verification',cls:'warn',source:'Inventory'};
 if(f.possible.length)return {label:'Possible inventory match',cls:'warn',source:'Inventory alias'+(f.rule&&f.rule.critical?' + rules':'')};
 if(f.rule&&f.rule.critical)return {label:'CDE candidate',cls:'warn',source:'Rules'};
 if(f.mlSuggested)return {label:'CDE candidate (model)',cls:'info',source:'Pre-trained model'};
 if(f.rule)return {label:'Sensitive · context review',cls:'info',source:'Rules (sensitivity)'};
 return {label:'No CDE signal',cls:'neutral',source:'—'};
}
function kpis(a){
 const k=fn=>a.findings.filter(fn).length,cnt=s=>a.controls.filter(r=>r.status===s).length;
 return {fields:a.findings.length,approved:k(f=>f.approved),rule_candidates:k(f=>f.rule&&f.rule.critical&&!f.record&&!f.conflicts.length&&!f.possible.length),
  model_candidates:k(f=>f.mlSuggested),to_verify:k(f=>(f.record&&!f.approved)||f.conflicts.length>0||(f.possible.length>0&&!f.record)),
  sensitive:k(f=>f.rule&&!f.rule.critical),no_signal:k(f=>!f.onReviewList&&!f.approved&&!f.record&&!f.possible.length),
  outside_scope:a.unmatched.length,review_list:k(f=>f.onReviewList),clause_checks:a.controls.length,clause_fail:cnt('FAIL'),clause_unknown:cnt('UNKNOWN'),
  evidence_strength:a.strength,model_threshold:+T().toFixed(4),compute_ms:+a.computeMs.toFixed(1)};
}
function sentence(a,K){
 const app=a.context.application_id,cand=K.rule_candidates+K.model_candidates+K.to_verify;
 if(a.verdict==='YES')return 'Yes — this spec contains '+plural(K.approved,'approved CDE')+' from the '+app+' inventory'+(cand?', plus '+plural(cand,'more field')+' with CDE signals for a steward to review':'')+'.';
 if(a.verdict==='NO')return 'No — no CDE signal in this scope, and the '+app+' inventory declaration is complete. Reassess when fields or their use change.';
 return cand?'Potentially — no approved CDE matched, but '+plural(cand,'field')+' show CDE signals that need a steward’s decision.':'Potentially — the evidence is incomplete or ambiguous, so a steward should review before this is called clear.';
}
function renderFind(){
 const a=analysis;$('findResults').classList.toggle('hidden',!a);if(!a)return;
 const K=kpis(a);
 $('verdict').textContent=a.verdict;$('verdict').className='verdict '+a.verdict.toLowerCase();
 $('verdictSentence').textContent=sentence(a,K);$('verdictReason').textContent='Why: '+a.reason+' The model can add fields to the review list; it does not change this determination.';
 $('runMeta').textContent=a.format+' · '+plural(K.fields,'field')+' · '+K.compute_ms+' ms · model '+(activeModel.name||'imported')+' (threshold '+T().toFixed(2)+')';
 const tile=(n,l,cls)=>'<div class="metric"'+(cls?' style="border-color:var(--'+cls+')"':'')+'><strong>'+n+'</strong><small>'+l+'</small></div>';
 $('kpis').innerHTML=[[K.fields,'fields scanned'],[K.approved,'approved CDEs (inventory)','pass'],[K.rule_candidates,'CDE candidates · rules','warn'],[K.model_candidates,'CDE candidates · model','info'],[K.to_verify,'tags / aliases to verify','warn'],[K.sensitive,'sensitive · context review'],[K.no_signal,'no CDE signal'],[K.outside_scope,'inventory tags outside scope']].map(x=>tile(...x)).join('');
 $('kpis2').innerHTML=[[K.review_list,'fields on the steward review list'],[K.clause_fail+K.clause_unknown+' / '+K.clause_checks,'readiness gaps (fail + unknown / checks)'],[K.evidence_strength+'/100','evidence strength (heuristic)'],[K.compute_ms+' ms','compute time in your browser']].map(x=>tile(...x)).join('');
 $('findRows').innerHTML=a.findings.map(f=>{
  const d=determination(f);
  const ml=!f.ml?'<span class="muted">—</span>':!f.ml.known?'<span class="muted">no known words</span>':'<span class="pbar"><i style="width:'+(f.ml.p*100).toFixed(0)+'%"></i></span><b class="mono">'+f.ml.p.toFixed(2)+'</b>'+(f.mlSuggested?' <span class="chip info">added</span>':'')+'<br><small class="muted mono">'+esc(f.ml.why.join(' · '))+'</small>';
  const inv=f.approved?esc(f.record.cde_id+' · '+f.record.approval_ref):f.conflicts.length?esc(f.conflicts.join(' vs ')):f.record?esc(f.mappingIssues.join('; ')):f.possible.length?'alias of '+esc(f.possible.map(r=>r.field+' ('+r.cde_id+')').join(', ')):'<span class="muted">not in inventory</span>';
  const next=f.mlSuggested?'Steward assesses this model-suggested candidate.':f.action.what;
  return '<tr><td><b class="mono">'+esc(f.field)+'</b><br><small class="muted">'+esc(f.type)+(f.description?' · '+esc(f.description):'')+'</small></td><td><span class="chip '+d.cls+'">'+esc(d.label)+'</span></td><td><small>'+esc(d.source)+'</small></td><td>'+ml+'</td><td><small>'+inv+'</small></td><td><small>'+esc(next)+'</small></td></tr>';
 }).join('');
 $('unmatched').innerHTML=(a.unmatched.length?a.unmatched.map(r=>'<div class="ev"><div class="row"><b>'+esc(r.field)+'</b>'+chip('REVIEW SCOPE')+'</div><small>'+esc(r.cde_id||'no id')+' · review due '+esc(r.review_due||'—')+'</small></div>').join(''):'<p class="small">All inventory records matched.</p>')+'<p class="small mt">Absence from this spec does not prove a tag is wrong: confirm scope, aliases and retired fields before removal.</p>';
 $('parseNotes').innerHTML='<p class="small"><b>Read as:</b> '+esc(a.mode)+'</p>'+(a.warnings.length?'<div class="notice warn mt">'+a.warnings.map(esc).join('<br>')+'</div>':'<p class="small mt">No parsing limitations for this input.</p>')+'<p class="small mt">JSON and YAML OpenAPI / JSON Schema are parsed fully (local $ref). SQL reads CREATE TABLE columns with COMMENT or -- comments, and SELECT aliases. Fields without a description get weaker evidence.</p>';
}
function downloadReport(){
 if(!analysis){toast('Run Find CDEs first.');return}
 const a=analysis,K=kpis(a);
 download('cde-determination-report.json',JSON.stringify({generated_at:new Date().toISOString(),input:{format:a.format,parsed_as:a.mode,warnings:a.warnings},
  determination:{decision:a.verdict,summary:sentence(a,K),reason:a.reason,evidence_strength:a.strength,decided_by:'discovery rules + application inventory',model_role:'adds candidates to the review list only'},
  kpis:K,model:{name:activeModel.name||'imported',version:activeModel.version||null,threshold:T(),trained_offline_on:activeModel.examples+' rows',source:activeModel.source||null,offline_test:activeModel.metrics?activeModel.metrics.test:null},
  fields:a.findings.map(f=>{const d=determination(f);return {field:f.field,path:f.path,type:f.type,description:f.description,determination:d.label,source:d.source,on_review_list:f.onReviewList,model_score:f.ml?+f.ml.p.toFixed(4):null,model_reasons:f.ml?f.ml.why:[],inventory:f.record?{cde_id:f.record.cde_id,status:f.record.status,issues:f.mappingIssues}:f.possible.length?{possible:f.possible.map(r=>r.cde_id)}:null,next_action:f.mlSuggested?'Steward assesses this model-suggested candidate.':f.action.what}}),
  inventory_outside_scope:a.unmatched,application_id:a.context.application_id,decision_owner:'data steward',official_catalog_updated:false,synthetic_demo:true},null,2));
}

/* ── Prove ── */
function renderProve(){
 const a=analysis,has=!!a;
 $('proveBody').classList.toggle('hidden',!has);$('proveEmpty').classList.toggle('hidden',has);if(!has)return;
 const c=a.context,cnt=s=>a.controls.filter(r=>r.status===s).length,fails=cnt('FAIL'),unk=cnt('UNKNOWN');
 $('proveMeta').textContent=c.application_id+' · inventory '+c.inventory.application_id+' snapshot '+c.inventory.snapshot_date+' · assessed '+c.assessment_date+' · '+a.mode;
 $('proveMetrics').innerHTML=[[cnt('PASS'),'declared PASS'],[fails,'declared FAIL'],[unk,'UNKNOWN / missing'],[review.length,'steward decisions']].map(([n,l])=>'<div class="metric"><strong>'+n+'</strong><small>'+l+'</small></div>').join('');
 const ready=!(fails||unk||!a.packCurrent||!a.scope||!a.fresh);
 $('readiness').className='notice '+(ready?'pass':'warn');
 $('readiness').innerHTML='<b>Readiness: '+(ready?'no declared control gaps in scope':'requires review')+'.</b> A tag is evidence of a past classification, not of working controls. Missing evidence is UNKNOWN.';
 $('proveWarnings').innerHTML=a.warnings.length?'<div class="notice warn mt">'+a.warnings.map(esc).join('<br>')+'</div>':'';
 $('decisionRows').innerHTML=a.findings.filter(f=>f.onReviewList).map(f=>{
  const rows=a.controls.filter(r=>r.field===f.field),k=s=>rows.filter(r=>r.status===s).length,d=decisionOf(f.field);
  const rd=rows.length?'<div class="counts">'+(k('PASS')?'<span class="chip pass">'+k('PASS')+' pass</span>':'')+(k('FAIL')?'<span class="chip fail">'+k('FAIL')+' fail</span>':'')+(k('UNKNOWN')?'<span class="chip warn">'+k('UNKNOWN')+' unknown</span>':'')+'</div>':'<span class="muted">Not a CDE check</span>';
  const st=f.mlSuggested?'<span class="chip info">CDE candidate (model)</span>':chip(f.status);
  const act=f.mlSuggested?{what:'Assess this model-suggested candidate; owner attaches evidence.',who:'Domain steward'}:f.action;
  return '<tr><td><b class="mono">'+esc(f.field)+'</b></td><td>'+st+'</td><td>'+rd+'</td><td>'+(d?chip(DECISION_LABEL[d].toUpperCase()):'<span class="muted">pending</span>')+'</td><td>'+esc(act.what)+'<br><small class="muted">Owner: '+esc(act.who)+'</small></td></tr>';
 }).join('')||'<tr><td colspan="5" class="muted">Nothing on the review list.</td></tr>';
 $('packMeta').textContent=c.policy_pack.source+' · '+c.policy_pack.id+' v'+c.policy_pack.version+' · effective '+c.policy_pack.effective_from+' → review '+c.policy_pack.review_due;
 $('controlRows').innerHTML=a.controls.length?a.controls.map(r=>'<tr><td><b class="mono">'+esc(r.field)+'</b><br><code>'+esc(r.clause)+'</code></td><td>'+esc(r.requirement)+'</td><td>'+chip(r.status)+'</td><td><code>'+esc(r.evidence)+'</code><br><small class="muted">'+esc(r.why)+'</small></td><td>'+esc(r.action)+'</td></tr>').join(''):'<tr><td colspan="5" class="muted">No CDE controls evaluated. This does not certify the project.</td></tr>';
 $('strategyRows').innerHTML=a.strategy.map(s=>'<tr><td>'+esc(s.criterion)+'</td><td>'+chip(s.status)+'</td><td>'+esc(s.evidence)+'<br><small class="muted">'+esc(s.action)+'</small></td></tr>').join('');
 contract=buildContract(a,review);
 contract.model_suggested_fields=a.findings.filter(f=>f.mlSuggested).map(f=>({name:f.field,score:+f.ml.p.toFixed(3),reasons:f.ml.why,model:activeModel.name||'imported'}));
 $('contractPreview').textContent=JSON.stringify(contract,null,2);
}
function remediate(){
 if(!analysis){toast('Run Find CDEs first.');return}
 if(analysis.context.policy_pack.id!=='DEMO-DG'){toast('Automatic remediation works with the synthetic DEMO-DG pack only.');return}
 $('contextInput').value=JSON.stringify(remediatedContext(analysis),null,2);runFind({instant:true});
 toast('Demo evidence attached. Controls improve; candidates are still candidates.');
}
function openReview(){
 if(!analysis){toast('Run Find CDEs first.');return}
 const items=analysis.findings.filter(f=>f.onReviewList);if(!items.length){toast('Nothing on the review list.');return}
 openModal('Local review exercise · no catalog writes','Steward review','<p class="small">Record a recommendation per field. Formal designation stays in the official workflow. Decisions are exported as labels for offline retraining.</p>'+items.map((f,i)=>'<div class="ev mt"><div class="row"><b>'+esc(f.field)+'</b>'+(f.mlSuggested?'<span class="chip info">CDE candidate (model)</span>':chip(f.status))+'</div><div class="row mt"><label for="dec'+i+'" class="small">Decision</label><select class="select" id="dec'+i+'"><option value="needs_context">Request more context</option><option value="nominate"'+((f.needsCDE||f.mlSuggested)&&!f.approved?' selected':'')+'>Nominate for official CDE approval</option>'+(f.approved?'<option value="verify_existing" selected>Verify existing mapping</option>':'')+'<option value="not_cde"'+(!f.needsCDE&&!f.mlSuggested&&f.rule?' selected':'')+'>No CDE nomination</option></select></div></div>').join('')+'<div class="field-label"><label for="reviewWhy">Decision rationale (required)</label></div><textarea id="reviewWhy" class="input" style="width:100%;min-height:80px" placeholder="Business use, reference, ambiguity and owner action"></textarea><div class="row mt"><button class="btn primary" onclick="saveReview()">Record review</button><button class="btn" onclick="applyStoryReview()">Use the demo decisions</button></div>');
}
function saveReview(){
 const why=$('reviewWhy').value.trim();if(!why){toast('Add a decision rationale first.');return}
 const items=analysis.findings.filter(f=>f.onReviewList);
 review=items.map((f,i)=>({field:f.field,path:f.path,decision:$('dec'+i).value,rationale:why,official_status_changed:false}));
 closeModal();renderProve();toast('Review recorded in this session. No official classification changed.');
}
function applyStoryReview(){
 if(!analysis)return;
 review=STORY_REVIEW.filter(r=>analysis.findings.some(f=>f.field===r.field&&f.onReviewList)).map(r=>({...r,path:analysis.findings.find(f=>f.field===r.field).path,rationale:'Demo steward decisions',official_status_changed:false}));
 closeModal();renderProve();toast('Demo decisions recorded.');
}
function downloadContract(){if(!contract){toast('Run Find CDEs first.');return}download('proposed-data-contract.json',JSON.stringify(contract,null,2))}
function downloadEvidence(){
 if(!analysis){toast('Run Find CDEs first.');return}
 const labels=review.filter(r=>r.decision!=='needs_context').map(r=>({name:r.field,description:(analysis.findings.find(f=>f.field===r.field)||{}).description||'',label:r.decision==='not_cde'?'not_cde':'cde',labelled_by:'steward (demo)',labelled_at:analysis.context.assessment_date,application_id:analysis.context.application_id}));
 download('cde-assurance-evidence.json',JSON.stringify({verdict:analysis.verdict,reason:analysis.reason,model:{name:activeModel.name||'imported',threshold:T()},findings:analysis.findings.map(f=>({field:f.field,path:f.path,type:f.type,status:f.status,model_suggested:f.mlSuggested,model_score:f.ml?+f.ml.p.toFixed(4):null,mapping_issues:f.mappingIssues,action:f.action})),controls:analysis.controls,unmatched_inventory:analysis.unmatched,strategy:analysis.strategy,steward_review:review,ml_training_labels:labels,limitations:['Offline rules + pre-trained model','Imported evidence not authenticated','No internal policy validation'],official_catalog_updated:false},null,2));
}

/* ── Pre-trained model view ── */
const featureLabel=k=>{const [kind,w]=k.split(':');return kind==='cue'?'cue · '+w:kind==='name'?'name word “'+w+'”':'word “'+w+'”'};
function renderModelView(){
 const m=activeModel,mt=m.metrics||{},test=mt.test;
 $('modelMetrics').innerHTML=[[Object.keys(m.weights).length,'learned weights'],[T().toFixed(2),'review threshold'],[m.examples||'—','training rows (offline)'],[test?pct(test.precision)+' / '+pct(test.recall):'—','precision / recall on unseen topics']].map(([n,l])=>'<div class="metric"><strong>'+n+'</strong><small>'+l+'</small></div>').join('');
 $('modelInUse').innerHTML='<div class="tbl-wrap"><table style="min-width:0"><tbody><tr><td>File</td><td><code>'+esc(m.name||'imported')+'</code>'+(m===PRETRAINED_MODEL?' <span class="chip pass">embedded</span>':' <span class="chip info">imported</span>')+'</td></tr><tr><td>Trained on</td><td>'+esc(m.source||'—')+'</td></tr><tr><td>Settings</td><td>'+esc(m.hyperparameters?'epochs '+m.hyperparameters.epochs+', lr '+m.hyperparameters.lr+', L2 '+m.hyperparameters.l2:'—')+'</td></tr><tr><td>Threshold</td><td>'+T().toFixed(4)+(m.notes?' · '+esc(m.notes):'')+'</td></tr><tr><td>Bias</td><td class="mono">'+m.bias.toFixed(4)+' (no known words → '+(1/(1+Math.exp(-m.bias))).toFixed(2)+')</td></tr></tbody></table></div>';
 const names={train:'Training topics',val:'Validation topics (threshold chosen here)',test:'Test topics never seen',eval_fields:'12 hand-written evaluation fields',page_set:'123-row page set'};
 $('modelEval').innerHTML=Object.keys(mt).length?Object.entries(mt).map(([k,v])=>'<tr><td>'+esc(names[k]||k)+'</td><td class="mono">'+v.tp+' / '+v.fp+' / '+v.fn+' / '+v.tn+'</td><td>'+pct(v.precision)+'</td><td>'+pct(v.recall)+'</td><td>'+(v.f1!=null?v.f1.toFixed(3):'—')+'</td></tr>').join(''):'<tr><td colspan="5" class="muted">The imported file carries no evaluation metrics.</td></tr>';
 const w=Object.entries(m.weights).sort((a,b)=>b[1]-a[1]),row=([k,v])=>'<div class="contrib"><span>'+esc(featureLabel(k))+'</span><b class="'+(v>0?'warn-t':'pass-t')+'">'+(v>0?'+':'')+v.toFixed(2)+'</b></div>';
 $('topPos').innerHTML=w.slice(0,8).map(row).join('');$('topNeg').innerHTML=w.slice(-8).reverse().map(row).join('');
 renderProbe();
}
function renderProbe(){
 const pr=predict(activeModel,$('probeName').value,$('probeDesc').value);
 $('probeOut').innerHTML='<div class="row between"><span class="verdict" style="font-size:30px;color:var(--accent)">'+pr.p.toFixed(2)+'</span>'+(pr.contributions.length?(pr.p>=T()?'<span class="chip info">would be added to the review list</span>':'<span class="chip neutral">below threshold</span>'):'<span class="chip neutral">no known words</span>')+'</div><div class="bar mt"><i style="width:'+(pr.p*100).toFixed(0)+'%"></i></div>'+
  pr.contributions.slice(0,6).map(c=>'<div class="contrib"><span>'+esc(featureLabel(c.feature))+'</span><b class="'+(c.weight>0?'warn-t':'pass-t')+'">'+(c.weight>0?'+':'')+c.weight.toFixed(2)+'</b></div>').join('')+'<p class="small mt">σ(bias '+activeModel.bias.toFixed(2)+' + Σ weights) = σ('+pr.z.toFixed(2)+'). Rules still run first in Find.</p>';
}
['probeName','probeDesc'].forEach(id=>$(id).addEventListener('input',renderProbe));
$('modelFile').onchange=async e=>{
 const file=e.target.files[0];e.target.value='';if(!file)return;
 try{
  if(file.size>2000000)throw new Error('Model file is larger than 2 MB.');
  const m=JSON.parse(await file.text());
  if(m.format!=='northstar-cde-candidate-model')throw new Error('Not a Northstar CDE candidate model.');
  if(m.tokenizer!=='v1')throw new Error('Model uses tokenizer '+m.tokenizer+'; this page supports v1.');
  if(!Number.isFinite(m.bias)||!m.weights||typeof m.weights!=='object'||Object.values(m.weights).some(w=>!Number.isFinite(w)))throw new Error('Model bias or weights are not numeric.');
  activeModel={name:file.name,bias:m.bias,weights:m.weights,threshold:Number.isFinite(m.threshold)?m.threshold:0.5,examples:(m.training&&m.training.examples)||0,source:m.training&&m.training.source,hyperparameters:m.hyperparameters,metrics:m.metrics,notes:m.notes};
  renderModelView();if(analysis)runFind({instant:true});toast('Now using '+file.name+' · threshold '+T().toFixed(2));
 }catch(err){toast('Import failed: '+err.message)}
};
function useEmbeddedModel(){activeModel=PRETRAINED_MODEL;renderModelView();if(analysis)runFind({instant:true});toast('Using the embedded model.')}
function renderModelBadge(){const t=(PRETRAINED_MODEL.metrics||{}).test;$('modelBadge').innerHTML='<b>Model in background:</b> <code>'+esc(activeModel.name||'imported')+'</code> · trained offline on '+(activeModel.examples||'—')+' rows'+(t&&activeModel===PRETRAINED_MODEL?' · unseen-topic test: precision '+pct(t.precision)+', recall '+pct(t.recall):'')+' · threshold '+T().toFixed(2)+'. Inference only — nothing is trained here. <a href="#model" data-go="model">Details →</a>'}
onViewShown=id=>{if(id==='find')renderModelBadge();if(id==='model')renderModelView()};

/* ── Use case, evaluation, presenting ── */
$('flowSteps').innerHTML=[
 ['find','Project engineer','Uploads the Statement API v2.5 spec (JSON, YAML or the SQL table) and clicks Find CDEs','Parsed into field paths; local $ref schemas resolved; SQL comments become descriptions.'],
 ['find','Rules + inventory','Decide the determination','YES: statementBalance matches DEMO-CDE-042. paymentDueDate is a rule candidate; customerEmail is sensitive only; a legacy tag sits outside the submitted scope.'],
 ['find','Pre-trained model','Scores every field in the background','Adds creditLimit (0.76) and aprPercent (0.95) to the review list with their reasons; scores cardArtId and lastLoginAt near zero. The determination does not change.'],
 ['prove','Assurance','Checks each review-list field clause by clause','Balance: lineage UNKNOWN, last test FAIL, evidence 81 days old. Candidates: owner and quality evidence UNKNOWN.'],
 ['prove','Control owner and steward','Attach evidence; record decisions with a rationale','Every clause passes on rerun. Steward verifies the balance, nominates the candidates, marks email not a CDE. No catalog is written.'],
 ['prove','Everyone','Export the determination report, evidence packet and contract','The contract feeds the Data Purpose Gate; steward decisions become labels for offline retraining.']].map(([st,who,t,o],i)=>'<div class="jstep static"><div class="n">'+(i+1)+'</div><div><div class="row"><span class="stage '+st+'">'+(st==='find'?'Find':'Prove')+'</span><span class="who">'+esc(who)+'</span></div><b>'+esc(t)+'</b><div class="out">'+esc(o)+'</div></div></div>').join('');
(function(){const c=mlCompare(PRETRAINED_MODEL,PRETRAINED_MODEL.threshold);
 $('evalMetrics').innerHTML=[[pct(c.rules.recall),'recall · rules only'],[pct(c.hybrid.recall),'recall · rules + model'],[pct(c.hybrid.precision),'precision · rules + model'],[c.rows.filter(r=>r.hybrid&&!r.rules).length,'fields added by the model']].map(([n,l])=>'<div class="metric"><strong>'+n+'</strong><small>'+l+'</small></div>').join('');
 $('evalRows').innerHTML=c.rows.map(r=>'<tr><td class="mono"><b>'+esc(r.field)+'</b>'+(r.hybrid&&!r.rules?' <span class="chip indigo">added by model</span>':'')+'<br><small class="muted" style="font-family:var(--sans)">'+esc(r.description)+'</small></td><td>'+(r.label==='cde'?'<span class="chip accent">CDE</span>':'<span class="chip neutral">not CDE</span>')+'</td><td>'+(r.rules?'candidate':'<span class="muted">—</span>')+'</td><td class="mono"><span class="pbar"><i style="width:'+(r.p*100).toFixed(0)+'%"></i></span>'+r.p.toFixed(2)+'</td><td>'+(r.hybrid?'candidate':'<span class="muted">—</span>')+'</td></tr>').join('');})();
$('contextPreview').textContent=JSON.stringify(CONTEXT,null,2);
PITCH=[[0,15,'The question','“A team is building a billing API. Does it contain critical data, is it tagged correctly, and is the evidence ready?”'],
 [15,45,'Find CDEs','Upload the spec — JSON, YAML or SQL — and click Find CDEs. Watch the five stages. Determination YES: an approved balance; a due-date candidate from rules; the pre-trained model adds credit limit and APR with its reasons.'],
 [45,60,'The model','“Trained offline on steward-style labels, tested on topics it never saw, embedded here as a versioned file. It suggests; rules decide; a steward signs.”'],
 [60,80,'Prove','The approved balance fails: missing lineage, failed test, stale evidence. Attach evidence, rerun — all pass — and candidates stay candidates until the steward decides.'],
 [80,90,'Hand-off','The report, evidence packet and contract go to the steward and the Purpose Gate; decisions become the next training labels.']];
renderPitch();
renderQA([
 ['Is the model trained in the page?','No. It is trained offline in the northstar-ml-candidate-model repository, evaluated on topics it never saw, and embedded here as a file. The page only runs inference; a newer version can be imported.'],
 ['Can the model make something a CDE?','No. Rules and the application inventory decide the determination; the model can only add fields to the review list. A self-check proves the determination is identical with and without it.'],
 ['Real time or batch?','Both. Inference is a lookup-and-add over a few hundred weights, so a whole spec takes milliseconds in the browser. The same model scores pull requests through the CLI and can run in batch over a catalog.'],
 ['What about YAML and SQL?','OpenAPI and JSON Schema in YAML are parsed structurally, the same as JSON. SQL reads CREATE TABLE columns with their comments and SELECT aliases; expressions and joins are not traced.'],
 ['What if the inventory is wrong?','Four challenge cases — wrong application, duplicate tag, expired approval, changed type — all ask for review instead of inheriting.'],
 ['Why not update the catalog automatically?','Designation authority sits with the steward and the official workflow. Radar prepares the evidence; it never writes.']]);

DEMO=[
 {view:'overview',title:'The question',text:'Does my spec contain critical data elements — and is the evidence ready?',act:()=>{}},
 {view:'find',title:'Find CDEs',text:'Statement API v2.5 as JSON. Click-equivalent: the five stages run, then the determination appears.',act:()=>{loadSample('json');runFind()}},
 {view:'find',title:'The model at work',text:'creditLimit and aprPercent: no rule fired, the pre-trained model added them with reasons. The determination stayed YES.',act:()=>setTimeout(()=>$('findTableAnchor').scrollIntoView({behavior:'smooth'}),150)},
 {view:'find',title:'Same answer from SQL',text:'The equivalent CREATE TABLE: columns and comments parsed; statement_balance is a likely alias of the approved tag; the model flags credit_limit and apr_percent.',act:()=>{loadSample('sql');runFind()}},
 {view:'prove',title:'Prove',text:'Back to v2.5. The approved balance has missing lineage, a failed test and stale evidence; model candidates have no evidence yet.',act:()=>{loadSample('json');runFind({instant:true});setTimeout(()=>$('clauseAnchor').scrollIntoView({behavior:'smooth'}),150)}},
 {view:'prove',title:'Remediate and decide',text:'Attach evidence and record the steward’s decisions. Controls pass; only the steward nominates.',act:()=>{remediate();applyStoryReview();setTimeout(()=>$('decAnchor').scrollIntoView({behavior:'smooth'}),150)}},
 {view:'model',title:'Under the hood',text:'The embedded model: trained offline, tested on unseen topics, every score explained by word weights.',act:()=>{}}];
$('contextInput').value=JSON.stringify(CONTEXT,null,2);
$('specInput').value=scenario('extended').input;
renderScenarios();invalidate();renderModelBadge();renderChecks();
showView((location.hash||'#overview').slice(1),true);
