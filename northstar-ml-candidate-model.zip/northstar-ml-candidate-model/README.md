# Northstar CDE candidate model

An explainable model that reads a field’s **name and description** and suggests whether a data steward should review it as a possible **Critical Data Element (CDE)**. It is part of Northstar (CDE Radar + Assurance → ML Candidate Model → Data Purpose Gate) and powers the *ML Candidate Model* page.

**What it may do:** add a field to the steward’s review list, with the words behind the score.
**What it never does:** designate a CDE, decide a project verdict or policy result, or approve data reuse.

> All training data in this repository is **synthetic**: hand-written or generated to imitate steward judgement on a card-billing estate. No real or bank data is included. Scores show that the method works, not production accuracy.

## Repository layout

```
northstar-ml-candidate-model/
├── src/northstar_cde/          # standard library only
│   ├── features.py             # tokenizer v1: words, name words, 5 domain cues
│   ├── model.py                # logistic regression, gradient descent from scratch, save/load
│   ├── data.py                 # CSV I/O, interleaved split, grouped split
│   ├── generate.py             # synthetic dataset generator (26 topics)
│   ├── evaluate.py             # precision/recall/F1, average precision, ROC AUC, threshold choice
│   ├── rules.py                # the deterministic discovery rules the model complements
│   ├── scan.py                 # score the fields of an OpenAPI / JSON Schema file
│   └── cli.py                  # python -m northstar_cde …
├── data/
│   ├── raw/page_labelled_fields.csv     # 123 rows — exactly what the browser page trains on
│   ├── raw/eval_fields.csv              # 12 separate evaluation fields
│   ├── raw/steward_feedback_example.csv # one steward label (hardshipPlanFlag)
│   ├── synthetic/generated_fields.csv   # 1,192 generated rows, split by topic
│   ├── templates/labelled_fields_template.csv  # format for real steward labels
│   └── DATA_CARD.md
├── artifacts/
│   ├── page_model.json                  # trained on the 123-row set (importable in the page)
│   ├── generated_model.json             # trained on the generated set, threshold chosen on validation
│   ├── page_model_with_feedback.json    # page set + 1 steward label
│   └── MODEL_CARD.md
├── notebooks/01_train_from_scratch.ipynb  # executed walkthrough with charts
├── tests/                               # 38 tests, incl. exact parity with the browser trainer
│   ├── fixtures/statement-api-v2.4.json, statement-api-v2.5.json
│   └── golden/browser_page_model.json
├── scripts/reproduce.sh                 # regenerate data + artifacts, run tests (no make needed)
├── Makefile, pyproject.toml, requirements-notebook.txt
```

## Quick start

```bash
# Python 3.8+; nothing to install for the package, CLI or tests
PYTHONPATH=src python3 -m northstar_cde predict --model artifacts/page_model.json \
  --name creditLimit --description "Approved credit line used in utilization and authorization"
python3 -m unittest discover -s tests          # 38 tests
scripts/reproduce.sh                           # rebuild data/artifacts and test (same as `make all`)
```

Or install it: `pip install -e .` then use `northstar-cde …`. For the notebook: `pip install -r requirements-notebook.txt`, then `jupyter notebook notebooks/01_train_from_scratch.ipynb`.

On macOS, if `python3` or `make` asks you to accept the Xcode licence, either accept it (`sudo xcodebuild -license`) or use another Python, e.g. `scripts/reproduce.sh /path/to/python`.

## CLI

| Command | What it does |
|---|---|
| `generate --out CSV [--n 1500 --seed 42]` | Write the synthetic dataset with a grouped `split` column |
| `train --data CSV --out JSON [--train-split train --val-split val --test-split test --min-recall 0.95 --eval NAME=CSV --feedback CSV]` | Train from scratch, choose the threshold on validation if given, store metrics in the model file |
| `evaluate --model JSON --data CSV [--split test]` | Metrics as JSON |
| `predict --model JSON --name N --description D` | Score and full explanation |
| `scan SPEC [--base OLD_SPEC] --model JSON [--format text|markdown|json]` | Score the fields a spec (or a change) adds; rules first, never blocks |

## How training works

1. **Features** (`features.py`). Split camelCase, lower-case, split on non-alphanumerics, drop 35 stop words and 1-letter tokens, strip a plural `s` (words longer than 3 letters, not ending in `ss`). Name words become `name:<w>` and `word:<w>`; description words `word:<w>`. Five cues fire on regular expressions over name + description: `cue:money`, `cue:decision`, `cue:display`, `cue:no-effect`, `cue:engagement`. Features are binary.
2. **Model** (`model.py`). p(cde) = σ(bias + Σ weights of present features).
3. **Training**. All weights and the bias start at 0. For 300 epochs: for every row compute p; error = (p − y) × row weight; each feature’s gradient is the sum of errors over rows containing it. Update `w ← w − 0.5 × (gradient / Σrow weights + 0.002 × w)` for every weight and `b ← b − 0.5 × (Σerrors / Σrow weights)`. Steward labels have row weight 3. Deterministic.
4. **Threshold**. 0.5 by default. With `--val-split`, the highest precision that keeps validation recall ≥ `--min-recall` (0.95).

## Results (all synthetic, reproduced by `scripts/reproduce.sh`)

| Model | Trained on | Features | Bias | Final loss | Threshold |
|---|---|---|---|---|---|
| `page_model.json` | 99 rows of the 123-row set | 452 | −1.4798 | 0.0340 | 0.5 |
| `generated_model.json` | 857 generated rows (18 topics) | 356 | −0.5121 | 0.0973 | 0.6447 |
| `page_model_with_feedback.json` | 99 rows + 1 steward label ×3 | 458 | −1.3504 | 0.0377 | 0.5 |

| Model · evaluated on | TP / FP / FN / TN | Precision | Recall | F1 |
|---|---|---|---|---|
| page · held-out 24 rows | 12 / 0 / 0 / 12 | 1.000 | 1.000 | 1.000 |
| page · 12 evaluation fields | 7 / 0 / 0 / 5 | 1.000 | 1.000 | 1.000 |
| page · all 1,192 generated rows | 643 / 16 / 36 / 497 | 0.976 | 0.947 | 0.961 |
| generated · validation topics | 88 / 2 / 2 / 66 | 0.978 | 0.978 | 0.978 |
| **generated · test topics never seen** | **89 / 4 / 9 / 75** | **0.957** | **0.908** | **0.932** |
| generated · page set | 57 / 0 / 3 / 63 | 1.000 | 0.950 | 0.974 |
| rules only · 12 evaluation fields | 5 / 0 / 2 / 5 | 1.000 | 0.714 | 0.833 |

Read these honestly:
- The 123-row set is cleanly separable; 100% there demonstrates the pipeline, not accuracy.
- The most realistic figure is the **test-topic** row: recall 0.908, *below* the 0.95 target the threshold was chosen for on validation topics. Unseen topics are harder; 5 of its 13 errors are deliberately flipped labels; most others are credit-line fields with abbreviated names and no description.
- A random split of the same data reports precision 0.993 / recall 0.952 — near-copies leak into the test set. Use grouped splits.
- Some weights are artefacts of how the synthetic text is worded, e.g. `word:used` +0.81 and `word:account` +0.80 (see the notebook, section 7).

## Parity with the browser

`tests/test_parity.py` trains on the same 99 rows and compares with `tests/golden/browser_page_model.json`, produced by the page’s own JavaScript trainer: identical feature set, largest weight difference below 1e-12 (observed ≈ 2e-16), identical bias. Any model file here can be imported in `northstar_ml_candidate_model.html` (Train tab → *Import notebook model*); the page checks `format` and `tokenizer`.

## Using real data

1. Collect steward decisions in the format of `data/templates/labelled_fields_template.csv` (application, name, description, label, who, when). Do not treat “untagged” as `not_cde`.
2. Measure steward agreement on ~100 fields first; the model cannot beat it.
3. Add a `split` column grouped by `application_id` (and ideally by time).
4. `python -m northstar_cde train --data your.csv --train-split train --val-split val --test-split test --min-recall 0.95 --out artifacts/real_model.json`
5. Before production: test on applications never seen, monitor drift and acceptance rate, and obtain independent model validation under your model-risk policy.

## Limits

Bag of words: weak on negation and abbreviations, English only, unknown words fall back to the bias. Hyperparameters (300 / 0.5 / 0.002) were chosen, not tuned. Synthetic labels were written by the authors of this demo, not by stewards.
