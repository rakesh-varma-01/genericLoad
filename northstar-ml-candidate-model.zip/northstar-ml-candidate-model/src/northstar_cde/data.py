"""Reading/writing labelled CSVs and the two splitting strategies."""
import csv
import random
from pathlib import Path

LABELS = ("cde", "not_cde")


def read_rows(path):
    """Rows as dicts. Required columns: name, label. Optional: description, split, weight, and anything else."""
    with open(path, newline="", encoding="utf-8") as fh:
        reader = csv.DictReader(fh)
        missing = {"name", "label"} - set(reader.fieldnames or [])
        if missing:
            raise ValueError(f"{path}: missing columns {sorted(missing)}")
        rows = []
        for i, r in enumerate(reader, start=2):
            if r["label"] not in LABELS:
                raise ValueError(f"{path}:{i}: label must be cde or not_cde, got {r['label']!r}")
            if not r["name"].strip():
                raise ValueError(f"{path}:{i}: empty name")
            r["description"] = r.get("description") or ""
            if r.get("weight"):
                r["weight"] = float(r["weight"])
            rows.append(r)
    return rows


def write_rows(path, rows, columns):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=columns, extrasaction="ignore", lineterminator="\n")
        w.writeheader()
        w.writerows(rows)


def interleave_split(rows, holdout_every=5):
    """The browser's split: alternate cde / not_cde rows, hold out every 5th. Deterministic, no randomness."""
    pos = [r for r in rows if r["label"] == "cde"]
    neg = [r for r in rows if r["label"] != "cde"]
    mixed = []
    for i in range(max(len(pos), len(neg))):
        if i < len(pos):
            mixed.append(pos[i])
        if i < len(neg):
            mixed.append(neg[i])
    train = [r for i, r in enumerate(mixed) if i % holdout_every != holdout_every - 1]
    test = [r for i, r in enumerate(mixed) if i % holdout_every == holdout_every - 1]
    return train, test


def grouped_split(rows, group_key="concept", seed=42, fractions=(0.7, 0.15)):
    """Hold out whole groups (concepts here; applications with real data), separately per label.

    Returns {group: 'train'|'val'|'test'}. A random split would put near-copies of test rows in training.
    """
    assignment = {}
    all_groups = sorted({r[group_key] for r in rows})
    for label in LABELS:
        # A group belongs to the class most of its rows carry, so a few noisy labels cannot move it.
        groups = [g for g in all_groups if _majority_label(rows, group_key, g) == label]
        rng = random.Random(seed)
        rng.shuffle(groups)
        n = len(groups)
        cut1, cut2 = round(n * fractions[0]), round(n * (fractions[0] + fractions[1]))
        for i, g in enumerate(groups):
            assignment[g] = "train" if i < cut1 else "val" if i < cut2 else "test"
    return assignment


def _majority_label(rows, key, group):
    labels = [r["label"] for r in rows if r[key] == group]
    return max(LABELS, key=labels.count)


def by_split(rows, split):
    return [r for r in rows if r.get("split") == split]
