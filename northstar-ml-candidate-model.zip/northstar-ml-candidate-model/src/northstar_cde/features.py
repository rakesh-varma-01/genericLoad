"""Feature extraction, tokenizer v1.

Must stay byte-for-byte compatible with the browser pages (northstar_*.html) and northstar_scan.py:
a model trained here is imported there, and a different tokenizer would silently change every score.
Change anything in this file → bump TOKENIZER_VERSION and update the pages.
"""
import re

TOKENIZER_VERSION = "v1"

STOP_WORDS = frozenset(
    "the an of to for on in by and or is that when with from each was be after before into at as this "
    "its it are has have no not any per which whether".split()
)

# Hand-written domain cues. Matched against the lower-cased name (camelCase split) plus description.
CUES = (
    ("cue:money", re.compile(r"\b(amount|balance|balances|usd|fee|fees|interest|rate|apr|ledger|payment|principal)\b")),
    ("cue:decision", re.compile(r"(decision|delinquen|authoriz|underwrit|regulat|reporting|reconcil|charge.?off|capital|credit line)")),
    ("cue:display", re.compile(r"(display|decorative|cosmetic|icon|image|logo|theme|layout|artwork)")),
    ("cue:no-effect", re.compile(r"(no effect on|does not affect|not used (in|for))")),
    ("cue:engagement", re.compile(r"(notification|reminder|alert|survey|marketing|session|sign-in|login)")),
)

_CAMEL = re.compile(r"([a-z0-9])([A-Z])")
_NON_ALNUM = re.compile(r"[^a-z0-9]+")


def split_camel(text):
    """'creditLimit' -> 'credit Limit'. Lower-casing happens later."""
    return _CAMEL.sub(r"\1 \2", str(text or ""))


def tokens(text):
    """Lower-case words, minus stop words and 1-letter tokens, with a simple plural 's' stripped."""
    out = []
    for word in _NON_ALNUM.split(split_camel(text).lower()):
        if len(word) > 1 and word not in STOP_WORDS:
            out.append(word[:-1] if len(word) > 3 and word.endswith("s") and not word.endswith("ss") else word)
    return out


def features(name, description=""):
    """Binary features in first-seen order: name:<w>, word:<w> and any matching cue."""
    seen = {}
    for t in tokens(name):
        seen.setdefault("name:" + t, None)
        seen.setdefault("word:" + t, None)
    for t in tokens(description):
        seen.setdefault("word:" + t, None)
    text = (split_camel(name) + " " + str(description or "")).lower()
    for key, pattern in CUES:
        if pattern.search(text):
            seen.setdefault(key, None)
    return list(seen)
