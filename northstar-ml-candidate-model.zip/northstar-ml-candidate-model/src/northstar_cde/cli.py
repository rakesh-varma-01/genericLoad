"""Command line: python -m northstar_cde <generate|train|evaluate|predict|scan> ...  (or `northstar-cde` once installed)."""
import argparse
import json
import sys
from pathlib import Path

from . import data as D
from .evaluate import choose_threshold, metrics
from .generate import generate
from .model import load, predict, save, train
from .scan import scan, to_markdown


def _scores(model, rows):
    return [predict(model, r["name"], r["description"])["p"] for r in rows]


def _report(model, rows, t):
    return metrics([r["label"] for r in rows], _scores(model, rows), t) if rows else None


def cmd_generate(a):
    rows = generate(a.n, a.seed, a.noise, a.drop_desc, a.suffix_p)
    assignment = D.grouped_split(rows, "concept", a.seed)
    for r in rows:
        r["split"] = assignment[r["concept"]]
    D.write_rows(a.out, rows, ["concept", "name", "description", "label", "label_noise", "split"])
    by = {s: sum(r["split"] == s for r in rows) for s in ("train", "val", "test")}
    print(f"wrote {a.out}: {len(rows)} rows · {sum(r['label'] == 'cde' for r in rows)} cde · {sum(r['label_noise'] for r in rows)} noisy labels · split {by}")


def cmd_train(a):
    rows = D.read_rows(a.data)
    tr = D.by_split(rows, a.train_split) if a.train_split else rows
    if not tr:
        sys.exit(f"error: no rows with split={a.train_split!r} in {a.data}")
    fb = []
    if a.feedback:
        fb = [{**r, "weight": a.feedback_weight} for r in D.read_rows(a.feedback)]
    model = train(tr + fb, a.epochs, a.lr, a.l2, a.threshold)
    if a.val_split:
        val = D.by_split(rows, a.val_split)
        # Keep the exact score: rounding would move rows that sit right at the threshold.
        model.threshold = choose_threshold([r["label"] for r in val], _scores(model, val), a.min_recall, a.threshold)
    t = model.threshold
    reports = {"train": _report(model, tr, t)}
    for s in filter(None, [a.val_split, a.test_split]):
        reports[s] = _report(model, D.by_split(rows, s), t)
    for spec in a.eval or []:
        name, _, path = spec.partition("=")
        reports[name] = _report(model, D.read_rows(path), t)
    model.metadata = {"training": {"source": a.source or str(a.data), "train_split": a.train_split, "steward_labels": len(fb)},
                      "metrics": reports,
                      "notes": f"threshold {'chosen on ' + a.val_split + ' for recall >= ' + str(a.min_recall) if a.val_split else 'fixed'}"}
    save(model, a.out)
    L = model.losses
    print(f"trained on {model.examples} rows ({len(fb)} steward labels) · {len(model.weights)} features · bias {model.bias:.4f} · loss {L[0]:.4f} -> {L[-1]:.4f} · threshold {t:.4f}")
    for k, m in reports.items():
        if m:
            print(f"  {k:<22} precision {m['precision'] if m['precision'] is None else round(m['precision'], 3)}  recall {m['recall'] if m['recall'] is None else round(m['recall'], 3)}"
                  f"  f1 {m['f1']:.3f}  tp/fp/fn/tn {m['tp']}/{m['fp']}/{m['fn']}/{m['tn']}")
    print(f"saved {a.out}")


def cmd_evaluate(a):
    model = load(a.model)
    rows = D.read_rows(a.data)
    if a.split:
        rows = D.by_split(rows, a.split)
    print(json.dumps(_report(model, rows, a.threshold if a.threshold is not None else model.threshold), indent=1))


def cmd_predict(a):
    model = load(a.model)
    r = predict(model, a.name, a.description)
    t = a.threshold if a.threshold is not None else model.threshold
    print(f"{a.name}: p = {r['p']:.3f} (threshold {t}) -> {'suggest steward review' if r['p'] >= t and r['contributions'] else 'not suggested'}")
    print(f"  bias {model.bias:+.3f}")
    for k, w in r["contributions"]:
        print(f"  {w:+.3f}  {k}")
    if r["unseen"]:
        print("  unseen (ignored): " + ", ".join(r["unseen"]))


def cmd_scan(a):
    head = json.loads(Path(a.spec).read_text())
    base = json.loads(Path(a.base).read_text()) if a.base else None
    model = load(a.model) if a.model else None
    t = a.threshold if a.threshold is not None else (model.threshold if model else 0.5)
    rows = scan(head, base, model, t)
    label = f"model {Path(a.model).name}" if model else "rules only"
    if a.format == "json":
        print(json.dumps({"file": a.spec, "threshold": t, "fields": rows}, indent=1))
    elif a.format == "markdown":
        print(to_markdown(rows, Path(a.spec).name, label, t))
    else:
        print(f"{len(rows)} field(s) · {sum(1 for r in rows if r['signal'])} may need CDE review · {label} · threshold {t}")
        for r in sorted(rows, key=lambda r: (r["signal"] is None, -(r["p"] or 0))):
            print(f"  {r['field']:<22}{(r['signal'] or '—'):<32}{'n/a' if r['p'] is None else format(r['p'], '.2f'):>6}  {', '.join(r['why'])}")


def main(argv=None):
    ap = argparse.ArgumentParser(prog="northstar-cde", description="Train and use the Northstar CDE candidate model.")
    sub = ap.add_subparsers(dest="cmd", required=True)

    g = sub.add_parser("generate", help="write the synthetic labelled dataset with a grouped split")
    g.add_argument("--out", default="data/synthetic/generated_fields.csv")
    g.add_argument("--n", type=int, default=1500)
    g.add_argument("--seed", type=int, default=42)
    g.add_argument("--noise", type=float, default=0.02)
    g.add_argument("--drop-desc", type=float, default=0.08)
    g.add_argument("--suffix-p", type=float, default=0.35)
    g.set_defaults(fn=cmd_generate)

    t = sub.add_parser("train", help="train from scratch and save a model JSON")
    t.add_argument("--data", required=True)
    t.add_argument("--train-split", default="train", help="rows whose split column equals this; '' = all rows")
    t.add_argument("--val-split", help="choose the threshold on these rows")
    t.add_argument("--test-split", help="report metrics on these rows")
    t.add_argument("--min-recall", type=float, default=0.95)
    t.add_argument("--threshold", type=float, default=0.5)
    t.add_argument("--eval", action="append", metavar="NAME=CSV", help="extra labelled set to report on (repeatable)")
    t.add_argument("--feedback", help="CSV of steward labels added with --feedback-weight")
    t.add_argument("--feedback-weight", type=float, default=3.0)
    t.add_argument("--epochs", type=int, default=300)
    t.add_argument("--lr", type=float, default=0.5)
    t.add_argument("--l2", type=float, default=0.002)
    t.add_argument("--source", help="description of the data for the model card")
    t.add_argument("--out", required=True)
    t.set_defaults(fn=cmd_train)

    e = sub.add_parser("evaluate", help="metrics of a saved model on a labelled CSV")
    e.add_argument("--model", required=True)
    e.add_argument("--data", required=True)
    e.add_argument("--split")
    e.add_argument("--threshold", type=float)
    e.set_defaults(fn=cmd_evaluate)

    p = sub.add_parser("predict", help="score and explain one field")
    p.add_argument("--model", required=True)
    p.add_argument("--name", required=True)
    p.add_argument("--description", default="")
    p.add_argument("--threshold", type=float)
    p.set_defaults(fn=cmd_predict)

    s = sub.add_parser("scan", help="score the fields of an OpenAPI/JSON Schema file (never blocks)")
    s.add_argument("spec")
    s.add_argument("--base", help="previous version; only added fields are scored")
    s.add_argument("--model")
    s.add_argument("--threshold", type=float)
    s.add_argument("--format", choices=["text", "markdown", "json"], default="text")
    s.set_defaults(fn=cmd_scan)

    a = ap.parse_args(argv)
    a.fn(a)
    return 0


if __name__ == "__main__":
    sys.exit(main())
