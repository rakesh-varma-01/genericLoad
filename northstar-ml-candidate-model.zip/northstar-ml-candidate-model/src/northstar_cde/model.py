"""Logistic regression trained from scratch with full-batch gradient descent.

p(cde | field) = sigmoid(bias + sum of weights of the field's features)

The update rule, defaults and zero initialisation match the browser pages exactly, so a model trained here
scores identically there (tests/test_parity.py checks this against weights exported from the browser).
"""
import json
import math
from pathlib import Path

from .features import TOKENIZER_VERSION, features

MODEL_FORMAT = "northstar-cde-candidate-model"
FORMAT_VERSION = 1
LABELS = ("cde", "not_cde")
DEFAULTS = {"epochs": 300, "lr": 0.5, "l2": 0.002}


def sigmoid(z):
    # Same expression as the browser; the guard only avoids OverflowError for absurd inputs.
    return 1.0 / (1.0 + math.exp(-z)) if z > -700 else 0.0


class Model:
    def __init__(self, weights, bias, losses=None, examples=0, hyperparameters=None, threshold=0.5, metadata=None):
        self.weights = dict(weights)
        self.bias = float(bias)
        self.losses = list(losses or [])
        self.examples = int(examples)
        self.hyperparameters = dict(hyperparameters or DEFAULTS)
        self.threshold = float(threshold)
        self.metadata = dict(metadata or {})

    def predict(self, name, description=""):
        return predict(self, name, description)

    def to_dict(self):
        return {
            "format": MODEL_FORMAT, "format_version": FORMAT_VERSION, "tokenizer": TOKENIZER_VERSION,
            "model": "logistic regression (bag of words + domain cues)",
            "bias": self.bias, "weights": self.weights, "losses": [round(x, 6) for x in self.losses],
            "threshold": self.threshold, "hyperparameters": self.hyperparameters,
            "training": {"examples": self.examples, **self.metadata.get("training", {})},
            **{k: v for k, v in self.metadata.items() if k != "training"},
            "intended_use": "Suggest additional CDE candidates for steward review only",
            "never_used_for": ["verdicts", "policy results", "reuse decisions", "catalog designation"],
        }


def train(examples, epochs=300, lr=0.5, l2=0.002, threshold=0.5):
    """examples: dicts with name, description, label ('cde'|'not_cde') and optional weight (steward labels use 3)."""
    data = []
    for e in examples:
        if e["label"] not in LABELS:
            raise ValueError(f"label must be one of {LABELS}, got {e['label']!r} for {e.get('name')!r}")
        data.append((features(e["name"], e.get("description", "")), 1.0 if e["label"] == "cde" else 0.0, float(e.get("weight") or 1)))
    if not data:
        raise ValueError("no training examples")
    total_weight = sum(sw for _, _, sw in data)
    weights = {}
    for feats, _, _ in data:
        for k in feats:
            weights[k] = 0.0                       # every feature seen in training starts at zero
    bias, losses = 0.0, []
    for _ in range(epochs):
        grad, grad_bias, loss = {}, 0.0, 0.0
        for feats, y, sw in data:
            p = sigmoid(bias + sum(weights[k] for k in feats))
            err = (p - y) * sw
            grad_bias += err
            for k in feats:
                grad[k] = grad.get(k, 0.0) + err
            loss += -sw * (y * math.log(p + 1e-12) + (1 - y) * math.log(1 - p + 1e-12))
        for k in weights:                          # L2 shrinks every weight; the bias is not regularised
            weights[k] -= lr * (grad.get(k, 0.0) / total_weight + l2 * weights[k])
        bias -= lr * grad_bias / total_weight
        losses.append(loss / total_weight)
    return Model(weights, bias, losses, len(data), {"epochs": epochs, "lr": lr, "l2": l2}, threshold)


def predict(model, name, description=""):
    """Score plus the explanation: contributions are (feature, weight) sorted by |weight|."""
    feats = features(name, description)
    contributions = sorted(((k, model.weights[k]) for k in feats if model.weights.get(k)), key=lambda kv: -abs(kv[1]))
    z = model.bias + sum(w for _, w in contributions)
    return {"p": sigmoid(z), "z": z, "contributions": contributions, "unseen": [k for k in feats if k not in model.weights]}


def from_dict(d):
    """Validate like the browser importer: format, tokenizer and numeric weights."""
    if not isinstance(d, dict) or d.get("format") != MODEL_FORMAT:
        raise ValueError("not a Northstar CDE candidate model (format field missing or different)")
    if d.get("tokenizer") != TOKENIZER_VERSION:
        raise ValueError(f"model uses tokenizer {d.get('tokenizer')!r}; this code supports {TOKENIZER_VERSION!r}")
    w = d.get("weights")
    if not isinstance(d.get("bias"), (int, float)) or not isinstance(w, dict) or not all(isinstance(v, (int, float)) for v in w.values()):
        raise ValueError("model bias or weights are not numeric")
    meta = {k: v for k, v in d.items() if k in ("metrics", "data", "notes")}
    return Model(w, d["bias"], d.get("losses"), (d.get("training") or {}).get("examples", 0), d.get("hyperparameters"), d.get("threshold", 0.5), meta)


def save(model, path):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    Path(path).write_text(json.dumps(model.to_dict(), indent=1) + "\n", encoding="utf-8")


def load(path):
    return from_dict(json.loads(Path(path).read_text(encoding="utf-8")))
