"""Synthetic labelled-field generator (card billing). Replace with steward labels for real use.

26 business concepts: 14 a steward would usually review as CDEs, 12 they usually would not. Each row picks a
name stem and a description from its concept, renders the name in camel/snake/Pascal case, abbreviates some
words, sometimes appends a context clause or drops the description, and flips a small share of labels to
simulate steward disagreement. Hardship programmes are deliberately absent (used to demo learning from feedback).
"""
import random

CDE_CONCEPTS = {
    "statement_balance": (["statement balance", "new balance", "closing balance", "balance due", "statement total"],
        ["Balance owed at statement close", "Total amount owed shown on the monthly statement", "Amount the customer owes for the billing cycle", "Closing balance carried to the next statement"]),
    "current_balance": (["current balance", "outstanding balance", "ledger balance", "principal balance", "revolving balance"],
        ["Outstanding balance on the account at end of day", "Principal amount owed used for interest calculation", "Revolving balance subject to finance charges"]),
    "payment_due_date": (["payment due date", "due date", "next payment due date", "minimum due date"],
        ["Date by which payment must be received to avoid a late fee", "Payment deadline that drives delinquency treatment", "Deadline for the minimum payment"]),
    "minimum_payment": (["minimum payment", "minimum payment due", "minimum amount due", "min payment amount"],
        ["Minimum amount due to keep the account current", "Required minimum payment calculated each billing cycle", "Smallest payment that avoids a late fee"]),
    "fees": (["late fee amount", "annual fee", "over limit fee", "fee charged", "foreign transaction fee"],
        ["Late fee charged when the minimum payment is missed", "Fee amount assessed on the account during the cycle", "Annual fee charged to the card account"]),
    "interest_rate": (["purchase apr", "cash advance apr", "penalty rate", "promo rate percent", "daily periodic rate"],
        ["Annual percentage rate applied to purchases", "Interest rate applied to cash advance balances", "Penalty annual percentage rate after missed payments", "Periodic rate used to compute daily interest"]),
    "interest_charged": (["interest charged", "finance charge", "interest accrued", "interest amount"],
        ["Interest amount charged on revolving balances", "Finance charge posted for the billing cycle", "Accrued interest booked to the ledger"]),
    "credit_line": (["credit line amount", "available credit", "cash advance limit", "credit line", "approved line"],
        ["Total credit line assigned to the account", "Remaining credit available for purchase authorization", "Maximum cash advance amount authorized", "Approved credit line used in utilization"]),
    "risk_score": (["bureau score", "behavior score", "risk score", "probability of default", "credit grade"],
        ["Credit bureau score used in underwriting decisions", "Internal risk score used in credit line decisions", "Model estimate used in loss reserving and credit decisions"]),
    "delinquency": (["days past due", "delinquency bucket", "past due amount", "cycles delinquent"],
        ["Number of days the payment is late", "Delinquency stage used for collections and reporting", "Amount past due that drives delinquency treatment"]),
    "charge_off": (["charge off amount", "charge off date", "recovery amount", "net loss amount"],
        ["Amount charged off and reported in loss reporting", "Date the balance was charged off for regulatory reporting", "Amount recovered after charge-off"]),
    "ledger_posting": (["posted amount", "transaction amount", "settlement amount", "general ledger balance"],
        ["Amount posted to the ledger for the transaction", "Settlement amount reconciled to the general ledger", "Posted transaction amount in USD that updates the balance"]),
    "regulatory_report": (["regulatory report code", "reserve amount", "exposure at default", "call report line"],
        ["Code used in regulatory reporting of the account", "Loss reserve amount reported in financial statements", "Exposure amount used in capital reporting"]),
    "payment_posted": (["payment amount", "autopay amount", "payment posted date", "payment status"],
        ["Amount of the customer payment posted to the account", "Amount drafted by autopay from the customer bank account", "Status of the payment used in delinquency decisions"]),
}
NOT_CONCEPTS = {
    "display_ui": (["theme preference", "font size", "widget layout", "display name", "card nickname", "tile order"],
        ["Visual theme preference for the interface", "Preferred font size for the mobile app", "Layout of widgets on the dashboard", "Customer-chosen label shown in the app; display only", "Display-only nickname; no effect on billing or credit decisions"]),
    "imagery": (["card art id", "merchant logo url", "category icon", "avatar url", "background image"],
        ["Card artwork image identifier; display only", "Logo image shown next to transactions", "Icon shown for a spending category", "Decorative background image"]),
    "session_device": (["session id", "device type", "app version", "last login time", "push token"],
        ["Identifier of the current app session", "Type of device used to sign in", "Version of the mobile app installed", "Time of the last sign-in to the app"]),
    "web_analytics": (["page view count", "clickstream id", "search query", "last screen viewed"],
        ["Number of pages viewed in the session", "Identifier for web analytics events", "Text the customer searched for in the app"]),
    "marketing": (["campaign code", "marketing opt in", "promo banner id", "offer impression id"],
        ["Code of the marketing campaign that referred the visit", "Whether the customer agreed to receive marketing messages", "Identifier of the promotional banner shown"]),
    "survey_feedback": (["nps score", "app rating", "survey response"],
        ["Net promoter score from a customer survey", "Rating the customer gave the mobile app", "Free-text answer to a satisfaction survey"]),
    "contact_info": (["customer email", "mobile phone", "mailing address line", "contact email"],
        ["Email used for servicing messages and reminders", "Phone number for text reminders about payments", "Street address for paper mail", "Email used to send payment reminder notices"]),
    "notification_prefs": (["alert channel", "push enabled", "paperless flag", "reminder channel"],
        ["Channel used to send reminder notices", "Whether alerts are switched on in the app", "Whether the customer chose electronic delivery"]),
    "support_ops": (["chat transcript id", "agent notes", "call reason code", "help article id"],
        ["Identifier of a support chat transcript", "Free-text notes left by a service agent", "Reason selected for a servicing call"]),
    "budgeting": (["budget goal name", "spending category label", "favorite merchant"],
        ["Name of a personal budgeting goal", "Label of the budgeting category chosen by the customer", "Merchant the customer marked as favorite"]),
    "security_ux": (["mfa method", "last password change", "login attempts"],
        ["Preferred sign-in verification method", "Time the password was last changed", "Number of sign-in attempts in the session"]),
    "referral_social": (["referral code", "social handle", "birthday greeting sent"],
        ["Code shared to refer a friend", "Social media handle provided by the customer", "Whether a birthday greeting message was sent"]),
}
SUFFIX = {"cde": ["; used in autopay", "; reported to finance", "; drives late fees", "; reconciled daily to the ledger", "; input to credit decisions"],
          "not_cde": ["; shown on the home screen", "; used for analytics only", "; display only", "; no effect on billing or credit decisions"]}
ABBREV = {"amount": "amt", "balance": "bal", "date": "dt", "payment": "pmt", "percent": "pct", "credit": "cr", "limit": "lmt", "number": "num",
          "interest": "int", "account": "acct", "customer": "cust", "transaction": "txn", "minimum": "min", "statement": "stmt", "identifier": "id"}


def render_name(stem, rng, abbreviate_p=0.3):
    words = [ABBREV.get(w, w) if rng.random() < abbreviate_p else w for w in stem.lower().split()]
    style = rng.choice(["camel", "camel", "snake", "pascal"])
    if style == "snake":
        return "_".join(words)
    if style == "pascal":
        return "".join(w.capitalize() for w in words)
    return words[0] + "".join(w.capitalize() for w in words[1:])


def generate(n=1500, seed=42, noise=0.02, drop_desc=0.08, suffix_p=0.35):
    """Rows: concept, name, description, label, label_noise. Duplicate (name, description) pairs are dropped."""
    rng = random.Random(seed)
    pool = [(cid, "cde", v) for cid, v in CDE_CONCEPTS.items()] + [(cid, "not_cde", v) for cid, v in NOT_CONCEPTS.items()]
    rows, seen = [], set()
    for _ in range(n):
        cid, label, (stems, descs) = pool[rng.randrange(len(pool))]
        desc = "" if rng.random() < drop_desc else descs[rng.randrange(len(descs))] + (SUFFIX[label][rng.randrange(len(SUFFIX[label]))] if rng.random() < suffix_p else "")
        noisy = rng.random() < noise
        name = render_name(stems[rng.randrange(len(stems))], rng)
        if (name, desc) in seen:
            continue
        seen.add((name, desc))
        rows.append({"concept": cid, "name": name, "description": desc,
                     "label": ("not_cde" if label == "cde" else "cde") if noisy else label, "label_noise": noisy})
    return rows
