"""Metrics without third-party dependencies. Labels are 'cde' / 'not_cde'; scores are probabilities."""


def confusion(labels, scores, threshold):
    tp = fp = fn = tn = 0
    for label, s in zip(labels, scores):
        pred, pos = s >= threshold, label == "cde"
        tp += pred and pos
        fp += pred and not pos
        fn += (not pred) and pos
        tn += (not pred) and not pos
    return {"tp": tp, "fp": fp, "fn": fn, "tn": tn}


def metrics(labels, scores, threshold):
    c = confusion(labels, scores, threshold)
    tp, fp, fn, tn = c["tp"], c["fp"], c["fn"], c["tn"]
    n = tp + fp + fn + tn
    out = dict(c)
    out["precision"] = tp / (tp + fp) if tp + fp else None
    out["recall"] = tp / (tp + fn) if tp + fn else None
    out["f1"] = 2 * tp / (2 * tp + fp + fn) if tp else 0.0
    out["accuracy"] = (tp + tn) / n if n else None
    if 0 < tp + fn < n:
        out["average_precision"] = average_precision(labels, scores)
        out["roc_auc"] = roc_auc(labels, scores)
    return out


def average_precision(labels, scores):
    """Area under the precision-recall curve, step-wise (same definition as scikit-learn)."""
    pairs = sorted(zip(scores, labels), key=lambda x: -x[0])
    positives = sum(1 for _, l in pairs if l == "cde")
    if not positives:
        return None
    ap, tp, fp, prev_recall, i = 0.0, 0, 0, 0.0, 0
    while i < len(pairs):
        j = i
        while j < len(pairs) and pairs[j][0] == pairs[i][0]:  # ties share one threshold
            tp += pairs[j][1] == "cde"
            fp += pairs[j][1] != "cde"
            j += 1
        recall = tp / positives
        ap += (recall - prev_recall) * (tp / (tp + fp))
        prev_recall, i = recall, j
    return ap


def roc_auc(labels, scores):
    """Probability a random CDE outscores a random non-CDE (ties count half)."""
    pos = [s for l, s in zip(labels, scores) if l == "cde"]
    neg = [s for l, s in zip(labels, scores) if l != "cde"]
    if not pos or not neg:
        return None
    wins = sum((p > q) + 0.5 * (p == q) for p in pos for q in neg)
    return wins / (len(pos) * len(neg))


def choose_threshold(labels, scores, min_recall=0.95, fallback=0.5):
    """Highest precision among thresholds that keep recall >= min_recall; ties go to the higher threshold.

    For triage a missed CDE costs more than an extra review, hence a recall floor rather than max F1.
    """
    best = None
    for t in sorted(set(scores)):
        m = metrics(labels, scores, t)
        if m["recall"] is not None and m["recall"] >= min_recall and m["precision"] is not None:
            if best is None or m["precision"] >= best[0]:
                best = (m["precision"], t)
    return best[1] if best else fallback
