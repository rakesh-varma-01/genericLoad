"""The deterministic discovery rules the model complements (same as FIELD_RULES in the browser pages).

The model may only ADD fields the rules did not flag; it never removes a rule result or changes a verdict.
"""
import re

# (names after normalisation, description pattern, critical?) — critical = CDE candidate; else sensitivity only.
RULES = (
    (("statementbalance", "closingbalance", "currentbalance", "balance", "amountdue"), r"amount owed|statement balance|autopay", True),
    (("paymentduedate", "duedate"), r"payment deadline|payment due|delinquency", True),
    (("minimumpayment", "minimumpaymentdue"), r"minimum payment", True),
    (("creditscore", "fico"), r"credit decision|credit score", True),
    (("pan", "primaryaccountnumber", "cardnumber"), r"full payment card|primary account number", False),
    (("email", "customeremail"), r"email address|servicing contact", False),
    (("ssn", "socialsecuritynumber", "taxid"), r"social security|tax identifier", False),
)


def rule_signal(name, description=""):
    """'candidate', 'sensitive' or None. A name match wins; description patterns are skipped for display-only fields."""
    n = re.sub(r"[^a-z0-9]", "", str(name).lower())
    for names, _, critical in RULES:
        if n in names:
            return "candidate" if critical else "sensitive"
    if re.search(r"display.only|decorative|no effect on", str(description), re.I):
        return None
    for _, pattern, critical in RULES:
        if re.search(pattern, str(description), re.I):
            return "candidate" if critical else "sensitive"
    return None
