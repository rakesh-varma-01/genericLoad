"""Score the fields of an OpenAPI / JSON Schema document: rules first, then the model. Suggestions only."""
from .model import predict
from .rules import rule_signal


def extract_fields(spec):
    """Walk the document, resolving local $ref. A referenced schema gets its own path root (Statement.x)."""
    rows, seen = [], set()
    is_spec = isinstance(spec, dict) and any(k in spec for k in ("openapi", "swagger", "$schema"))

    def resolve(ref):
        node = spec
        for part in ref[2:].split("/"):
            node = node.get(part.replace("~1", "/").replace("~0", "~")) if isinstance(node, dict) else None
        return node

    def visit(node, path, refs, depth):
        if depth > 32 or not isinstance(node, (dict, list)):
            return
        if isinstance(node, list):
            for i, x in enumerate(node[:20]):
                visit(x, f"{path}[{i}]", refs, depth + 1)
            return
        ref = node.get("$ref")
        if isinstance(ref, str):
            if ref.startswith("#/") and ref not in refs and resolve(ref) is not None:
                visit(resolve(ref), ref.split("/")[-1], refs | {ref}, depth + 1)
            return
        if isinstance(node.get("properties"), dict):
            for k, v in node["properties"].items():
                if not isinstance(v, dict):
                    continue
                p = f"{path}.{k}"
                if p not in seen:
                    seen.add(p)
                    rows.append({"field": k, "path": p, "type": v.get("type", ""), "description": v.get("description", "")})
                visit(v, p, refs, depth + 1)
            return
        if node.get("type") == "array" and "items" in node:
            visit(node["items"], path + "[]", refs, depth + 1)
            return
        for kw in ("allOf", "oneOf", "anyOf"):
            if isinstance(node.get(kw), list):
                for part in node[kw]:
                    visit(part, path, refs, depth + 1)
        if isinstance(node.get("type"), str) or "format" in node:
            return
        for k, v in node.items():
            if k in ("info", "example", "examples", "description", "required", "servers", "tags", "security", "allOf", "oneOf", "anyOf"):
                continue
            if is_spec and depth == 0 and k in ("components", "definitions", "$defs"):
                continue
            if isinstance(v, (dict, list)):
                visit(v, path if is_spec else f"{path}.{k}", refs, depth + 1)
            elif not is_spec and f"{path}.{k}" not in seen:
                seen.add(f"{path}.{k}")
                rows.append({"field": k, "path": f"{path}.{k}", "type": type(v).__name__, "description": ""})

    visit(spec, "$", frozenset(), 0)
    return rows


def scan(head, base=None, model=None, threshold=0.5):
    """Score fields in `head` that are not in `base`. signal: rule candidate / rule sensitive / model / None."""
    old = {r["path"] for r in extract_fields(base)} if base is not None else set()
    out = []
    for f in (r for r in extract_fields(head) if r["path"] not in old):
        rule = rule_signal(f["field"], f["description"])
        p, why = None, []
        if model is not None:
            pr = predict(model, f["field"], f["description"])
            p, why = pr["p"], [f"{w:+.2f} {k}" for k, w in pr["contributions"][:3]]
        signal = ("Rule: CDE candidate" if rule == "candidate" else "Rule: sensitive, needs context" if rule == "sensitive"
                  else "Model: suggest review" if p is not None and why and p >= threshold else None)
        out.append({**f, "signal": signal, "p": p, "why": why})
    return out


def to_markdown(rows, file, model_label, threshold):
    flagged, rest = [r for r in rows if r["signal"]], [r for r in rows if not r["signal"]]
    head = "| Field | Signal | Model score | Top reasons |\n|---|---|---|---|"

    def line(r):
        reasons = " ".join(f"`{w}`" for w in r["why"]) if r["why"] else ("rule match" if (r["signal"] or "").startswith("Rule") else "—")
        return "| `{}` | {} | {} | {} |".format(r["field"], r["signal"] or "—", "n/a" if r["p"] is None else f"{r['p']:.2f}", reasons)

    parts = ["### Northstar CDE review — suggestion, not a gate", "", f"{len(rows)} new field(s) in `{file}`; **{len(flagged)}** may need CDE review.", ""]
    parts += ([head] + [line(r) for r in flagged]) if flagged else ["No new field needs CDE review."]
    parts += [""]
    if rest:
        parts += [f"<details><summary>{len(rest)} field(s) below threshold</summary>", "", head] + [line(r) for r in rest] + ["", "</details>", ""]
    parts += [f"_Rules + {model_label} · threshold {threshold}. A data steward decides; nothing in the catalog changed._"]
    return "\n".join(parts)
