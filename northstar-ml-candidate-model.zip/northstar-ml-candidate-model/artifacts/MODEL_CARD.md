# Model card — Northstar CDE candidate model

| | |
|---|---|
| **Type** | Logistic regression over binary bag-of-words features plus 5 hand-written domain cues (tokenizer v1) |
| **Training** | Full-batch gradient descent, 300 epochs, learning rate 0.5, L2 0.002 (weights only), zero initialisation, steward labels weighted ×3 |
| **Files** | `page_model.json` · `generated_model.json` · `page_model_with_feedback.json` (JSON, importable in the browser page) |
| **Intended use** | Suggest additional fields for a data steward to review as possible CDEs, in project artifacts (API specs, schemas). Decision support only. |
| **Out of scope** | CDE designation, project verdicts, policy or compliance results, data-reuse or access decisions, anything about customers or data values. |
| **Guardrail** | In Northstar the model can only *add* a field to the review list; rules decide the verdict, which is identical with and without the model. |

## Training data

Synthetic only — see `data/DATA_CARD.md`. `page_model`: 99 rows of the 123-row hand-written set. `generated_model`: 857 rows from 18 of 26 generated topics.

## Results

| Model | Evaluation | Precision | Recall | F1 |
|---|---|---|---|---|
| page_model (t = 0.5) | 24 held-out rows | 1.000 | 1.000 | 1.000 |
| page_model | 12 evaluation fields | 1.000 | 1.000 | 1.000 |
| page_model | all 1,192 generated rows | 0.976 | 0.947 | 0.961 |
| generated_model (t = 0.6447, chosen for val recall ≥ 0.95) | validation topics | 0.978 | 0.978 | 0.978 |
| generated_model | **test topics never seen** | **0.957** | **0.908** | **0.932** |

Average precision on the test topics: 0.985; ROC AUC: 0.978.

## Explainability

Every score decomposes exactly into bias + the weights of the field’s features (tested). Example, `page_model`: `creditLimit` → −1.48 bias + 1.59 `cue:decision` + 0.81 `word:used` + 0.74 `word:credit` + … = 3.51 → p = 0.971.

## Known limitations

- Labels written by the demo authors, not stewards; synthetic data is easier than real metadata.
- Some weights reflect wording artefacts (`word:used` +0.81, `word:account` +0.80).
- Weak on abbreviations (`AvailableCr` with no description scores 0.35 in the generated model) and negation; English only.
- Unknown words are ignored; a field with none scores σ(bias) (0.19 for page_model).
- Recall on unseen topics (0.908) fell short of the 0.95 target set on validation topics.

## Before production

Real steward labels across several applications · measured steward agreement · split by application and time · threshold chosen on validation applications · drift and acceptance-rate monitoring · independent validation under the organisation’s model-risk policy (for example, US Fed SR 11-7).
