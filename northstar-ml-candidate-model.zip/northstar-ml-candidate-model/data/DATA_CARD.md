# Data card

All datasets are **synthetic**. Labels imitate how a data steward would judge card-billing fields; no steward labelled them and no real or bank data is included.

**Label meaning.** `cde` = worth a steward’s review as a possible Critical Data Element. `not_cde` = would not be reviewed as one. A label is a review recommendation, never an official designation.

## `raw/page_labelled_fields.csv` — 123 rows

| Column | Meaning |
|---|---|
| `name` | Field name (camelCase) |
| `description` | One-line business description (every row has one) |
| `label` | `cde` (60) or `not_cde` (63) |
| `split` | `train` (99: 48 cde, 51 not) or `holdout` (24: 12 / 12) |

- **Origin:** hand-written for the Northstar demo; byte-identical to the `ML_CDE` / `ML_NOT` blocks in `northstar_ml_candidate_model.html`.
- **Split rule:** interleave cde and not_cde rows (cde₁, not₁, cde₂, not₂ …; the three extra not_cde rows go last) and hold out every 5th row.
- **CDE topics:** balances, payment due dates, minimum payments, fees, interest rates/APR, interest charged, credit lines, risk scores, delinquency, charge-offs, ledger postings, regulatory reporting, payments.
- **Not-CDE topics:** display/UI settings, images, sessions and devices, analytics, marketing, surveys, contact details, notifications, support notes, budgeting, security UX, referrals.
- **Deliberate choices:** three not_cde rows use “no effect on … credit / does not affect” wording (`cardColorChoice`, `statementHeaderLabel`, `rewardsTierName`) so negated decision wording is learned; no hardship-programme rows (used to demonstrate learning from one steward label).
- **Known artefacts:** many cde descriptions say “used in…” or mention “account”, so those generic words gain weight (+0.81 / +0.80).

## `raw/eval_fields.csv` — 12 rows

Written separately from the training rows (no name overlap; a test enforces it). 7 cde, 5 not_cde. Used for rules vs rules + model: rules miss `creditLimit` and `aprPercent`.

## `raw/steward_feedback_example.csv` — 1 row

`hardshipPlanFlag` labelled `cde`, used with row weight 3 to show learning from a steward decision.

## `synthetic/generated_fields.csv` — 1,192 rows

| Column | Meaning |
|---|---|
| `concept` | One of 26 topics (14 cde, 12 not_cde) |
| `name`, `description` | Rendered from the topic’s stems and sentences |
| `label` | 679 cde / 513 not_cde |
| `label_noise` | `True` for the 24 rows whose label was flipped on purpose (2%) |
| `split` | `train` 857 · `val` 158 · `test` 177 — **whole topics** per split, chosen per class |

- **Generator:** `python -m northstar_cde generate` (`src/northstar_cde/generate.py`), `random.Random(42)`, 1,500 draws, duplicates of (name, description) dropped → 1,192 rows. Names are rendered camel / snake / Pascal case; 30% of words abbreviated (amount → amt, balance → bal …); 35% get a context clause; 8% have no description; 2% labels flipped.
- **Topics per split:** test = contact_info, credit_line, payment_posted, survey_feedback · val = budgeting, charge_off, fees, marketing · train = the other 18.
- **Quirk:** stems and descriptions are drawn independently within a topic, so some pairs read oddly (e.g. a name about a phone with a description about an address); the label follows the topic.
- **Differs from the earlier notebook** in the parent folder (`cde_candidate_model.ipynb`), which used NumPy’s random generator: the rows are different, the method is the same.

## `templates/labelled_fields_template.csv`

Format for real steward labels: `application_id, name, description, label, labelled_by, labelled_at, source`. Split real data by `application_id`.
