import contextlib
import io
import json
import tempfile
import unittest
from pathlib import Path

from _helpers import EVAL_CSV, FIXTURES, PAGE_CSV
from northstar_cde.cli import main
from northstar_cde.data import by_split, read_rows
from northstar_cde.evaluate import average_precision, choose_threshold, metrics, roc_auc
from northstar_cde.model import predict, train
from northstar_cde.rules import rule_signal
from northstar_cde.scan import extract_fields, scan


class MetricsTest(unittest.TestCase):
    def test_hand_computed_example(self):
        labels = ["cde", "cde", "not_cde", "not_cde"]
        m = metrics(labels, [0.9, 0.4, 0.6, 0.1], 0.5)
        self.assertEqual((m["tp"], m["fp"], m["fn"], m["tn"]), (1, 1, 1, 1))
        self.assertEqual((m["precision"], m["recall"], m["accuracy"]), (0.5, 0.5, 0.5))
        self.assertAlmostEqual(roc_auc(labels, [0.9, 0.4, 0.6, 0.1]), 0.75)
        self.assertAlmostEqual(average_precision(labels, [0.9, 0.4, 0.6, 0.1]), (1.0 + 2 / 3) / 2)

    def test_threshold_respects_recall_floor(self):
        labels = ["cde"] * 4 + ["not_cde"] * 4
        scores = [0.9, 0.8, 0.7, 0.3, 0.6, 0.2, 0.1, 0.05]
        t = choose_threshold(labels, scores, 0.95)
        self.assertGreaterEqual(metrics(labels, scores, t)["recall"], 0.95)
        self.assertEqual(t, 0.3)


class RulesTest(unittest.TestCase):
    def test_rules_on_the_eval_set_miss_exactly_two(self):
        ev = read_rows(EVAL_CSV)
        missed = [r["name"] for r in ev if r["label"] == "cde" and rule_signal(r["name"], r["description"]) != "candidate"]
        self.assertEqual(sorted(missed), ["aprPercent", "creditLimit"])

    def test_signals(self):
        self.assertEqual(rule_signal("statementBalance", ""), "candidate")
        self.assertEqual(rule_signal("customerEmail", ""), "sensitive")
        self.assertIsNone(rule_signal("rewardsNickname", "Display-only label; no effect on billing or credit"))


class ScanTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.model = train(by_split(read_rows(PAGE_CSV), "train"))
        cls.v24 = json.loads((FIXTURES / "statement-api-v2.4.json").read_text())
        cls.v25 = json.loads((FIXTURES / "statement-api-v2.5.json").read_text())

    def test_extract_fields_resolves_ref(self):
        self.assertEqual([f["path"] for f in extract_fields(self.v24)],
                         ["Statement.statementBalance", "Statement.paymentDueDate", "Statement.customerEmail", "Statement.rewardsNickname"])

    def test_pr_scan_flags_only_what_rules_miss(self):
        rows = {r["field"]: r for r in scan(self.v25, self.v24, self.model, 0.5)}
        self.assertEqual(set(rows), {"creditLimit", "aprPercent", "hardshipProgramCode", "cardArtId", "lastLoginAt"})
        self.assertEqual(sorted(f for f, r in rows.items() if r["signal"]), ["aprPercent", "creditLimit"])
        self.assertTrue(all(r["signal"].startswith("Model") for r in rows.values() if r["signal"]))

    def test_rules_take_precedence_over_model(self):
        rows = {r["field"]: r for r in scan(self.v24, None, self.model, 0.5)}
        self.assertEqual(rows["statementBalance"]["signal"], "Rule: CDE candidate")
        self.assertEqual(rows["customerEmail"]["signal"], "Rule: sensitive, needs context")

    def test_without_model_only_rules(self):
        self.assertFalse(any(r["signal"] for r in scan(self.v25, self.v24, None)))


class CliTest(unittest.TestCase):
    def run_cli(self, *args):
        buf = io.StringIO()
        with contextlib.redirect_stdout(buf):
            self.assertEqual(main(list(args)), 0)
        return buf.getvalue()

    def test_train_predict_evaluate_scan(self):
        with tempfile.TemporaryDirectory() as d:
            out = Path(d) / "m.json"
            self.assertIn("452 features", self.run_cli("train", "--data", str(PAGE_CSV), "--test-split", "holdout", "--out", str(out)))
            self.assertIn("p = 0.971", self.run_cli("predict", "--model", str(out), "--name", "creditLimit", "--description", "Approved credit line used in utilization and authorization"))
            ev = json.loads(self.run_cli("evaluate", "--model", str(out), "--data", str(EVAL_CSV)))
            self.assertEqual((ev["tp"], ev["fp"], ev["fn"], ev["tn"]), (7, 0, 0, 5))
            md = self.run_cli("scan", str(FIXTURES / "statement-api-v2.5.json"), "--base", str(FIXTURES / "statement-api-v2.4.json"), "--model", str(out), "--format", "markdown")
            self.assertIn("suggestion, not a gate", md)
            self.assertIn("`creditLimit`", md)


if __name__ == "__main__":
    unittest.main()
