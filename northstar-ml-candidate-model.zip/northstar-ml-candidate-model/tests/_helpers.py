"""Shared paths for the tests. Runs with the standard library: python -m unittest discover -s tests"""
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

DATA = ROOT / "data"
PAGE_CSV = DATA / "raw" / "page_labelled_fields.csv"
EVAL_CSV = DATA / "raw" / "eval_fields.csv"
GENERATED_CSV = DATA / "synthetic" / "generated_fields.csv"
FIXTURES = ROOT / "tests" / "fixtures"
GOLDEN = ROOT / "tests" / "golden"
