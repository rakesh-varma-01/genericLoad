import json
import tempfile
import unittest
from pathlib import Path

from _helpers import PAGE_CSV
from northstar_cde.data import by_split, read_rows
from northstar_cde.model import from_dict, load, predict, save, train


class TrainingTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        rows = read_rows(PAGE_CSV)
        cls.train_rows, cls.holdout = by_split(rows, "train"), by_split(rows, "holdout")
        cls.model = train(cls.train_rows)

    def test_documented_numbers(self):
        m = self.model
        self.assertEqual(len(m.weights), 452)
        self.assertEqual(m.examples, 99)
        self.assertAlmostEqual(m.bias, -1.4798, places=4)
        self.assertAlmostEqual(m.losses[0], 0.6931, places=4)
        self.assertAlmostEqual(m.losses[-1], 0.0340, places=4)
        self.assertEqual(len(m.losses), 300)

    def test_deterministic(self):
        again = train(self.train_rows)
        self.assertEqual(again.weights, self.model.weights)
        self.assertEqual(again.bias, self.model.bias)

    def test_loss_never_increases(self):
        L = self.model.losses
        self.assertTrue(all(b <= a + 1e-12 for a, b in zip(L, L[1:])))

    def test_training_rows_separable_holdout_correct(self):
        for rows in (self.train_rows, self.holdout):
            for r in rows:
                self.assertEqual(predict(self.model, r["name"], r["description"])["p"] >= 0.5, r["label"] == "cde", r["name"])

    def test_explanation_sums_to_logit(self):
        r = predict(self.model, "creditLimit", "Approved credit line used in utilization and authorization")
        self.assertAlmostEqual(r["z"], self.model.bias + sum(w for _, w in r["contributions"]), places=12)
        self.assertAlmostEqual(r["p"], 0.971, places=3)
        self.assertEqual(r["contributions"][0][0], "cue:decision")

    def test_unknown_words_fall_back_to_bias(self):
        r = predict(self.model, "field_a", "")
        self.assertEqual(r["contributions"], [])
        self.assertAlmostEqual(r["p"], 0.1855, places=3)

    def test_steward_label_generalises_to_unseen_fields(self):
        fb = train(self.train_rows + [{"name": "hardshipPlanFlag", "description": "Customer enrolled in a hardship repayment plan", "label": "cde", "weight": 3}])
        for name, desc in [("hardshipProgramCode", "Hardship program assigned to the account"), ("hardshipEnrollmentDate", "Date the customer joined a hardship program")]:
            self.assertLess(predict(self.model, name, desc)["p"], 0.5)
            self.assertGreaterEqual(predict(fb, name, desc)["p"], 0.5)

    def test_rejects_bad_labels(self):
        with self.assertRaises(ValueError):
            train([{"name": "x", "description": "", "label": "maybe"}])
        with self.assertRaises(ValueError):
            train([])


class SerialisationTest(unittest.TestCase):
    def test_round_trip_and_browser_fields(self):
        m = train([{"name": "lateFeeAmount", "description": "Late fee", "label": "cde"}, {"name": "themeColor", "description": "Display only", "label": "not_cde"}], epochs=20)
        with tempfile.TemporaryDirectory() as d:
            p = Path(d) / "m.json"
            save(m, p)
            raw = json.loads(p.read_text())
            for key in ("format", "tokenizer", "bias", "weights", "threshold", "intended_use", "never_used_for"):
                self.assertIn(key, raw)
            back = load(p)
            self.assertEqual(back.weights, m.weights)
            self.assertEqual(back.bias, m.bias)

    def test_import_validation_matches_browser(self):
        with self.assertRaises(ValueError):
            from_dict({"format": "something-else"})
        with self.assertRaises(ValueError):
            from_dict({"format": "northstar-cde-candidate-model", "tokenizer": "v2", "bias": 0, "weights": {}})
        with self.assertRaises(ValueError):
            from_dict({"format": "northstar-cde-candidate-model", "tokenizer": "v1", "bias": 0, "weights": {"a": "x"}})


if __name__ == "__main__":
    unittest.main()
