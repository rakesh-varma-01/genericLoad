import tempfile
import unittest
from pathlib import Path

from _helpers import EVAL_CSV, GENERATED_CSV, PAGE_CSV
from northstar_cde.data import grouped_split, interleave_split, read_rows, write_rows
from northstar_cde.generate import generate


class PageSetTest(unittest.TestCase):
    """The 123-row set the browser trains on."""

    @classmethod
    def setUpClass(cls):
        cls.rows = read_rows(PAGE_CSV)

    def test_counts(self):
        self.assertEqual(len(self.rows), 123)
        self.assertEqual(sum(r["label"] == "cde" for r in self.rows), 60)
        self.assertEqual(sum(r["label"] == "not_cde" for r in self.rows), 63)

    def test_unique_names_and_every_row_described(self):
        self.assertEqual(len({r["name"] for r in self.rows}), 123)
        self.assertTrue(all(r["description"] for r in self.rows))

    def test_split_column_matches_interleave_rule(self):
        train, test = interleave_split(self.rows)
        self.assertEqual((len(train), len(test)), (99, 24))
        self.assertEqual(sum(r["label"] == "cde" for r in train), 48)
        self.assertEqual({r["name"] for r in test}, {r["name"] for r in self.rows if r["split"] == "holdout"})
        self.assertEqual([r["name"] for r in test][:3], ["newBalance", "fontSize", "minimumPaymentAmount"])

    def test_no_hardship_rows(self):
        self.assertFalse(any("hardship" in (r["name"] + r["description"]).lower() for r in self.rows))


class EvalSetTest(unittest.TestCase):
    def test_twelve_fields_none_in_training(self):
        ev = read_rows(EVAL_CSV)
        self.assertEqual(len(ev), 12)
        self.assertEqual(sum(r["label"] == "cde" for r in ev), 7)
        self.assertFalse({r["name"] for r in ev} & {r["name"] for r in read_rows(PAGE_CSV)})


class GeneratedSetTest(unittest.TestCase):
    def test_generator_is_deterministic(self):
        self.assertEqual(generate(200, seed=7), generate(200, seed=7))
        self.assertNotEqual(generate(200, seed=7), generate(200, seed=8))

    def test_committed_csv_matches_generator(self):
        rows = read_rows(GENERATED_CSV)
        fresh = generate()
        self.assertEqual(len(rows), len(fresh))
        self.assertEqual([(r["name"], r["description"], r["label"]) for r in rows], [(r["name"], r["description"], r["label"]) for r in fresh])

    def test_grouped_split_never_shares_a_concept(self):
        rows = read_rows(GENERATED_CSV)
        by_split = {}
        for r in rows:
            by_split.setdefault(r["split"], set()).add(r["concept"])
        self.assertEqual(set(by_split), {"train", "val", "test"})
        self.assertFalse(by_split["train"] & by_split["val"] or by_split["train"] & by_split["test"] or by_split["val"] & by_split["test"])

    def test_grouped_split_keeps_both_classes_everywhere(self):
        rows = generate(1500, seed=42)
        a = grouped_split(rows, "concept", 42)
        for split in ("train", "val", "test"):
            labels = {r["label"] for r in rows if a[r["concept"]] == split and not r["label_noise"]}
            self.assertEqual(labels, {"cde", "not_cde"}, split)


class CsvValidationTest(unittest.TestCase):
    def test_bad_label_and_missing_column_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            p = Path(d) / "x.csv"
            write_rows(p, [{"name": "a", "label": "maybe"}], ["name", "label"])
            with self.assertRaises(ValueError):
                read_rows(p)
            p.write_text("name,description\na,b\n")
            with self.assertRaises(ValueError):
                read_rows(p)


if __name__ == "__main__":
    unittest.main()
