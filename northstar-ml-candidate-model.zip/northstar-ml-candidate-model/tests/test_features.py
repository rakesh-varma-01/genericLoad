import unittest

import _helpers  # noqa: F401  (adds src/ to the path)
from northstar_cde.features import STOP_WORDS, TOKENIZER_VERSION, features, split_camel, tokens


class TokenizerTest(unittest.TestCase):
    def test_version_is_v1(self):
        self.assertEqual(TOKENIZER_VERSION, "v1")

    def test_camel_snake_and_pascal_split(self):
        self.assertEqual(split_camel("creditLimit"), "credit Limit")
        self.assertEqual(tokens("creditLimit"), ["credit", "limit"])
        self.assertEqual(tokens("credit_limit"), ["credit", "limit"])
        self.assertEqual(tokens("CreditLimit"), ["credit", "limit"])

    def test_stop_words_and_single_letters_dropped(self):
        self.assertEqual(len(STOP_WORDS), 35)
        self.assertEqual(tokens("the amount of a fee"), ["amount", "fee"])

    def test_plural_rule(self):
        self.assertEqual(tokens("balances fees days"), ["balance", "fee", "day"])
        self.assertEqual(tokens("loss address"), ["loss", "address"])  # 'ss' kept
        self.assertEqual(tokens("apps"), ["app"])
        self.assertEqual(tokens("abs"), ["abs"])                          # 3 letters kept


class FeatureTest(unittest.TestCase):
    def test_documented_example(self):
        f = features("creditLineAmount", "Total credit line assigned to the account; used in authorization")
        self.assertEqual(f, ["name:credit", "word:credit", "name:line", "word:line", "name:amount", "word:amount",
                             "word:total", "word:assigned", "word:account", "word:used", "word:authorization",
                             "cue:money", "cue:decision"])

    def test_each_cue(self):
        self.assertIn("cue:money", features("x", "Annual percentage rate applied"))
        self.assertIn("cue:decision", features("x", "Used in underwriting decisions"))
        self.assertIn("cue:display", features("x", "Display only label"))
        self.assertIn("cue:no-effect", features("x", "no effect on billing"))
        self.assertIn("cue:engagement", features("x", "Time of the last sign-in"))

    def test_cue_reads_the_name_too(self):
        self.assertIn("cue:money", features("lateFeeAmount", ""))

    def test_no_duplicates_and_empty_inputs(self):
        f = features("amount", "amount amount")
        self.assertEqual(len(f), len(set(f)))
        self.assertEqual(features("", ""), [])


if __name__ == "__main__":
    unittest.main()
