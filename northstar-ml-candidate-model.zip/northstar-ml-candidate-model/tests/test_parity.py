"""The Python trainer must reproduce the browser trainer exactly.

tests/golden/browser_page_model.json holds the weights produced by trainModel() in the engine of
northstar_ml_candidate_model.html (run in Node on the 99 training rows, defaults 300 / 0.5 / 0.002).
"""
import json
import unittest

from _helpers import GOLDEN, PAGE_CSV
from northstar_cde.data import by_split, read_rows
from northstar_cde.model import train


class BrowserParityTest(unittest.TestCase):
    def test_weights_and_bias_match_browser(self):
        golden = json.loads((GOLDEN / "browser_page_model.json").read_text())
        model = train(by_split(read_rows(PAGE_CSV), "train"))
        self.assertEqual(set(model.weights), set(golden["weights"]))
        worst = max(abs(model.weights[k] - golden["weights"][k]) for k in golden["weights"])
        self.assertLess(worst, 1e-12, f"largest weight difference {worst}")
        self.assertLess(abs(model.bias - golden["bias"]), 1e-12)


if __name__ == "__main__":
    unittest.main()
