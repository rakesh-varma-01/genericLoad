#!/usr/bin/env bash
# Rebuild data and artifacts, then run the tests — same steps as `make all`, without needing make.
# Usage: scripts/reproduce.sh [python-interpreter]
set -euo pipefail
cd "$(dirname "$0")/.."
PY="${1:-python3}"
export PYTHONPATH=src

"$PY" -m northstar_cde generate --out data/synthetic/generated_fields.csv

"$PY" -m northstar_cde train --data data/raw/page_labelled_fields.csv --train-split train --test-split holdout \
  --eval eval_fields=data/raw/eval_fields.csv --eval generated_all=data/synthetic/generated_fields.csv \
  --source "123 hand-written synthetic rows (same as northstar_ml_candidate_model.html)" --out artifacts/page_model.json

"$PY" -m northstar_cde train --data data/synthetic/generated_fields.csv --train-split train --val-split val --test-split test --min-recall 0.95 \
  --eval eval_fields=data/raw/eval_fields.csv --eval page_set=data/raw/page_labelled_fields.csv \
  --source "1,192 generated synthetic rows, split by concept" --out artifacts/generated_model.json

"$PY" -m northstar_cde train --data data/raw/page_labelled_fields.csv --train-split train --test-split holdout \
  --feedback data/raw/steward_feedback_example.csv --source "page set + 1 steward label (weight 3)" \
  --out artifacts/page_model_with_feedback.json

"$PY" -m unittest discover -s tests
